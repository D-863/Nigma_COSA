#include "cosaLinux.h"
#include "../headers/error.h"

void _ExpandContextBlockPageRegion(cosaContext *pContext) {
    cosaPrintF("pContext->blockPage.count<%lu>\n", pContext->blockPage.count);
    COSA_PAGE_BLOCK_EXPAND(pContext->blockPage.count);
    cosaPrintF("pContext->blockPage.count<%lu>\n", pContext->blockPage.count);

    cosaMemBlock *pNewBlocks = mmap(
        NULL,
        pContext->blockPage.count * sizeof(cosaMemBlock),
        COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
        COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
        -1, 0);
    if (pNewBlocks == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);

        pContext->blockPage.count = pContext->blockPage.top;
        return;
    }
    (void)memcpy(pNewBlocks, pContext->blockPage.pBlocks, pContext->blockPage.top * sizeof(cosaMemBlock));
    (void)memset(pNewBlocks + pContext->blockPage.top, 0, (pContext->blockPage.count - pContext->blockPage.top) * sizeof(cosaMemBlock));

    if (munmap(pContext->blockPage.pBlocks, pContext->blockPage.top * sizeof(cosaMemBlock)) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)munmap(pNewBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));

        pContext->blockPage.count = pContext->blockPage.top;
        return;
    }
    pContext->blockPage.pBlocks = pNewBlocks;
} 

void _ExpandContextMemPageRegion(cosaContext *pContext) {
    COSA_PAGE_MEM_EXPAND(pContext->memPage.size);
    cosaUSize i;
    for (i = 0; (i < COSA_PAGE_MEM_MAX_CONTIGUOUS_EXPANSION) && (pContext->memPage.top >= pContext->memPage.size); ++i) {
        COSA_PAGE_MEM_EXPAND(pContext->memPage.size);
    }
    if (i == (COSA_PAGE_MEM_MAX_CONTIGUOUS_EXPANSION - 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPCLC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPCLC;
        #if defined(COSA_ENABLE_DEBUG)
            cosaPrintF("(_ExpandContextMemPageRegion)i<%lu>\n", i);
            cosaPrintF("(_ExpandContextMemPageRegion)pContext->memPage.size<%lu>\n", pContext->memPage.size);
            cosaPrintF("(_ExpandContextMemPageRegion)pContext->memPage.top<%lu>\n", pContext->memPage.top);
        #endif
        return;
    }

    cosaU8 *pNewMem = mmap(
        NULL,
        pContext->memPage.size,
        COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
        COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
        -1, 0);
    if (pNewMem == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);

        pContext->memPage.size = pContext->memPage.top;
        return;
    }
    (void)memcpy(pNewMem, pContext->memPage.pMem, pContext->memPage.top);
    (void)memset(pNewMem + pContext->memPage.top, 0, pContext->memPage.size - pContext->memPage.top);

    if (munmap(pContext->memPage.pMem, pContext->memPage.top) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)munmap(pNewMem, pContext->memPage.size);

        pContext->memPage.size = pContext->memPage.top;
        return;
    }

    bool isNewMemAddrBehind = cosaBFalse;
    cosaUSize newMemAddrDiff = 0;
    if (pContext->memPage.pMem < pNewMem) {
        isNewMemAddrBehind = cosaBFalse;
        newMemAddrDiff = pNewMem - pContext->memPage.pMem;
    } else {
        isNewMemAddrBehind = cosaBTrue;
        newMemAddrDiff = pContext->memPage.pMem - pNewMem;
    }

    for (i = 0; i < pContext->blockPage.top; ++i) {
        if (isNewMemAddrBehind == cosaBFalse) {
            pContext->blockPage.pBlocks[i].addr += newMemAddrDiff;
        } else {
            pContext->blockPage.pBlocks[i].addr -= newMemAddrDiff;
        }
    }

    pContext->memPage.pMem = pNewMem;
} 

void linuxInitializeCosaMD(cosaContext *pContext, _CosaMD *pCosaMD) {
    if (getrlimit(RLIMIT_NOFILE, &pCosaMD->systemInfo.maxFileDescs) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
}

cosaMemBlock *linuxCosaMemoryAlloc(cosaContext *pContext, cosaUSize count, cosaUSize byteSize) {
    cosaBool foundBlock = cosaBFalse;
    cosaUSize blockSlot;
    cosaUSize currentRegion;
    cosaUSize blockRegion = count * byteSize;
    for (blockSlot = 0; blockSlot < pContext->blockPage.top; ++blockSlot) {
        if (cosaRB(pContext->blockPage.pBlocks[blockSlot].flags) == COSA_MEM_FLAG_IS_FREE) {
            currentRegion = pContext->blockPage.pBlocks[blockSlot].count;
            currentRegion *= pContext->blockPage.pBlocks[blockSlot].byteSize;
            if (currentRegion >= blockRegion) {
                foundBlock = cosaBTrue;
                break;
            }
        }
    }
    if (foundBlock == cosaBTrue) {
        if (currentRegion > blockRegion) {
            if (pContext->blockPage.top >= pContext->blockPage.count) {
                _ExpandContextBlockPageRegion(pContext);
                if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
            }
            cosaUSize excessBlockSlot = pContext->blockPage.top;
            pContext->blockPage.pBlocks[excessBlockSlot].flags = 0x00;
            cosaCB(pContext->blockPage.pBlocks[excessBlockSlot].flags);

            pContext->blockPage.pBlocks[excessBlockSlot].byteSize = sizeof(cosaU8);
            pContext->blockPage.pBlocks[excessBlockSlot].count = currentRegion - blockRegion;
            pContext->blockPage.pBlocks[excessBlockSlot].addr = pContext->blockPage.pBlocks[blockSlot].addr + blockRegion;
            ++pContext->blockPage.top;
        }
        pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
        cosaSB(pContext->blockPage.pBlocks[blockSlot].flags);

        pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
        pContext->blockPage.pBlocks[blockSlot].count = count;
        return &pContext->blockPage.pBlocks[blockSlot];
    }

    if (pContext->blockPage.top >= pContext->blockPage.count) {
        _ExpandContextBlockPageRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    }
    blockSlot = pContext->blockPage.top;
    ++pContext->blockPage.top;

    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    cosaSB(pContext->blockPage.pBlocks[blockSlot].flags);

    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    pContext->blockPage.pBlocks[blockSlot].addr = pContext->memPage.pMem + pContext->memPage.top;

    if (pContext->memPage.top >= pContext->memPage.size) {
        _ExpandContextMemPageRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    }
    pContext->memPage.top += blockRegion;

    return &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaUSize top = (cosaUSize)pStack->addr[0];
    cosaUSize newTop = top + (itemSize + sizeof(cosaUSize));

    if (newTop > COSA_STACK_SIZE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pStackMem = (cosaU8*)(pStack->addr + sizeof(cosaUSize));
    pStackMem += top;

    (void)memcpy(pStackMem, pItem, itemSize);
    pStackMem += itemSize;

    (void)memcpy(pStackMem, &itemSize, sizeof(cosaUSize));
    (void)memcpy(pStack->addr, &newTop, sizeof(cosaUSize));
}

void *linuxCosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    cosaUSize *pTop = (cosaUSize*)pStack->addr;
    if (*pTop < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        if (pItemSize != NULL) { *pItemSize = 0; }
        return NULL;
    }
    cosaU8 *pStackMem = (cosaU8*)(pStack->addr + sizeof(cosaUSize));
    *pTop -= sizeof(cosaUSize);

    cosaUSize itemSize = 0;;
    (void)memcpy(&itemSize, pStackMem + *pTop, sizeof(cosaUSize));
    *pTop -= itemSize;

    if (pItemSize != NULL) { *pItemSize = itemSize; }
    return pStackMem + *pTop;
}

cosaMemBlock *linuxCosaCreateStack(cosaContext *pContext) {
    cosaMemBlock *pBlock = linuxCosaMemoryAlloc(pContext, COSA_STACK_SIZE + sizeof(cosaUSize), sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    return pBlock;
}

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pQueue->addr;
    cosaU8 *pQueueMem = (cosaU8*)(pQueue->addr + sizeof(cosaQueue_MD));

    (void)memcpy(pQueueMem + pQueue_MD->top, pItem, pQueue_MD->byteSize);
    pQueue_MD->top += pQueue_MD->byteSize;
    pQueue_MD->top %= (pQueue_MD->count * pQueue_MD->byteSize);
}

void *linuxCosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue) {
    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pQueue->addr;
    cosaU8 *pQueueMem = (cosaU8*)(pQueue->addr + sizeof(cosaQueue_MD));

    cosaUSize oldIndex = pQueue_MD->index;
    pQueue_MD->index += pQueue_MD->byteSize;
    pQueue_MD->index %= (pQueue_MD->count * pQueue_MD->byteSize);
    return pQueueMem + oldIndex;
}

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize) {
    cosaMemBlock *pBlock = linuxCosaMemoryAlloc(pContext, (count * byteSize) + sizeof(cosaQueue_MD), sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pBlock->addr;
    pQueue_MD->byteSize = byteSize;
    pQueue_MD->count = count;

    return pBlock;
}

cosaFile *linuxCosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]) {
    cosaFile *pFile = NULL;
    cosaU32 fileSlot;
    for (fileSlot = 0; fileSlot < pContext->filePage.count; ++fileSlot) {
        if (pContext->filePage.pFiles[fileSlot].desc == -1) {
            pFile = &pContext->filePage.pFiles[fileSlot];
            break;
        }
    }
    if (pFile == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return NULL;
    }
    cosaU8 fileFlags = cosaR3B(flags, 0);
    cosaI32 memFlags = cosaR2B(fileFlags, 0);

    pFile->desc = open(filePath, memFlags - 1);
    if (pFile->desc < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return NULL;
    }

    if (fstat(pFile->desc, &pFile->info) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    pFile->pMData = mmap(
        NULL, pFile->info.st_size,
        memFlags, COSA_MEM_FLAG_PVE,
        pFile->desc, 0);
    if (pFile->pMData == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    return pFile;
}

void linuxCosaFileClose(cosaContext *pContext, cosaFile *pFile) {
    cosaI32 errMem = munmap(pFile->pMData, pFile->info.st_size);
    cosaI32 err = close(pFile->desc);
    pFile->flags = 0x00;

    cosaU8 errFlg = 0x00;
    (errMem < 0) ? cosaSB(errFlg) : cosaCB(errFlg);
    (err < 0) ? cosaS1B(errFlg, 1) : cosaC1B(errFlg, 1);

    switch (errFlg) {
        case 0x03: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            break;
        }
        case 0x02: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->pMData = NULL;
            break;
        }
        case 0x01: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->desc = -1;
            break;
        }
        default: {
            pFile->pMData = NULL;
            pFile->desc = -1;
            break;
        }
    }
}

cosaPanel *linuxCosaCreatePanel(
    cosaContext *pContext,
    cosaU8 type,
    cosaI32 posX,
    cosaI32 posY,
    cosaU32 sizeX,
    cosaU32 sizeY,
    cosaU8 borderWidth,
    cosaU32 panelColor,
    cosaU32 borderColor,
    cosaChar *pTitle) {
        cosaPanel *pPanel = NULL;
        switch (type) {
            case 0: {
                cosaMemBlock *pBlock = linuxCosaMemoryAlloc(pContext, 1, sizeof(cosaPanel) + sizeof(cosaPanel_XLibMD));
                if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
                (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);
                pPanel = (cosaPanel*)pBlock->addr;
                pPanel->pBlock = pBlock;
                pPanel->type = type;
                pPanel->sizeX = sizeX;
                pPanel->sizeY = sizeY;
                pPanel->color = panelColor;
                pPanel->border = borderColor;
                pPanel->posX = posX;
                pPanel->posY = posY;
                cosaW8B(pPanel->border, 0, borderWidth);

                cosaPanel_XLibMD *pXlibMD = (cosaPanel_XLibMD*)(pBlock->addr + sizeof(cosaPanel_XLibMD));
                if ((pXlibMD->pDisplay = XOpenDisplay(NULL)) == NULL) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_LIBACC;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_LIBACC;
                    pBlock->flags = 0x00;
                    return NULL;
                }
                pXlibMD->pVisual = CopyFromParent;
                pXlibMD->screen = DefaultScreen(pXlibMD->pDisplay);
                pXlibMD->root = RootWindow(pXlibMD->pDisplay, pXlibMD->screen);
                pXlibMD->pGC = DefaultGC(pXlibMD->pDisplay, pXlibMD->screen);
                pXlibMD->attributeMask = CWEventMask | CWBackPixel | CWBorderPixel;
                pXlibMD->attributes.event_mask = ExposureMask | ButtonPressMask | KeyPressMask;
                pXlibMD->attributes.border_pixel     = 0x00FFFFFF & (borderColor >> 8);
                pXlibMD->attributes.background_pixel = 0x00FFFFFF & (panelColor >> 8);

                pXlibMD->window = XCreateWindow(
                    pXlibMD->pDisplay, pXlibMD->root,
                    posX, posY,
                    sizeX, sizeY,
                    borderWidth,
                    CopyFromParent,
                    InputOutput,
                    pXlibMD->pVisual,
                    pXlibMD->attributeMask, &pXlibMD->attributes);

                XSizeHints size_hints;
                size_hints.x = posX;
                size_hints.y = posY;
                size_hints.width = sizeX;
                size_hints.height = sizeY;
                size_hints.min_width = sizeX;
                size_hints.min_height = sizeY;
                size_hints.base_width = sizeX;
                size_hints.base_height = sizeY;
                size_hints.flags = USPosition | USSize | PMinSize | PBaseSize;
                XClassHint class_hints;
                class_hints.res_class = "NIGMA_COSA_XLIB_PANEL";
                class_hints.res_name = pTitle;
                XWMHints window_manager_hints;
                window_manager_hints.flags = InputHint | StateHint;
                window_manager_hints.initial_state = NormalState;
                window_manager_hints.input = True;

                XSetWMNormalHints(pXlibMD->pDisplay, pXlibMD->window, &size_hints);
                (void)XStoreName(pXlibMD->pDisplay, pXlibMD->window, pTitle);
                (void)XSetClassHint(pXlibMD->pDisplay, pXlibMD->window, &class_hints);
                (void)XSetWMHints(pXlibMD->pDisplay, pXlibMD->window, &window_manager_hints);

                (void)XMapWindow(pXlibMD->pDisplay, pXlibMD->window);
                (void)XSync(pXlibMD->pDisplay, False);
                break;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
                pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
                break;
            }
        }

        return pPanel;
}

void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
    switch (pPanel->type) {
        case 0: {
            cosaPanel_XLibMD *pXlibMD = (cosaPanel_XLibMD*)(pPanel->pBlock->addr + sizeof(cosaPanel_XLibMD));
            (void)XCloseDisplay(pXlibMD->pDisplay);
            break;
        }
        default: {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            break;
        }
    }
    pPanel->pBlock->flags = 0x00;
}
