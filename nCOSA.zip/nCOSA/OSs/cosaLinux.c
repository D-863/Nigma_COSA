#include "cosaLinux.h"
#include "../headers/error.h"

static cosaBool _CosaFindFreedBlock(cosaContext *pContext, cosaUSize *pBlockSlot, cosaUSize blockSize) {
    cosaBool foundSlot = cosaBFalse;
    cosaUSize freedSlot, freedSize, blockSlot = 0;
    for (freedSlot = 0; freedSlot < pContext->blockPage.freedTop; ++freedSlot) {
        blockSlot = pContext->blockPage.pFreed[freedSlot];
        freedSize = pContext->blockPage.pBlocks[blockSlot].count;
        freedSize *= pContext->blockPage.pBlocks[blockSlot].byteSize;
        if (freedSize >= blockSize) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBTrue) {
        cosaUSize i;
        for (i = blockSlot + 1; i < pContext->blockPage.freedTop; ++i) {
            pContext->blockPage.pFreed[i - 1] = pContext->blockPage.pFreed[i];
        }
        --pContext->blockPage.freedTop;
    }

    (*pBlockSlot) = blockSlot;
    return foundSlot;
}

static void _CosaAddFreedBlock(cosaContext *pContext, cosaUSize blockSlot) {
    pContext->blockPage.pFreed[pContext->blockPage.freedTop] = blockSlot;
    ++pContext->blockPage.freedTop;

    if (pContext->blockPage.freedTop >= pContext->blockPage.freedCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.freedCount);

        cosaUSize *pNewFreed = realloc(pContext->blockPage.pFreed, newCount * sizeof(cosaUSize));
        if (pNewFreed == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.freedTop;
            return;
        }
        (void)memset(pNewFreed + pContext->blockPage.freedCount, 0, (newCount - pContext->blockPage.freedCount) * sizeof(cosaUSize));
        pContext->blockPage.freedCount = newCount;
        pContext->blockPage.pFreed = pNewFreed;
    }
}

static void _CosaGetLinkBlock(cosaContext *pContext, cosaUSize *pLinkSlot) {
    (*pLinkSlot) = pContext->blockPage.linkTop;
    ++pContext->blockPage.linkTop;

    if (pContext->blockPage.linkTop >= pContext->blockPage.linkCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

        cosaLinkBlock *pNewLinks = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaLinkBlock));
        if (pNewLinks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewLinks + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaLinkBlock));
        pContext->blockPage.linkCount = newCount;
        pContext->blockPage.pLinks = pNewLinks;
    }
}

static void _CosaUpdateLinks(cosaContext *pContext, cosaMemBlock *pNewBuff) {
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
            (*pContext->blockPage.pLinks[i].ppBlockLink) = &pNewBuff[pContext->blockPage.pLinks[i].blockSlot];
        }
    }
}

static void _CosaRemoveLinkBlock(cosaContext *pContext, cosaUSize linkSlot) {
    if (pContext->blockPage.pLinks[linkSlot].ppBlockLink != NULL) { (*pContext->blockPage.pLinks[linkSlot].ppBlockLink) = NULL; }

    --pContext->blockPage.linkTop;
    if (pContext->blockPage.linkTop > 0) {
        if (linkSlot != pContext->blockPage.linkTop) {
            pContext->blockPage.pLinks[linkSlot].blockSlot = pContext->blockPage.pLinks[pContext->blockPage.linkTop].blockSlot;
            pContext->blockPage.pLinks[linkSlot].ppBlockLink = pContext->blockPage.pLinks[pContext->blockPage.linkTop].ppBlockLink;
        }
    }
}

static void _CosaGetBlockMD(cosaContext *pContext, cosaUSize *pBlockSlot) {
    (*pBlockSlot) = pContext->blockPage.blockTop;
    ++pContext->blockPage.blockTop;

    if (pContext->blockPage.blockTop >= pContext->blockPage.blockCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

        cosaMemBlock *pNewBlocks = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
        if (pNewBlocks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewBlocks + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
        pContext->blockPage.blockCount = newCount;

        if (pNewBlocks != pContext->blockPage.pBlocks) { _CosaUpdateLinks(pContext, pNewBlocks); }
        pContext->blockPage.pBlocks = pNewBlocks;
    }
}

static void _CosaGetFileBlock(cosaContext *pContext, cosaFile **ppFile) {
    //Will be updated in the future, but for now this is good enough.
    if (pContext->filePage.fileTop >= pContext->filePage.fileCount) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
        return;
    }
    (*ppFile) = &pContext->filePage.pFiles[pContext->filePage.fileTop];
    ++pContext->filePage.fileTop;
}

static void _CosaGetFInfoBlock(cosaContext *pContext, cosaFile **ppFile) {
    //Will be updated in the future, but for now this is good enough.
    (*ppFile)->finfoID = pContext->filePage.finfoTop;
    ++pContext->filePage.finfoTop;

    if (pContext->filePage.finfoTop >= pContext->filePage.finfoCount) {
        cosaUSize newCount = COSA_FINFO_EXPAND(pContext->filePage.finfoCount);

        cosaFInfo *pNewFInfos = realloc(pContext->filePage.pFInfos, newCount * sizeof(cosaFInfo));
        if (pNewFInfos == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->filePage.finfoTop;
            return;
        }
        (void)memset(pNewFInfos + pContext->filePage.finfoCount, 0, (newCount - pContext->filePage.finfoCount) * sizeof(cosaFInfo));
        pContext->filePage.finfoCount = newCount;
        pContext->filePage.pFInfos = pNewFInfos;
    }
}

static void _CosaLoadFinfoFromFile(cosaContext *pContext, cosaFile **ppFile) {
    _Cosa_FileStat fileStat;
    if (fstat((*ppFile)->desc, &fileStat) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    cosaFInfo *pFInfo = &pContext->filePage.pFInfos[(*ppFile)->finfoID];
    pFInfo->UID    = fileStat.st_uid;
    pFInfo->GID    = fileStat.st_gid;
    pFInfo->size   = fileStat.st_size;
    pFInfo->aTime  = fileStat.st_atime;
    pFInfo->mTime  = fileStat.st_mtime;
    pFInfo->scTime = fileStat.st_ctime;
    pFInfo->perm  = ((fileStat.st_mode & S_IRUSR) == S_IRUSR) ? COSA_FILE_INFO_UPRM_RD  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IWUSR) == S_IWUSR) ? COSA_FILE_INFO_UPRM_WE  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IXUSR) == S_IXUSR) ? COSA_FILE_INFO_UPRM_EX  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IRGRP) == S_IRGRP) ? COSA_FILE_INFO_GPRM_RD  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IWGRP) == S_IWGRP) ? COSA_FILE_INFO_GPRM_WE  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IXGRP) == S_IXGRP) ? COSA_FILE_INFO_GPRM_EX  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IROTH) == S_IROTH) ? COSA_FILE_INFO_OPRM_RD  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IWOTH) == S_IWOTH) ? COSA_FILE_INFO_OPRM_WE  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_IXOTH) == S_IXOTH) ? COSA_FILE_INFO_OPRM_EX  : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_ISUID) == S_ISUID) ? COSA_FILE_INFO_SPRM_UID : 0x0000;
    pFInfo->perm |= ((fileStat.st_mode & S_ISGID) == S_ISGID) ? COSA_FILE_INFO_SPRM_GID : 0x0000;

    (*ppFile)->flags |= (S_ISDIR(fileStat.st_mode) | (S_ISLNK(fileStat.st_mode) << 1)) << 2;
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    //Unlikely yet possible malloc error.
    cosaUSize blockSize = count * byteSize;
    if (cosaCUnlikely(blockSize > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }

    //Is there usuable freed blocks? Otherwise, get a fresh one.
    cosaUSize blockSlot = 0;
    cosaBool foundSlot = _CosaFindFreedBlock(pContext, &blockSlot, blockSize);
    if (foundSlot == cosaBFalse) {
        _CosaGetBlockMD(pContext, &blockSlot);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }

    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->blockPage.pBlocks[blockSlot].addr = malloc(blockSize);

        if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            return;
        }
    }

    //Get a linkBlock slot and set it.
    cosaUSize linkSlot = 0;
    _CosaGetLinkBlock(pContext, &linkSlot);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        free(pContext->blockPage.pBlocks[blockSlot].addr);
        pContext->blockPage.pBlocks[blockSlot].addr = NULL;
        return;
    }
    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;

    //Give the newly created block's address.
    (*ppBlock) = &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    cosaUSize newSize = count * byteSize;
    cosaUSize oldSize = pBlock->count * pBlock->byteSize;
    if (oldSize > newSize) { return; }

    cosaU8 *pNewAddr = realloc(pBlock->addr, newSize);
    if (pNewAddr == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewAddr + oldSize, 0, newSize - oldSize);
    pBlock->byteSize = byteSize;
    pBlock->count = count;
    pBlock->addr = pNewAddr;
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    cosaUSize blockSlot = pBlock - pContext->blockPage.pBlocks;
    if (blockSlot > pContext->blockPage.blockTop) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }

    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].blockSlot == blockSlot) {
            _CosaRemoveLinkBlock(pContext, i);
            break;
        }
    }
    _CosaAddFreedBlock(pContext, blockSlot);
}

void linuxCosaStackXSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)pStack->addr;

    cosaUSize offset = pStackMD->top * pStackMD->bSize;
    cosaUSize size = pStack->count - sizeof(cosaStackMD_XS);

    if (offset >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_DS: {
                size += offset - size;
                size += COSA_STACK_XS_EXPAND * pStackMD->bSize;

                linuxCosaExpandBlock(pContext, pStack, size + sizeof(cosaStackMD_XS), sizeof(cosaU8));
                if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

                pStackMD = (cosaStackMD_XS*)pStack->addr;
                break;
            }
            case COSA_STACK_TYPE_SS: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                return;
            }
        }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, sizeof(cosaStackMD_XS));
    (void)memcpy(pMem + offset, pItem, pStackMD->bSize);
    ++pStackMD->top;
}

void linuxCosaStackXDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaStackMD_XD *pStackMD = (cosaStackMD_XD*)pStack->addr;

    cosaU32 newTop = pStackMD->top + itemSize + sizeof(itemSize);
    cosaUSize size = pStack->count - sizeof(cosaStackMD_XD);

    if (newTop >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_DD: {
                size += newTop - size;
                size += COSA_STACK_XD_EXPAND * COSA_STACK_XS_EXPAND;

                linuxCosaExpandBlock(pContext, pStack, size + sizeof(cosaStackMD_XD), sizeof(cosaU8));
                if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

                pStackMD = (cosaStackMD_XD*)pStack->addr;
                break;
            }
            case COSA_STACK_TYPE_SD: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                return;
            }
        }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, sizeof(cosaStackMD_XD));

    (void)memcpy(pMem + pStackMD->top, pItem, itemSize);
    (void)memcpy(pMem + pStackMD->top + itemSize, &itemSize, sizeof(itemSize));
    pStackMD->top = newTop;
}

void linuxCosaStackXBPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemCount) {
    cosaStackMD_XB *pStackMD = (cosaStackMD_XB*)pStack->addr;
    cosaU8 *pFlags = cosaStackMD_XB_Flags(pStack);
    cosaU32 *pBSizes = cosaStackMD_XB_BSizes(pStack, pStackMD);

    cosaBool isDynamic = cosaBTrue;
    cosaU8 indexFByte = (cosaU8)(pStackMD->bSizeIndex/8);
    if ((indexFByte > (pStackMD->flagCount - 1)) == cosaBFalse) {
        isDynamic = (cosaBool)cosaR1B(pFlags[indexFByte] >> (pStackMD->bSizeIndex % 8));
    }

    cosaU8 bSizeType = 0;
    cosaUSize newTop = pStackMD->top + (pBSizes[pStackMD->bSizeIndex] * itemCount);
    if (isDynamic == cosaBTrue) {
        newTop += sizeof(cosaU8);
        if (256 > itemCount) {
            bSizeType = 1;
            newTop += sizeof(cosaU8);
        } else if (65536 > itemCount) {
            bSizeType = 2;
            newTop += sizeof(cosaU16);
        } else if (4294967296 > itemCount) {
            bSizeType = 3;
            newTop += sizeof(cosaU32);
        } else {
            bSizeType = 4;
            newTop += sizeof(cosaUSize);
        }
    }

    cosaUSize sizeStackMD = COSA_STACK_SIZE_XB(pStackMD);
    cosaUSize size = pStack->count - sizeStackMD;

    if (newTop >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_DB: {
                cosaUSize totalBSize = 0;
                for (cosaU8 i = 0; i < pStackMD->bSizeCount; ++i) { totalBSize += pBSizes[i]; }

                size += newTop - size;
                size += COSA_STACK_XB_EXPAND * totalBSize;

                linuxCosaExpandBlock(pContext, pStack, size + sizeStackMD, sizeof(cosaU8));
                if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

                pStackMD = (cosaStackMD_XB*)pStack->addr;
                pFlags = cosaStackMD_XB_Flags(pStack);
                pBSizes = cosaStackMD_XB_BSizes(pStack, pStackMD);
                break;
            }
            case COSA_STACK_TYPE_SB: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                return;
            }
        }
    }

    cosaU8 *pMem = cosaStackMD_Mem(pStack, sizeStackMD);
    switch (bSizeType) {
        case 1: {
            (void)memcpy(pMem + pStackMD->top, pItem, pBSizes[pStackMD->bSizeIndex] * itemCount);

            (void)memcpy(pMem + (newTop - (sizeof(cosaU8) + sizeof(cosaU8))), &itemCount, sizeof(cosaU8));
            (void)memcpy(pMem + (newTop - sizeof(cosaU8)), &bSizeType, sizeof(cosaU8));
            break;
        }
        case 2: {
            (void)memcpy(pMem + pStackMD->top, pItem, pBSizes[pStackMD->bSizeIndex] * itemCount);

            (void)memcpy(pMem + (newTop - (sizeof(cosaU8) + sizeof(cosaU16))), &itemCount, sizeof(cosaU16));
            (void)memcpy(pMem + (newTop - sizeof(cosaU8)), &bSizeType, sizeof(cosaU8));
            break;
        }
        case 3: {
            (void)memcpy(pMem + pStackMD->top, pItem, pBSizes[pStackMD->bSizeIndex] * itemCount);

            (void)memcpy(pMem + (newTop - (sizeof(cosaU8) + sizeof(cosaU32))), &itemCount, sizeof(cosaU32));
            (void)memcpy(pMem + (newTop - sizeof(cosaU8)), &bSizeType, sizeof(cosaU8));
            break;
        }
        case 4: {
            (void)memcpy(pMem + pStackMD->top, pItem, pBSizes[pStackMD->bSizeIndex] * itemCount);

            (void)memcpy(pMem + (newTop - (sizeof(cosaU8) + sizeof(cosaUSize))), &itemCount, sizeof(cosaUSize));
            (void)memcpy(pMem + (newTop - sizeof(cosaU8)), &bSizeType, sizeof(cosaU8));
            break;
        }
        default: {
            (void)memcpy(pMem + pStackMD->top, pItem, pBSizes[pStackMD->bSizeIndex]);
            break;
        }
    }
    pStackMD->top = newTop;

    ++pStackMD->bSizeIndex;
    pStackMD->bSizeIndex %= pStackMD->bSizeCount;
}

void *linuxCosaStackXSPop(cosaContext *pContext, cosaMemBlock *pStack) {
    cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)pStack->addr;

    if (pStackMD->top < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, sizeof(cosaStackMD_XS));
    --pStackMD->top;

    return pMem + (pStackMD->top * pStackMD->bSize);
}

void *linuxCosaStackXDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    cosaStackMD_XD *pStackMD = (cosaStackMD_XD*)pStack->addr;

    if (pStackMD->top < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    pStackMD->top -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, sizeof(cosaStackMD_XD));
    cosaUSize itemSize = *((cosaUSize*)(pMem + pStackMD->top));

    if (pItemSize != NULL) { (*pItemSize) = itemSize; }
    pStackMD->top -= itemSize;

    return pMem + pStackMD->top;
}

void *linuxCosaStackXBPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    cosaStackMD_XB *pStackMD = (cosaStackMD_XB*)pStack->addr;

    if (pStackMD->top < (sizeof(cosaU8) + sizeof(cosaU8) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }

    if (pStackMD->bSizeIndex == 0) {
        pStackMD->bSizeIndex = pStackMD->bSizeCount;
    } else {
        --pStackMD->bSizeIndex;
    }
    cosaU8 *pFlags = cosaStackMD_XB_Flags(pStack);

    cosaBool isDynamic = cosaBTrue;
    cosaU8 indexFByte = (cosaU8)(pStackMD->bSizeIndex/8);
    if ((indexFByte > (pStackMD->flagCount - 1)) == cosaBFalse) {
        isDynamic = (cosaBool)cosaR1B(pFlags[indexFByte] >> (pStackMD->bSizeIndex % 8));
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_XB(pStackMD));

    cosaUSize itemCount = 1;
    if (isDynamic == cosaBTrue) {
        pStackMD->top -= sizeof(cosaU8);
        cosaU8 bSizeType = *((cosaU8*)(pMem + pStackMD->top));

        switch (bSizeType) {
            case 1: {
                pStackMD->top -= sizeof(cosaU8);
                itemCount = *((cosaU8*)(pMem + pStackMD->top));
                break;
            }
            case 2: {
                pStackMD->top -= sizeof(cosaU16);
                itemCount = *((cosaU16*)(pMem + pStackMD->top));
                break;
            }
            case 3: {
                pStackMD->top -= sizeof(cosaU32);
                itemCount = *((cosaU32*)(pMem + pStackMD->top));
                break;
            }
            case 4: {
                pStackMD->top -= sizeof(cosaUSize);
                itemCount = *((cosaUSize*)(pMem + pStackMD->top));
                break;
            }
        }
    }
    cosaU32 *pBSizes = cosaStackMD_XB_BSizes(pStack, pStackMD);

    cosaUSize itemSize = pBSizes[pStackMD->bSizeIndex] * itemCount;
    if (pItemSize != NULL) { (*pItemSize) = itemSize; }

    pStackMD->top -= itemSize;
    return pMem + pStackMD->top;
}

//StackSS - Static Stack Static Typed.
void linuxCosaCreateStackSS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize) {
    linuxCosaCreateBlock(
        pContext, ppBlock,
        (count * byteSize) + sizeof(cosaStackMD_XS),
        sizeof(cosaU8)
    );
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, sizeof(cosaStackMD_XS));

    cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)(*ppBlock)->addr;
    pStackMD->type = COSA_STACK_TYPE_SS;
    pStackMD->bSize = byteSize;
}

//StackDS - Dynamic Stack Static Typed.
void linuxCosaCreateStackDS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize) {
    linuxCosaCreateBlock(
        pContext, ppBlock,
        (count * byteSize) + sizeof(cosaStackMD_XS),
        sizeof(cosaU8)
    );
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, sizeof(cosaStackMD_XS));

    cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)(*ppBlock)->addr;
    pStackMD->type = COSA_STACK_TYPE_DS;
    pStackMD->bSize = byteSize;
}

//StackSD - Static Stack Dynamic Typed.
void linuxCosaCreateStackSD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size) {
    linuxCosaCreateBlock(
        pContext, ppBlock,
        size + sizeof(cosaStackMD_XD),
        sizeof(cosaU8)
    );
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, sizeof(cosaStackMD_XD));

    cosaStackMD_XD *pStackMD = (cosaStackMD_XD*)(*ppBlock)->addr;
    pStackMD->type = COSA_STACK_TYPE_SD;
}

//StackDD - Dynamic Stack Dynamic Typed.
void linuxCosaCreateStackDD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size) {
    linuxCosaCreateBlock(
        pContext, ppBlock,
        size + sizeof(cosaStackMD_XD),
        sizeof(cosaU8)
    );
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, sizeof(cosaStackMD_XD));

    cosaStackMD_XD *pStackMD = (cosaStackMD_XD*)(*ppBlock)->addr;
    pStackMD->type = COSA_STACK_TYPE_DD;
}

//StackSS - Static Stack Blueprinted Typed.
void linuxCosaCreateStackSB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes) {
    cosaUSize sizeFlags = sizeof(cosaU8) * flagCount;
    cosaUSize sizeBSizes = sizeof(cosaU32) * bSizeCount;

    linuxCosaCreateBlock(
        pContext, ppBlock,
        size + sizeBSizes + sizeFlags + sizeof(cosaStackMD_XB),
        sizeof(cosaU8)
    );
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, sizeof(cosaStackMD_XB));
    (void)memcpy((*ppBlock)->addr + sizeof(cosaStackMD_XB), pFlags, sizeFlags);
    (void)memcpy((*ppBlock)->addr + sizeof(cosaStackMD_XB) + sizeFlags, pBSizes, sizeBSizes);

    cosaStackMD_XB *pStackMD = (cosaStackMD_XB*)(*ppBlock)->addr;
    pStackMD->type = COSA_STACK_TYPE_SB;
    pStackMD->flagCount = flagCount;
    pStackMD->bSizeCount = bSizeCount;
}

//StackSS - Dynamic Stack Blueprinted Typed.
void linuxCosaCreateStackDB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes) {
    cosaUSize sizeFlags = sizeof(cosaU8) * flagCount;
    cosaUSize sizeBSizes = sizeof(cosaU32) * bSizeCount;

    linuxCosaCreateBlock(
        pContext, ppBlock,
        size + sizeBSizes + sizeFlags + sizeof(cosaStackMD_XB),
        sizeof(cosaU8)
    );
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, sizeof(cosaStackMD_XB));
    (void)memcpy((*ppBlock)->addr + sizeof(cosaStackMD_XB), pFlags, sizeFlags);
    (void)memcpy((*ppBlock)->addr + sizeof(cosaStackMD_XB) + sizeFlags, pBSizes, sizeBSizes);

    cosaStackMD_XB *pStackMD = (cosaStackMD_XB*)(*ppBlock)->addr;
    pStackMD->type = COSA_STACK_TYPE_DB;
    pStackMD->flagCount = flagCount;
    pStackMD->bSizeCount = bSizeCount;
}

void linuxCosaStackSSRemove(cosaContext *pContext, cosaMemBlock *pStack, cosaU32 itemIndex) {
    cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)pStack->addr;

    if ((pStackMD->top < 1) | (itemIndex >= pStackMD->top)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    } else if (itemIndex == (pStackMD->top - 1)) {
        (void)linuxCosaStackXSPop(pContext, pStack);
        return;
    }
    cosaMemBlock *pSTMP = NULL;
    linuxCosaCreateStackSS(pContext, &pSTMP, (pStackMD->top - itemIndex) - 1, pStackMD->bSize);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaU32 i;
    for (i = 0; i < (pStackMD->top - itemIndex); ++i) {
        void *pAddr = linuxCosaStackXSPop(pContext, pStack);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        if ((pStackMD->top - i) != itemIndex) {
            linuxCosaStackXSPush(pContext, pSTMP, pAddr);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        }
    }

    for (i = 0; i < (pStackMD->top - itemIndex) - 1; ++i) {
        void *pAddr = linuxCosaStackXSPop(pContext, pSTMP);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        linuxCosaStackXSPush(pContext, pStack, pAddr);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }

    linuxCosaDestroyBlock(pContext, pSTMP);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
}

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pBack = cosaQueueMD_Back(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((size - ((*pCount) * bSize)) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }

    cosaU8 *pMem = cosaQueueMD_Mem(pQueue);
    (void)memcpy(pMem + (*pBack), pItem, bSize);
    (*pBack) = ((*pBack) + bSize) % size;
    ++(*pCount);
}

void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pFront = cosaQueueMD_Front(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((*pCount) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaQueueMD_Mem(pQueue) + (*pFront);
    (*pFront) = ((*pFront) + bSize) % size;
    --(*pCount);
    return pMem;
}

void linuxCosaCreateQueue(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize) {
    linuxCosaCreateBlock(pContext, ppBlock, (count * byteSize) + COSA_QUEUE_SIZE, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    (void)memset((*ppBlock)->addr, 0, (*ppBlock)->count * (*ppBlock)->byteSize);

    (*cosaQueueMD_BSize(*ppBlock)) = byteSize;
}

cosaFile *linuxCosaCreateFile(cosaContext *pContext, cosaU16 flags, cosaChar dirPath[], cosaChar fileName[]) {
    cosaFile *pFile = NULL;
    _CosaGetFileBlock(pContext, &pFile);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }

    pFile->flags = (flags & 0xF) | COSA_FILE_FLAG_PERM_WE;
    cosaI32 permFlags = O_CREAT;
    switch (cosaR2B(pFile->flags)) {
        case 0x01: {
            permFlags |= O_WRONLY;
            break;
        }
        case 0x02: {
            permFlags |= O_RDONLY;
            break;
        }
        case 0x03: {
            permFlags |= O_RDWR;
            break;
        }
    }

    cosaI32 modeFlags = 0x00;
    switch (cosaR3B(flags >> 4)) {
        case 0x01: {
            modeFlags |= S_IXUSR;
            break;
        }
        case 0x02: {
            modeFlags |= S_IWUSR;
            break;
        }
        case 0x03: {
            modeFlags |= S_IWUSR;
            modeFlags |= S_IXUSR;
            break;
        }
        case 0x04: {
            modeFlags |= S_IRUSR;
            break;
        }
        case 0x05: {
            modeFlags |= S_IRUSR;
            modeFlags |= S_IXUSR;
            break;
        }
        case 0x06: {
            modeFlags |= S_IRUSR;
            modeFlags |= S_IWUSR;
            break;
        }
        case 0x07: {
            modeFlags |= S_IRWXU;
            break;
        }
    }
    switch (cosaR3B(flags >> 7)) {
        case 0x01: {
            modeFlags |= S_IXGRP;
            break;
        }
        case 0x02: {
            modeFlags |= S_IWGRP;
            break;
        }
        case 0x03: {
            modeFlags |= S_IWGRP;
            modeFlags |= S_IXGRP;
            break;
        }
        case 0x04: {
            modeFlags |= S_IRGRP;
            break;
        }
        case 0x05: {
            modeFlags |= S_IRGRP;
            modeFlags |= S_IXGRP;
            break;
        }
        case 0x06: {
            modeFlags |= S_IRGRP;
            modeFlags |= S_IWGRP;
            break;
        }
        case 0x07: {
            modeFlags |= S_IRWXG;
            break;
        }
    }
    switch (cosaR3B(flags >> 10)) {
        case 0x01: {
            modeFlags |= S_IXOTH;
            break;
        }
        case 0x02: {
            modeFlags |= S_IWOTH;
            break;
        }
        case 0x03: {
            modeFlags |= S_IWOTH;
            modeFlags |= S_IXOTH;
            break;
        }
        case 0x04: {
            modeFlags |= S_IROTH;
            break;
        }
        case 0x05: {
            modeFlags |= S_IROTH;
            modeFlags |= S_IXOTH;
            break;
        }
        case 0x06: {
            modeFlags |= S_IROTH;
            modeFlags |= S_IWOTH;
            break;
        }
        case 0x07: {
            modeFlags |= S_IRWXO;
            break;
        }
    }
    switch (cosaR2B(flags >> 13)) {
        case 0x01: {
            modeFlags |= S_ISUID;
            break;
        }
        case 0x02: {
            modeFlags |= S_ISGID;
            break;
        }
        case 0x03: {
            modeFlags |= S_ISUID;
            modeFlags |= S_ISGID;
            break;
        }
    }

    pFile->desc = open(filePath, permFlags, modeFlags);
    if (pFile->desc < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return NULL;
    }

    if (fstat(pFile->desc, &pFile->info) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    if (pFile->info.st_size < COSA_FILE_SIZE_THRESHOLD_A) {
        linuxCosaCreateStackDS();
    } else if (pFile->info.st_size < COSA_FILE_SIZE_THRESHOLD_B) {
    }
    linuxCosaCreateBlock(pContext, &pFile->pBData, pFile->info.st_size, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    return pFile;
}

cosaFile *linuxCosaOpenFile(cosaContext *pContext, cosaU8 flags, cosaChar path[]) {
    cosaFile *pFile = NULL;
    _CosaGetFileBlock(pContext, &pFile);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }

    _CosaGetFInfoBlock(pContext, &pFile);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    pContext->filePage.pFInfos[pFile->finfoID].pPath = path;
    pFile->flags = flags & 0xF;

    cosaI32 fileFlags = 0x00;
    switch (cosaR2B(pFile->flags)) {
        case 0x01: {
            fileFlags |= O_WRONLY;
            break;
        }
        case 0x02: {
            fileFlags |= O_RDONLY;
            break;
        }
        case 0x03: {
            fileFlags |= O_RDWR;
            break;
        }
    }
    pFile->desc = open(path, fileFlags, 0x00);
    if (pFile->desc < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return NULL;
    }

    _CosaLoadFinfoFromFile(pContext, &pFile);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
}

void linuxCosaFileWrite() {
}

void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]) {
    cosaUSize pathLength = strlen(filePath);

    cosaBool foundType = cosaBFalse;
    cosaChar imageTypes[COSA_IMAGE_TYPE_COUNT][COSA_IMAGE_TYPE_LENGTH] = COSA_IMAGE_TYPES;
    for (cosaU8 i = 0; i < COSA_IMAGE_TYPE_COUNT; ++i) {
        if (strncmp(filePath + (pathLength - COSA_IMAGE_TYPE_LENGTH), imageTypes[i], COSA_IMAGE_TYPE_LENGTH) == 0) {
            pImage->type = i;
            foundType = cosaBTrue;
            break;
        }
    }
    if (foundType == cosaBFalse) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
        return;
    }
    pImage->pFile = linuxCosaOpenFile(pContext, COSA_FILE_FLAG_PERM_RD, filePath);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaI32 w = 0;
    cosaI32 h = 0;
    cosaI32 c = 0;
    pImage->pData = stbi_load_from_memory(pImage->pFile->pMData, pImage->pFile->info.st_size, &w, &h, &c, 0);
    if (pImage->pData == NULL) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
        return;
    } else if ((w < 1) || (h < 1) || (c < 1)) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
        return;
    }
    pImage->width    = COSA_MACRO_SIGNED_TO_UNSIGNED(w);
    pImage->height   = COSA_MACRO_SIGNED_TO_UNSIGNED(h);
    pImage->channels = COSA_MACRO_SIGNED_TO_UNSIGNED(c);
}

void linuxCosaCloseFile(cosaContext *pContext, cosaFile *pFile) {
    cosaI32 errMem = munmap(pFile->pMData, pFile->info.st_size);
    cosaI32 err = close(pFile->desc);
    pFile->flags = 0x00;

    cosaU8 errFlg = 0x00;
    (errMem < 0) ? cosaS1B(errFlg) : cosaC1B(errFlg);
    (err < 0) ? cosaS1B_O(errFlg, 1) : cosaC1B_O(errFlg, 1);

    switch (errFlg) {
        case 0x03: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            break;
        }
        case 0x02: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->pMData = NULL;
            break;
        }
        case 0x01: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->desc = -1;
            break;
        }
        default: {
            pFile->pMData = NULL;
            pFile->desc = -1;
            break;
        }
    }
}

void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage) {
    if (pImage->pData != NULL) {
        stbi_image_free(pImage->pData);
        pImage->pData = NULL;
        pImage->width = 0;
        pImage->height = 0;
        pImage->channels = 0;
    }
    if (pImage->pFile != NULL) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
            pImage->pFile = NULL;
            pImage->type = 0;
        }
    }
}

void linuxCosaInitContext(cosaContext *pContext) {
    pContext->blockPage.blockCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pBlocks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));
    if (pContext->blockPage.pBlocks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pContext->blockPage.pBlocks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));

    pContext->blockPage.freedCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pFreed = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaUSize));
    if (pContext->blockPage.pFreed == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->blockPage.pFreed, 0, COSA_PAGE_BLOCK_START * sizeof(cosaUSize));

    pContext->blockPage.linkCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pLinks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));
    if (pContext->blockPage.pLinks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->blockPage.pLinks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));


    pContext->pCosaMD = malloc(sizeof(_CosaMD));
    if (pContext->pCosaMD == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->pCosaMD, 0, sizeof(_CosaMD));

    cosaU16 isBigEndian = 0x0001;
    pContext->pCosaMD->systemInfo.isBigEndian = cosaIsEndianBig(isBigEndian);

    if (getrlimit(RLIMIT_NOFILE, &pContext->pCosaMD->systemInfo.maxFDs) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->pCosaMD);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->pCosaMD = NULL;
        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }


    pContext->filePage.count = COSA_FILE_DESCS_MIN;
    pContext->filePage.top = 0;
    if ((pContext->filePage.count == 0) || (pContext->pCosaMD->systemInfo.maxFDs.rlim_cur < pContext->filePage.count)) {
        pContext->filePage.count = pContext->pCosaMD->systemInfo.maxFDs.rlim_cur;
    }

    pContext->filePage.pFiles = malloc(pContext->filePage.count * sizeof(cosaFile));
    if (pContext->filePage.pFiles == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->pCosaMD);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->pCosaMD = NULL;
        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->filePage.pFiles, 0, pContext->filePage.count * sizeof(cosaFile));
    for (cosaU32 i = 0; i < pContext->filePage.count; ++i) {
        pContext->filePage.pFiles[i].desc = -1;
    }
}

void linuxCosaDestroyContext(cosaContext *pContext) {
    if (pContext->filePage.pFiles != NULL) {
        free(pContext->filePage.pFiles);
        pContext->filePage.pFiles = NULL;
    }

    if (pContext->pCosaMD != NULL) {
        free(pContext->pCosaMD);
        pContext->pCosaMD = NULL;
    }

    if (pContext->blockPage.pBlocks != NULL) {
        for (cosaUSize i = 0; i < pContext->blockPage.blockTop; ++i) {
            free(pContext->blockPage.pBlocks[i].addr);
            pContext->blockPage.pBlocks[i].addr = NULL;
        }
        free(pContext->blockPage.pBlocks);
        pContext->blockPage.pBlocks = NULL;
    }

    if (pContext->blockPage.pLinks != NULL) {
        for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
            if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
                (*pContext->blockPage.pLinks[i].ppBlockLink) = NULL;
            }
            pContext->blockPage.pLinks[i].ppBlockLink = NULL;
        }
        free(pContext->blockPage.pLinks);
        pContext->blockPage.pLinks = NULL;
    }

    free(pContext->blockPage.pFreed);
    pContext->blockPage.pFreed = NULL;
    _InitContext(pContext);
}


#if defined(COSA_ENABLE_EXTENSIONS)
    static cosaU32 _CosaExtensionFind(cosaContext *pContext, cosaU32 extensionID) {
        cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)pContext->pCosaMD->pSExtensions->addr;

        if (pStackMD->top == 0) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
            return 0;
        }
        _CosaExtension *pMem = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));

        cosaBool foundSlot = cosaBFalse;
        cosaU32 extensionSlot;
        for (extensionSlot = 0; extensionSlot < pStackMD->top; ++extensionSlot) {
            if (pMem[extensionSlot].ID == extensionID) {
                foundSlot = cosaBTrue;
                break;
            }
        }
        if (foundSlot == cosaBFalse) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
        }
        return extensionSlot;
    }

    static cosaU32 _CosaExtensionCreate(cosaContext *pContext) {
        _CosaExtension extensionMD = {0};
        cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)pContext->pCosaMD->pSExtensions->addr;

        cosaU32 extID = pStackMD->top;
        linuxCosaStackXSPush(pContext, pContext->pCosaMD->pSExtensions, &extensionMD);

        return extID;
    }

    static void _CosaExtensionRemove(cosaContext *pContext, cosaU32 extensionSlot) {
        cosaStackMD_XS *pStackMD = (cosaStackMD_XS*)pContext->pCosaMD->pSExtensions->addr;

        if ((pStackMD->top == 0) || (extensionSlot > (pStackMD->top - 1))) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
            return;
        }
        _CosaExtension *pMem = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
        _CosaExtension *pExt = linuxCosaStackXSPop(pContext, pContext->pCosaMD->pSExtensions);
        if (pMem[extensionSlot].ID != pExt->ID) {
            pMem[extensionSlot].ID       = pExt->ID;
            pMem[extensionSlot].pBlock   = pExt->pBlock;
            pMem[extensionSlot].pCleanup = pExt->pCleanup;
        }
    }

    void linuxCosaInitExtensions(cosaContext *pContext) {
        if ((COSA_EXTENSION_COUNT == 0) || (COSA_EXTENSION_COUNT > 255)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }
        linuxCosaCreateStackSS(pContext, &pContext->pCosaMD->pSExtensions, COSA_EXTENSION_COUNT, sizeof(_CosaExtension));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    /*Bitpos(9b).
        GLFW_KEY:
            #byte:0;2
            SPACE          32      0001 00000 0  - 0  = 0
            APOSTROPHE     39      0001 00111 7  - 6  = 1
            COMMA          44      0001 01100 12 - 10 = 2
            MINUS          45      0001 01101 13 - 10 = 3
            PERIOD         46      0001 01110 14 - 10 = 4
            SLASH          47      0001 01111 15 - 10 = 5
            0              48      0001 10000 16 - 10 = 6
            1              49      0001 10001 17 - 10 = 7
            2              50      0001 10010 18 - 10 = 8
            3              51      0001 10011 19 - 10 = 9
            4              52      0001 10100 20 - 10 = 10
            5              53      0001 10101 21 - 10 = 11
            6              54      0001 10110 22 - 10 = 12
            7              55      0001 10111 23 - 10 = 13
            8              56      0001 11000 24 - 10 = 14
            9              57      0001 11001 25 - 10 = 15

            #byte:2;4
            GRAVE_ACCENT   96      0011 00000 0
            WORLD_1        161     0101 00001 1
            WORLD_2        162     0101 00010 2
            A              65      0010 00001 1  + 2 = 3
            B              66      0010 00010 2  + 2 = 4
            C              67      0010 00011 3  + 2 = 5
            D              68      0010 00100 4  + 2 = 6
            E              69      0010 00101 5  + 2 = 7
            F              70      0010 00110 6  + 2 = 8
            G              71      0010 00111 7  + 2 = 9
            H              72      0010 01000 8  + 2 = 10
            I              73      0010 01001 9  + 2 = 11
            J              74      0010 01010 10 + 2 = 12
            K              75      0010 01011 11 + 2 = 13
            L              76      0010 01100 12 + 2 = 14
            M              77      0010 01101 13 + 2 = 15
            N              78      0010 01110 14 + 2 = 16
            O              79      0010 01111 15 + 2 = 17
            P              80      0010 10000 16 + 2 = 18
            Q              81      0010 10001 17 + 2 = 19
            R              82      0010 10010 18 + 2 = 20
            S              83      0010 10011 19 + 2 = 21
            T              84      0010 10100 20 + 2 = 22
            U              85      0010 10101 21 + 2 = 23
            V              86      0010 10110 22 + 2 = 24
            W              87      0010 10111 23 + 2 = 25
            X              88      0010 11000 24 + 2 = 26
            Y              89      0010 11001 25 + 2 = 27
            Z              90      0010 11010 26 + 2 = 28
            LEFT_BRACKET   91      0010 11011 27 + 2 = 29
            BACKSLASH      92      0010 11100 28 + 2 = 30
            RIGHT_BRACKET  93      0010 11101 29 + 2 = 31

            #byte:6;8
            KP_0           320     1010 00000 0
            KP_1           321     1010 00001 1
            KP_2           322     1010 00010 2
            KP_3           323     1010 00011 3
            KP_4           324     1010 00100 4
            KP_5           325     1010 00101 5
            KP_6           326     1010 00110 6
            KP_7           327     1010 00111 7
            KP_8           328     1010 01000 8
            KP_9           329     1010 01001 9
            KP_DECIMAL     330     1010 01010 10
            KP_DIVIDE      331     1010 01011 11
            KP_MULTIPLY    332     1010 01100 12
            KP_SUBTRACT    333     1010 01101 13
            KP_ADD         334     1010 01110 14
            KP_ENTER       335     1010 01111 15
            KP_EQUAL       336     1010 10000 16
            LEFT_SHIFT     340     1010 10100 20 - 3  = 17
            ESCAPE         256     1000 00000 0  + 18 = 18
            ENTER          257     1000 00001 1  + 18 = 19
            TAB            258     1000 00010 2  + 18 = 20
            BACKSPACE      259     1000 00011 3  + 18 = 21
            INSERT         260     1000 00100 4  + 18 = 22
            DELETE         261     1000 00101 5  + 18 = 23
            RIGHT          262     1000 00110 6  + 18 = 24
            LEFT           263     1000 00111 7  + 18 = 25
            DOWN           264     1000 01000 8  + 18 = 26
            UP             265     1000 01001 9  + 18 = 27
            PAGE_UP        266     1000 01010 10 + 18 = 28
            PAGE_DOWN      267     1000 01011 11 + 18 = 29
            HOME           268     1000 01100 12 + 18 = 30
            END            269     1000 01101 13 + 18 = 31
            CAPS_LOCK      280     1000 11000 24 + 8  = 32
            SCROLL_LOCK    281     1000 11001 25 + 8  = 33
            NUM_LOCK       282     1000 11010 26 + 8  = 34
            PRINT_SCREEN   283     1000 11011 27 + 8  = 35
            PAUSE          284     1000 11100 28 + 8  = 36
            SEMICOLON      59      0001 11011 27 + 10 = 37
            EQUAL          61      0001 11101 29 + 9  = 38
            F1             290     1001 00010 2  + 37 = 39
            F2             291     1001 00011 3  + 37 = 40
            F3             292     1001 00100 4  + 37 = 41
            F4             293     1001 00101 5  + 37 = 42
            F5             294     1001 00110 6  + 37 = 43
            F6             295     1001 00111 7  + 37 = 44
            F7             296     1001 01000 8  + 37 = 45
            F8             297     1001 01001 9  + 37 = 46
            F9             298     1001 01010 10 + 37 = 47
            F10            299     1001 01011 11 + 37 = 48
            F11            300     1001 01100 12 + 37 = 49
            F12            301     1001 01101 13 + 37 = 50
            F13            302     1001 01110 14 + 37 = 51
            F14            303     1001 01111 15 + 37 = 52
            F15            304     1001 10000 16 + 37 = 53
            F16            305     1001 10001 17 + 37 = 54
            F17            306     1001 10010 18 + 37 = 55
            F18            307     1001 10011 19 + 37 = 56
            F19            308     1001 10100 20 + 37 = 57
            F20            309     1001 10101 21 + 37 = 58
            F21            310     1001 10110 22 + 37 = 59
            F22            311     1001 10111 23 + 37 = 60
            F23            312     1001 11000 24 + 37 = 61
            F24            313     1001 11001 25 + 37 = 62
            F25            314     1001 11010 26 + 37 = 63

            #byte:14;1
            LEFT_CONTROL   341     1010 10101 21 - 21 = 0
            LEFT_ALT       342     1010 10110 22 - 21 = 1
            LEFT_SUPER     343     1010 10111 23 - 21 = 2
            RIGHT_SHIFT    344     1010 11000 24 - 21 = 3
            RIGHT_CONTROL  345     1010 11001 25 - 21 = 4
            RIGHT_ALT      346     1010 11010 26 - 21 = 5
            RIGHT_SUPER    347     1010 11011 27 - 21 = 6
            MENU           348     1010 11100 28 - 21 = 7
    121 keys.
    */

    static void _CosaPanelExtensionCleanupGLFW(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock) {
        (void)_CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;
            return;
        }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBTrue) {
            pCosaGLFW->isInitialized = cosaBFalse;
            pCosaGLFW->monitorCount = 0;
            pCosaGLFW->pBMonitors = NULL;
        }
        glfwTerminate();
    }

    static void _CosaPanelExtensionInitGLFW(cosaContext *pContext, _CosaExtension *pExtension, _cosaGLFW_EXT *pCosaGLFW) {
        if (glfwInit() == GLFW_FALSE) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_LIBACC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_LIBACC;
            return;
        }
        pCosaGLFW->isInitialized = cosaBTrue;
        pExtension->pCleanup = _CosaPanelExtensionCleanupGLFW;
    }

    void linuxCosaPanelUpdateMousePosInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_POS) {
        //Get the cosaPanel from glfwWindow.
        //(Should probally just make the programmer provide a pointer towards cosaPanel MD.)
        if (cosaCUnlikely(_pGLFWWindow == NULL)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
            return;
        }
        if (cosaCUnlikely(_GLFWPosX < 0) || cosaCUnlikely(_GLFWPosY < 0)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }

        _CosaExtension *pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
        cosaU32 panelExtSlot = _CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        } else if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        if ((pCosaGLFW->isInitialized == cosaBFalse) || (pCosaGLFW->panelTop == 0)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }

        cosaPanel **ppPanels = (cosaPanel**)pCosaGLFW->pBPanels->addr;
        cosaBool foundPanel = cosaBFalse;
        cosaU32 panelIndex;
        for (panelIndex = 0; panelIndex < pCosaGLFW->panelTop; ++panelIndex) {
            if (((cosaPanel_GLFW*)ppPanels[panelIndex]->pBlock->addr)->pWindow == _pGLFWWindow) {
                foundPanel = cosaBTrue;
                break;
            }
        }
        if (foundPanel == cosaBFalse) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }

        //Compact the two damn 8Byte DOUBLE positions into a resonable 255 range.
        //This saves 14Bytes as someone thought sub-pixel precision was needed,
        //even when the decimal points is never used..? <_<'

        //(roundf from COSA to GLFW may be removed at the cost of noticeable precision.)
        //To convert from cosaMousePos to glfwMousePos: roundf((cosaMousePos/255) * length)
        //To convert from glfwMousePos to cosaMousePos: roundf((glfwPos/length) * 255)
        pContext->pCosaMD->inputMap.data[COSA_INPUTMAP_START_MOUSE_POSX] = (cosaU8)roundf((((cosaFloat)_GLFWPosX)/ppPanels[panelIndex]->width) * 255.0f);
        pContext->pCosaMD->inputMap.data[COSA_INPUTMAP_START_MOUSE_POSY] = (cosaU8)roundf((((cosaFloat)_GLFWPosY)/ppPanels[panelIndex]->height) * 255.0f);
    }

    void linuxCosaPanelUpdateMouseKeyInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_KEY) {
        //We aren't using the _pGLFWWindow.
        /*if (cosaCUnlikely(_pGLFWWindow == NULL)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
            return;
        }*/

        //Very unlikely but who knows, seeing how GLFW maps the Mouse_ID's and etc,
        //so it's better to catch the possible undefined behavior of negatives. _(-_-')|
        if (cosaCUnlikely(
                (_GLFWIKey < GLFW_MOUSE_BUTTON_1) || 
                (_GLFWIKey > GLFW_MOUSE_BUTTON_8) || 
                (_GLFWIAction < 0) || 
                (_GLFWIAction > 1) || 
                (_GLFWIMods < 0) || 
                (_GLFWIMods > GLFW_MOD_NUM_LOCK)
            )) {
                pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
                pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
                return;
        }

        //Gladly the Mouse_ID's in GLFW are mapped sanely within 8-bits,
        //so we can just use the actual key as a bit offset.
        pContext->pCosaMD->inputMap.data[COSA_INPUTMAP_START_MOD] = cosaR6B(((cosaU8)_GLFWIMods));
        pContext->pCosaMD->inputMap.data[COSA_INPUTMAP_START_MOUSE_KEY] &= (~(0x01 << ((cosaU8)_GLFWIKey)));
        pContext->pCosaMD->inputMap.data[COSA_INPUTMAP_START_MOUSE_KEY] |= (((cosaU8)_GLFWIAction) << ((cosaU8)_GLFWIKey));
    }

    void linuxCosaPanelUpdateKeyboardInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_KEYBOARD) {
        //Very unlikely but who knows, seeing how GLFW maps the Key_ID's and etc,
        //so it's better to catch the possible undefined behavior of negatives. _(-_-')|
        if (cosaCUnlikely(
                (_GLFWIKey < GLFW_KEY_SPACE) || 
                (_GLFWIKey > GLFW_KEY_LAST) || 
                (_GLFWIAction < 0) || 
                (_GLFWIAction > 2) || 
                (_GLFWIMods < 0) || 
                (_GLFWIMods > GLFW_MOD_NUM_LOCK)
            )) {
                pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
                pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
                return;
        }
        cosaU8 GLFWAction = (cosaU8)_GLFWIAction;
        COSA_INPUTMAP_KEYSTATE_OVERFLOW(GLFWAction)

        cosaU16 GLFWKey = _GLFWIKey & 0x1FF; //cosaR9B(_GLFWIKey);

        cosaU8 offset = cosaR5B(GLFWKey);
        cosaU8 bank = 0;

        //This merely maps GLFW's mapping into COSA's more runtime and memory performant yet user-friendly method,
        //while not making a 1KB+ mapping table at the cost of some complexity to the eyes.
        switch (GLFWKey >> 5) {
            case 0x00000001: {
                switch (offset) {
                    case 0x07:
                        offset -= 6;
                        //Fall.
                    case 0x00:
                        bank = 0;
                        break;
                    case 0x1B: {
                        bank = 6;
                        offset += 10;
                        break;
                    }
                    case 0x1D: {
                        bank = 6;
                        offset += 9;
                        break;
                    }
                    default: {
                        bank = 0;
                        offset -= 10;
                        break;
                    }
                }
                break;
            }
            case 0x00000003:
                //Fall.
            case 0x00000002:
                offset += 2;
                //Fall.
            case 0x00000005:
                bank = 2;
                break;
            case 0x00000008: {
                bank = 6;
                offset += (cosaR1B_O(GLFWKey, 4) == 0x10) ? 8 : 18;
                break;
            }
            case 0x00000009: {
                bank = 6;
                offset += 37;
                break;
            }
            case 0x0000000A: {
                bank = 6;
                if (GLFWKey > GLFW_KEY_KP_EQUAL) {
                    if (GLFWKey == GLFW_KEY_LEFT_SHIFT) {
                        // bank = 6;
                        offset -= 3;
                    } else {
                        bank += 8; // bank = 14.
                        offset -= 21;
                    }
                }// else { bank = 6; }
                break;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
                return;
            }
        }

        //Finally, go to the looked up bank of keys and get the respective offset key state.
        switch (bank) {
            case 0: {
                cosaU16 *pBank = (cosaU16*)(pContext->pCosaMD->inputMap.data + COSA_INPUTMAP_START_KEYBOARD);
                (*pBank) &= (~(0x01 << offset));
                (*pBank) |= (GLFWAction << offset);
                break;
            }
            case 2: {
                cosaU32 *pBank = (cosaU32*)(pContext->pCosaMD->inputMap.data + bank + COSA_INPUTMAP_START_KEYBOARD);
                (*pBank) &= (~(0x01 << offset));
                (*pBank) |= (GLFWAction << offset);
                break;
            }
            case 6: {
                cosaU64 *pBank = (cosaU64*)(pContext->pCosaMD->inputMap.data + bank + COSA_INPUTMAP_START_KEYBOARD);
                (*pBank) &= (~(0x01 << offset));
                (*pBank) |= (GLFWAction << offset);
                break;
            }
            case 14: {
                cosaU8 *pBank = (cosaU8*)(pContext->pCosaMD->inputMap.data + bank + COSA_INPUTMAP_START_KEYBOARD);
                (*pBank) &= (~(0x01 << offset));
                (*pBank) |= (GLFWAction << offset);
                break;
            }
        }
    }

    void linuxCosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel) {
        cosaU8 R = cosaR8B_O(pPanel->color, 24) >> 24;
        cosaU8 G = cosaR8B_O(pPanel->color, 16) >> 16;
        cosaU8 B = cosaR8B_O(pPanel->color, 8) >> 8;
        cosaU8 A = cosaR8B(pPanel->color) >> 0;
        glClearColor(
            (R > 0) ? (GLfloat)(1.0f/(255.0f/R)) : 0.0f,
            (G > 0) ? (GLfloat)(1.0f/(255.0f/G)) : 0.0f,
            (B > 0) ? (GLfloat)(1.0f/(255.0f/B)) : 0.0f,
            (A > 0) ? (GLfloat)(1.0f/(255.0f/A)) : 0.0f
        );
        glClear(GL_COLOR_BUFFER_BIT);
    }

    void linuxCosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        glfwSwapBuffers(pPanelMD_GLFW->pWindow);
        glfwPollEvents();

        if (glfwWindowShouldClose(pPanelMD_GLFW->pWindow) == GLFW_TRUE) { pPanel->flags |= COSA_PANEL_ACTIVE; }
    }

    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
        _CosaExtension *pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
        cosaU32 panelExtSlot = _CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        } else if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        if ((pCosaGLFW->isInitialized == cosaBFalse) || (pCosaGLFW->panelTop == 0)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }

        cosaPanel **ppPanels = (cosaPanel**)pCosaGLFW->pBPanels->addr;
        cosaBool foundPanel = cosaBFalse;
        cosaU32 panelIndex;
        for (panelIndex = 0; panelIndex < pCosaGLFW->panelTop; ++panelIndex) {
            if (ppPanels[panelIndex]->pBlock == pPanel->pBlock) {
                foundPanel = cosaBTrue;
                break;
            }
        }
        if (foundPanel == cosaBFalse) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }

        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)ppPanels[panelIndex]->pBlock->addr;
        if (ppPanels[panelIndex]->pIconPath != NULL) { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        glfwMakeContextCurrent(NULL);
        glfwDestroyWindow(pPanelMD_GLFW->pWindow);

        (void)memset(ppPanels[panelIndex]->pBlock->addr, 0, sizeof(cosaPanel_GLFW));
        linuxCosaDestroyBlock(pContext, ppPanels[panelIndex]->pBlock);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        ppPanels[panelIndex]->pBlock = NULL;
        ppPanels[panelIndex] = NULL;
    }

    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel) {
        _CosaExtension *pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
        cosaU32 panelExtSlot = _CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;

            panelExtSlot = _CosaExtensionCreate(pContext);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
            pExtStack[panelExtSlot].ID = COSA_EXTENSION_PANEL_ID;

            linuxCosaCreateBlock(pContext, &pExtStack[panelExtSlot].pBlock, 1, sizeof(_cosaGLFW_EXT));
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
            pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));

            (void)memset(
                pExtStack[panelExtSlot].pBlock->addr, 0,
                pExtStack[panelExtSlot].pBlock->count * pExtStack[panelExtSlot].pBlock->byteSize
            );
        } else if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBFalse) {
            _CosaPanelExtensionInitGLFW(pContext, &pExtStack[panelExtSlot], pCosaGLFW);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                pExtStack[panelExtSlot].pBlock->flags = 0x00;
                _CosaExtensionRemove(pContext, panelExtSlot);
            }
        }

        if (pCosaGLFW->pBPanels == NULL) {
            linuxCosaCreateBlock(pContext, &pCosaGLFW->pBPanels, 1, sizeof(cosaPanel*));
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
            pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
            pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;

            (void)memset(pCosaGLFW->pBPanels->addr, 0, pCosaGLFW->pBPanels->count * pCosaGLFW->pBPanels->byteSize);
        } else if (pCosaGLFW->panelTop >= pCosaGLFW->pBPanels->count) {
            linuxCosaExpandBlock(pContext, pCosaGLFW->pBPanels, pCosaGLFW->panelTop + 1, sizeof(cosaPanel*));
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
            pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
            pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        }
        ((cosaPanel**)pCosaGLFW->pBPanels->addr)[pCosaGLFW->panelTop] = pPanel;
        ++pCosaGLFW->panelTop;

        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, COSA_PANEL_CONTEXT_MAJOR);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, COSA_PANEL_CONTEXT_MINOR);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

        glfwWindowHint(GLFW_POSITION_X, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_POSITION_Y, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_CONTEXT_DEBUG,           ((pPanel->flags >> 9) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, ((pPanel->flags >> 1) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_FOCUS_ON_SHOW,           ((pPanel->flags >> 2) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #if defined(USING_X11) || defined(COSA_OS_WINDOWS)
            glfwWindowHint(GLFW_SCALE_TO_MONITOR,  ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #elif defined(USING_WAYLAND)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #endif

        #if defined(COSA_OS_MACOS)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
        #else
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_FALSE);
        #endif

        if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
            glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
            glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
            glfwWindowHint(GLFW_MAXIMIZED, GLFW_FALSE);
            glfwWindowHint(GLFW_VISIBLE,   GLFW_FALSE);
            glfwWindowHint(GLFW_FOCUSED,   GLFW_FALSE);
            glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & COSA_PANEL_MOUSE_PASSTHROUGH) == COSA_PANEL_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_AUTO_ICONIFY,      ((pPanel->flags & COSA_PANEL_AUTO_ICONIFY)      == COSA_PANEL_AUTO_ICONIFY     ) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_CENTER_CURSOR,     ((pPanel->flags & COSA_PANEL_CENTER_CURSOR)     == COSA_PANEL_CENTER_CURSOR    ) ? GLFW_TRUE : GLFW_FALSE);
        } else {
            glfwWindowHint(GLFW_MAXIMIZED, ((pPanel->flags & COSA_PANEL_MAXIMIZED) == COSA_PANEL_MAXIMIZED) ? GLFW_TRUE : GLFW_FALSE);

            if ((pPanel->flags & COSA_PANEL_DECORATED) == COSA_PANEL_DECORATED) {
                glfwWindowHint(GLFW_DECORATED, GLFW_TRUE);
                glfwWindowHint(GLFW_RESIZABLE, ((pPanel->flags & COSA_PANEL_RESIZABLE) == COSA_PANEL_RESIZABLE) ? GLFW_TRUE : GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
                glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & GLFW_MOUSE_PASSTHROUGH) == GLFW_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            }

            if ((pPanel->flags & COSA_PANEL_VISIBLE) == COSA_PANEL_VISIBLE) {
                glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);
                glfwWindowHint(GLFW_FOCUSED, ((pPanel->flags & COSA_PANEL_FOCUSED) == COSA_PANEL_FOCUSED) ? GLFW_TRUE : GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
                glfwWindowHint(GLFW_FOCUSED, GLFW_FALSE);
            }
        }


        linuxCosaCreateBlock(pContext, &pPanel->pBlock, 1, sizeof(cosaPanel_GLFW));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, sizeof(cosaStackMD_XS));
        pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        (void)memset(pPanel->pBlock->addr, 0, pPanel->pBlock->count * pPanel->pBlock->byteSize);

        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        pPanelMD_GLFW->pWindow = glfwCreateWindow(pPanel->width, pPanel->height, pPanel->pTitle, NULL, NULL);
        if (pPanelMD_GLFW->pWindow == NULL) {
            pPanel->pBlock->flags = 0x00;
            pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
            
            pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
            return;
        }
        glfwMakeContextCurrent(pPanelMD_GLFW->pWindow);
        glfwSwapInterval(1); // V-Sync.

        if (pPanel->pIconPath != NULL) {
            cosaImage image;
            linuxCosaOpenImage(pContext, &image, pPanel->pIconPath);
            if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
                pPanelMD_GLFW->icon.width = image.width;
                pPanelMD_GLFW->icon.height = image.height;
                pPanelMD_GLFW->icon.pixels = image.pData;
                glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 1, &pPanelMD_GLFW->icon);
                linuxCosaCloseImage(pContext, &image);

                pPanelMD_GLFW->icon.width = 0;
                pPanelMD_GLFW->icon.height = 0;
                pPanelMD_GLFW->icon.pixels = NULL;
            } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }

        if (((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) ||
            ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) ||
            ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y)) {
                if (pCosaGLFW->pBMonitors == NULL) {
                    cosaI32 monitorCount = 0;
                    pCosaGLFW->pBMonitors = glfwGetMonitors(&monitorCount);
                    if ((monitorCount == 0) || (pCosaGLFW->pBMonitors == NULL)) {
                        pCosaGLFW->monitorCount = 0;
                        pCosaGLFW->pBMonitors = NULL;
                        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;

                        linuxCosaDestroyPanel(pContext, pPanel);
                        return;
                    }
                    pCosaGLFW->monitorCount = COSA_MACRO_SIGNED_TO_UNSIGNED(monitorCount);
                }
                pPanelMD_GLFW->pMonitor = NULL;

                for (cosaU32 i = 0; i < pCosaGLFW->monitorCount; i++) {
                    if (pCosaGLFW->pBMonitors[i] != NULL) {
                        pPanelMD_GLFW->pMonitor = pCosaGLFW->pBMonitors[i];
                        break;
                    }
                }
                if (pPanelMD_GLFW->pMonitor == NULL) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_NOMDIM;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_NOMDIM;
                } else {
                    const GLFWvidmode *pVideoMode = glfwGetVideoMode(pPanelMD_GLFW->pMonitor);
                    if (pVideoMode == NULL) {
                        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
                    } else if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
                        pPanel->width = pVideoMode->width;
                        pPanel->height = pVideoMode->height;
                        pPanel->posX = 0;
                        pPanel->posY = 0;
                        glfwSetWindowMonitor(pPanelMD_GLFW->pWindow, pPanelMD_GLFW->pMonitor, pPanel->posX, pPanel->posY, pPanel->width, pPanel->height, pVideoMode->refreshRate);
                    } else {
                        cosaI32 gotWindowPosX = 0;
                        cosaI32 gotWindowPosY = 0;
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);

                        cosaI32 gotMonitorPosX = 0;
                        cosaI32 gotMonitorPosY = 0;
                        glfwGetMonitorPos(pPanelMD_GLFW->pMonitor, &gotMonitorPosX, &gotMonitorPosY);
                        if ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) {
                            gotWindowPosX = gotMonitorPosX + pPanel->posX;
                            if ((gotWindowPosX + pPanel->width) > pVideoMode->width) {
                                gotWindowPosX -= (gotWindowPosX + pPanel->width) - pVideoMode->width;
                                if (gotWindowPosX < gotMonitorPosX) { gotWindowPosX = gotMonitorPosX; }
                            }
                        }
                        if ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y) {
                            gotWindowPosY = gotMonitorPosY + pPanel->posY;
                            if ((gotWindowPosY + pPanel->height) > pVideoMode->height) {
                                gotWindowPosY -= (gotWindowPosY + pPanel->height) - pVideoMode->height;
                                if (gotWindowPosY < gotMonitorPosY) { gotWindowPosY = gotMonitorPosY; }
                            }
                        }
                        glfwSetWindowPos(pPanelMD_GLFW->pWindow, gotWindowPosX, gotWindowPosY);
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);
                    }
                }
        }


        (void)gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
        glViewport(0, 0, pPanel->width, pPanel->height);
    }
#endif
