#include "cosaLinux.h"
#include "../headers/error.h"

static cosaBool _CosaFindFreedBlock(cosaContext *pContext, cosaUSize *pBlockSlot, cosaUSize blockSize) {
    cosaBool foundSlot = cosaBFalse;
    cosaUSize freedSlot, freedSize, blockSlot = 0;
    for (freedSlot = 0; freedSlot < pContext->blockPage.freedTop; ++freedSlot) {
        blockSlot = pContext->blockPage.pFreed[freedSlot];
        freedSize = pContext->blockPage.pBlocks[blockSlot].count;
        freedSize *= pContext->blockPage.pBlocks[blockSlot].byteSize;
        if (freedSize >= blockSize) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBTrue) {
        cosaUSize i;
        for (i = blockSlot + 1; i < pContext->blockPage.freedTop; ++i) {
            pContext->blockPage.pFreed[i - 1] = pContext->blockPage.pFreed[i];
        }
        --pContext->blockPage.freedTop;
    }

    (*pBlockSlot) = blockSlot;
    return foundSlot;
}

static void _CosaAddFreedBlock(cosaContext *pContext, cosaUSize blockSlot) {
    pContext->blockPage.pFreed[pContext->blockPage.freedTop] = blockSlot;
    ++pContext->blockPage.freedTop;

    if (pContext->blockPage.freedTop >= pContext->blockPage.freedCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.freedCount);

        cosaUSize *pNewFreed = realloc(pContext->blockPage.pFreed, newCount * sizeof(cosaUSize));
        if (pNewFreed == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.freedTop;
            return;
        }
        (void)memset(pNewFreed + pContext->blockPage.freedCount, 0, (newCount - pContext->blockPage.freedCount) * sizeof(cosaUSize));
        pContext->blockPage.freedCount = newCount;
        pContext->blockPage.pFreed = pNewFreed;
    }
}

static void _CosaGetLinkBlock(cosaContext *pContext, cosaUSize *pLinkSlot) {
    (*pLinkSlot) = pContext->blockPage.linkTop;
    ++pContext->blockPage.linkTop;

    if (pContext->blockPage.linkTop >= pContext->blockPage.linkCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

        cosaLinkBlock *pNewLinks = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaLinkBlock));
        if (pNewLinks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewLinks + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaLinkBlock));
        pContext->blockPage.linkCount = newCount;
        pContext->blockPage.pLinks = pNewLinks;
    }
}

static void _CosaUpdateLinks(cosaContext *pContext, cosaMemBlock *pNewBuff) {
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
            (*pContext->blockPage.pLinks[i].ppBlockLink) = &pNewBuff[pContext->blockPage.pLinks[i].blockSlot];
        }
    }
}

static void _CosaRemoveLinkBlock(cosaContext *pContext, cosaUSize linkSlot) {
    for (cosaUSize i = linkSlot + 1; i < pContext->blockPage.linkTop; ++i) {
        pContext->blockPage.pLinks[i - 1].blockSlot = pContext->blockPage.pLinks[i].blockSlot;
        pContext->blockPage.pLinks[i - 1].ppBlockLink = pContext->blockPage.pLinks[i].ppBlockLink;
    }
    --pContext->blockPage.linkTop;
}

static void _CosaGetBlockMD(cosaContext *pContext, cosaUSize *pBlockSlot) {
    (*pBlockSlot) = pContext->blockPage.blockTop;
    ++pContext->blockPage.blockTop;

    if (pContext->blockPage.blockTop >= pContext->blockPage.blockCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

        cosaMemBlock *pNewBlocks = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
        if (pNewBlocks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewBlocks + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
        pContext->blockPage.blockCount = newCount;

        if (pNewBlocks != pContext->blockPage.pBlocks) {
            _CosaUpdateLinks(pContext, pNewBlocks);
        }
        pContext->blockPage.pBlocks = pNewBlocks;
    }
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    //Unlikely yet possible malloc error.
    cosaUSize blockSize = count * byteSize;
    if (cosaCUnlikely(blockSize > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }

    //Is there usuable freed blocks? Otherwise, get a fresh one.
    cosaUSize blockSlot = 0;
    cosaBool foundSlot = _CosaFindFreedBlock(pContext, &blockSlot, blockSize);
    if (foundSlot == cosaBFalse) {
        _CosaGetBlockMD(pContext, &blockSlot);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }

    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->blockPage.pBlocks[blockSlot].addr = malloc(blockSize);

        if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            return;
        }
    }

    //Get a linkBlock slot and set it.
    cosaUSize linkSlot = 0;
    _CosaGetLinkBlock(pContext, &linkSlot);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        free(pContext->blockPage.pBlocks[blockSlot].addr);
        pContext->blockPage.pBlocks[blockSlot].addr = NULL;
        return;
    }
    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;

    //Give the newly created block's address.
    (*ppBlock) = &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    cosaUSize newSize = count * byteSize;
    cosaUSize oldSize = pBlock->count * pBlock->byteSize;
    cosaU8 *pNewAddr = realloc(pBlock->addr, newSize);
    if (pNewAddr == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewAddr + oldSize, 0, newSize - oldSize);
    pBlock->byteSize = byteSize;
    pBlock->count = count;
    pBlock->addr = pNewAddr;
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    cosaUSize blockSlot = pBlock - pContext->blockPage.pBlocks;
    if (blockSlot > pContext->blockPage.blockTop) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }

    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].blockSlot == blockSlot) {
            _CosaRemoveLinkBlock(pContext, i);
        }
    }
    _CosaAddFreedBlock(pContext, blockSlot);
}

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * bSize;

    if (offset >= (pStack->count - COSA_STACK_SIZE_SS)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    (void)memcpy(pMem + offset, pItem, bSize);
    ++(*pTop);
}

void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * bSize;
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DS);

    if (offset >= size) {
        size += offset - size;
        size += COSA_STACK_EXPAND * bSize;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DS, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    (void)memcpy(pMem + offset, pItem, bSize);
    ++(*pTop);
}

void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) + itemSize + sizeof(cosaUSize);

    if (newTop >= (pStack->count - COSA_STACK_SIZE_SD)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(cosaUSize));
    (*pTop) = newTop;
}

void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) += itemSize + sizeof(itemSize);
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DD);

    if (newTop >= size) {
        size += newTop - size;
        size += COSA_STACK_EXPAND * COSA_STACK_DTYPE_EXPAND;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(itemSize));
    (*pTop) = newTop;
}

void *linuxCosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    if (pSize != NULL) { *pSize = bSize; }
    --(*pTop);

    return pMem + ((*pTop) * bSize);
}

void *linuxCosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    if (pSize != NULL) { *pSize = bSize; }
    --(*pTop);

    return pMem + ((*pTop) * bSize);
}

void *linuxCosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

void *linuxCosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

//StackSS - Static Sized Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_SS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

//StackDS - Dynamic Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_DS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pType = COSA_STACK_TYPE_DS;
    *pBSize = byteSize;

    return pBlock;
}

//StackSD - Static Sized Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_SD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_SD;

    return pBlock;
}

//StackDD - Dynamic Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_DD;

    return pBlock;
}

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pBack = cosaQueueMD_Back(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((size - ((*pCount) * bSize)) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }

    cosaU8 *pMem = cosaQueueMD_Mem(pQueue);
    (void)memcpy(pMem + (*pBack), pItem, bSize);
    (*pBack) = ((*pBack) + bSize) % size;
    ++(*pCount);
}

void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pFront = cosaQueueMD_Front(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((*pCount) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaQueueMD_Mem(pQueue) + (*pFront);
    (*pFront) = ((*pFront) + bSize) % size;
    --(*pCount);
    return pMem;
}

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_QUEUE_SIZE, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaQueueMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

cosaFile *linuxCosaOpenFile(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]) {
    cosaFile *pFile = NULL;
    cosaU32 fileSlot;
    for (fileSlot = 0; fileSlot < pContext->filePage.count; ++fileSlot) {
        if (pContext->filePage.pFiles[fileSlot].desc == -1) {
            pFile = &pContext->filePage.pFiles[fileSlot];
            break;
        }
    }
    if (pFile == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
        return NULL;
    }
    cosaU8 fileFlags = cosaR3B(flags);
    cosaI32 memFlags = cosaR2B(fileFlags);

    pFile->desc = open(filePath, memFlags - 1);
    if (pFile->desc < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return NULL;
    }

    if (fstat(pFile->desc, &pFile->info) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    pFile->pMData = mmap(
        NULL, pFile->info.st_size,
        memFlags, COSA_MEM_FLAG_PVE,
        pFile->desc, 0);
    if (pFile->pMData == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    return pFile;
}

void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]) {
    cosaUSize pathLength = strlen(filePath);
    pImage->type = 0;
    cosaChar imageTypes[COSA_IMAGE_TYPE_COUNT][COSA_IMAGE_TYPE_LENGTH] = COSA_IMAGE_TYPES;
    for (cosaU8 i = 0; i < COSA_IMAGE_TYPE_COUNT; ++i) {
        if (strncmp(filePath + (pathLength - 4), imageTypes[i], 4) == 0) {
            pImage->type = i + 1;
            break;
        }
    }
    if (pImage->type == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
        return;
    }
    pImage->pFile = linuxCosaOpenFile(pContext, COSA_FILE_FLAG_PERM_RD, filePath);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaI32 w = 0;
    cosaI32 h = 0;
    cosaI32 c = 0;
    pImage->pData = stbi_load_from_memory(pImage->pFile->pMData, pImage->pFile->info.st_size, &w, &h, &c, 0);
    if (pImage->pData == NULL) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
        return;
    } else if ((w < 1) || (h < 1) || (c < 1)) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
        return;
    }
    pImage->width    = COSA_MACRO_SIGNED_TO_UNSIGNED(w);
    pImage->height   = COSA_MACRO_SIGNED_TO_UNSIGNED(h);
    pImage->channels = COSA_MACRO_SIGNED_TO_UNSIGNED(c);
}

void linuxCosaCloseFile(cosaContext *pContext, cosaFile *pFile) {
    cosaI32 errMem = munmap(pFile->pMData, pFile->info.st_size);
    cosaI32 err = close(pFile->desc);
    pFile->flags = 0x00;

    cosaU8 errFlg = 0x00;
    (errMem < 0) ? cosaS1B(errFlg) : cosaC1B(errFlg);
    (err < 0) ? cosaS1B_O(errFlg, 1) : cosaC1B_O(errFlg, 1);

    switch (errFlg) {
        case 0x03: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            break;
        }
        case 0x02: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->pMData = NULL;
            break;
        }
        case 0x01: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->desc = -1;
            break;
        }
        default: {
            pFile->pMData = NULL;
            pFile->desc = -1;
            break;
        }
    }
}

void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage) {
    if (pImage->pData != NULL) {
        stbi_image_free(pImage->pData);
        pImage->pData = NULL;
        pImage->width = 0;
        pImage->height = 0;
        pImage->channels = 0;
    }
    if (pImage->pFile != NULL) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
            pImage->pFile = NULL;
            pImage->type = 0;
        }
    }
}

void linuxCosaInitContext(cosaContext *pContext) {
    pContext->blockPage.blockCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pBlocks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));
    if (pContext->blockPage.pBlocks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pContext->blockPage.pBlocks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));

    pContext->blockPage.freedCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pFreed = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaUSize));
    if (pContext->blockPage.pFreed == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->blockPage.pFreed, 0, COSA_PAGE_BLOCK_START * sizeof(cosaUSize));

    pContext->blockPage.linkCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pLinks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));
    if (pContext->blockPage.pLinks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->blockPage.pLinks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));


    pContext->pCosaMD = malloc(sizeof(_CosaMD));
    if (pContext->pCosaMD == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->pCosaMD, 0, sizeof(_CosaMD));

    cosaU16 isBigEndian = 0x0001;
    pContext->pCosaMD->systemInfo.isBigEndian = cosaIsEndianBig(isBigEndian);

    if (getrlimit(RLIMIT_NOFILE, &pContext->pCosaMD->systemInfo.maxFDs) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->pCosaMD);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->pCosaMD = NULL;
        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }


    pContext->filePage.count = COSA_FILE_DESCS_MIN;
    if ((pContext->filePage.count == 0) || (pContext->pCosaMD->systemInfo.maxFDs.rlim_cur < pContext->filePage.count)) {
        pContext->filePage.count = pContext->pCosaMD->systemInfo.maxFDs.rlim_cur;
    }

    pContext->filePage.pFiles = malloc(pContext->filePage.count * sizeof(cosaFile));
    if (pContext->filePage.pFiles == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->pCosaMD);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->pCosaMD = NULL;
        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->filePage.pFiles, 0, pContext->filePage.count * sizeof(cosaFile));
    for (cosaU32 i = 0; i < pContext->filePage.count; ++i) {
        pContext->filePage.pFiles[i].desc = -1;
    }
}

void linuxCosaDestroyContext(cosaContext *pContext) {
    if (pContext->filePage.pFiles != NULL) {
        free(pContext->filePage.pFiles);
        pContext->filePage.pFiles = NULL;
    }

    if (pContext->pCosaMD != NULL) {
        free(pContext->pCosaMD);
        pContext->pCosaMD = NULL;
    }

    if (pContext->blockPage.pBlocks != NULL) {
        for (cosaUSize i = 0; i < pContext->blockPage.blockTop; ++i) {
            free(pContext->blockPage.pBlocks[i].addr);
            pContext->blockPage.pBlocks[i].addr = NULL;
        }
        free(pContext->blockPage.pBlocks);
        pContext->blockPage.pBlocks = NULL;
    }

    if (pContext->blockPage.pLinks != NULL) {
        for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
            if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
                (*pContext->blockPage.pLinks[i].ppBlockLink) = NULL;
            }
            pContext->blockPage.pLinks[i].ppBlockLink = NULL;
        }
        free(pContext->blockPage.pLinks);
        pContext->blockPage.pLinks = NULL;
    }

    free(pContext->blockPage.pFreed);
    pContext->blockPage.pFreed = NULL;
    _InitContext(pContext);
}


#if defined(COSA_ENABLE_EXTENSIONS)
    static cosaU32 _CosaExtensionFind(cosaContext *pContext, cosaU32 extensionID) {
        cosaU32 top = *cosaStackMD_Top(pContext->pCosaMD->pSExtensions);
        if (top == 0) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
            return 0;
        }
        _CosaExtension *pMem = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, COSA_STACK_SIZE_SS);

        cosaBool foundSlot = cosaBFalse;
        cosaU32 extensionSlot;
        for (extensionSlot = 0; extensionSlot < top; ++extensionSlot) {
            if (pMem[extensionSlot].ID == extensionID) {
                foundSlot = cosaBTrue;
                break;
            }
        }
        if (foundSlot == cosaBFalse) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
        }
        return extensionSlot;
    }

    static cosaU32 _CosaExtensionCreate(cosaContext *pContext, _CosaExtension *pExtensionMD) {
        cosaU32 top = *cosaStackMD_Top(pContext->pCosaMD->pSExtensions);
        linuxCosaStackSSPush(pContext, pContext->pCosaMD->pSExtensions, pExtensionMD);
        return top;
    }

    static void _CosaExtensionRemove(cosaContext *pContext, cosaU32 extensionSlot) {
        cosaU32 top = *cosaStackMD_Top(pContext->pCosaMD->pSExtensions);
        if ((top == 0) || (extensionSlot > (top - 1))) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
            return;
        }
        _CosaExtension *pMem = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, COSA_STACK_SIZE_SS);
        _CosaExtension *pExt = linuxCosaStackSSPop(pContext, pContext->pCosaMD->pSExtensions, NULL);
        if (pMem[extensionSlot].ID != pExt->ID) {
            pMem[extensionSlot].ID       = pExt->ID;
            pMem[extensionSlot].pBlock   = pExt->pBlock;
            pMem[extensionSlot].pCleanup = pExt->pCleanup;
        }
    }

    void linuxCosaInitExtensions(cosaContext *pContext) {
        if ((COSA_EXTENSION_COUNT == 0) || (COSA_EXTENSION_COUNT > 255)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }
        pContext->pCosaMD->pSExtensions = linuxCosaCreateStackSS(pContext, COSA_EXTENSION_COUNT, sizeof(_CosaExtension));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    /*
        GLFW_MOD:
            SHIFT      0x01    000001
            CONTROL    0x02    000010
            ALT        0x04    000100
            SUPER      0x08    001000
            CAPS_LOCK  0x10    010000
            NUM_LOCK   0x20    100000
    */

    /*Difference.
        GLFW_KEY:
            SPACE          32      000100000
            APOSTROPHE     39      000100111
            COMMA          44      000101100
            SEMICOLON      59      000111011
            EQUAL          61      000111101
            GRAVE_ACCENT   96      001100000
            WORLD_1        161     010100001
            WORLD_2        162     010100010


            SPACE          32      000100000

            APOSTROPHE     39      000100111

            COMMA          44      000101100

            MINUS          45      000101101
            PERIOD         46      000101110
            SLASH          47      000101111
            0              48      000110000
            1              49      000110001
            2              50      000110010
            3              51      000110011
            4              52      000110100
            5              53      000110101
            6              54      000110110
            7              55      000110111
            8              56      000111000
            9              57      000111001

            SEMICOLON      59      000111011

            EQUAL          61      000111101

            A              65      001000001
            B              66      001000010
            C              67      001000011
            D              68      001000100
            E              69      001000101
            F              70      001000110
            G              71      001000111
            H              72      001001000
            I              73      001001001
            J              74      001001010
            K              75      001001011
            L              76      001001100
            M              77      001001101
            N              78      001001110
            O              79      001001111
            P              80      001010000
            Q              81      001010001
            R              82      001010010
            S              83      001010011
            T              84      001010100
            U              85      001010101
            V              86      001010110
            W              87      001010111
            X              88      001011000
            Y              89      001011001
            Z              90      001011010
            LEFT_BRACKET   91      001011011
            BACKSLASH      92      001011100
            RIGHT_BRACKET  93      001011101

            GRAVE_ACCENT   96      001100000

            WORLD_1        161     010100001
            WORLD_2        162     010100010

            ESCAPE         256     100000000
            ENTER          257     100000001
            TAB            258     100000010
            BACKSPACE      259     100000011
            INSERT         260     100000100
            DELETE         261     100000101
            RIGHT          262     100000110
            LEFT           263     100000111
            DOWN           264     100001000
            UP             265     100001001
            PAGE_UP        266     100001010
            PAGE_DOWN      267     100001011
            HOME           268     100001100
            END            269     100001101

            CAPS_LOCK      280     100011000
            SCROLL_LOCK    281     100011001
            NUM_LOCK       282     100011010
            PRINT_SCREEN   283     100011011
            PAUSE          284     100011100

            F1             290     100100010
            F2             291     100100011
            F3             292     100100100
            F4             293     100100101
            F5             294     100100110
            F6             295     100100111
            F7             296     100101000
            F8             297     100101001
            F9             298     100101010
            F10            299     100101011
            F11            300     100101100
            F12            301     100101101
            F13            302     100101110
            F14            303     100101111
            F15            304     100110000
            F16            305     100110001
            F17            306     100110010
            F18            307     100110011
            F19            308     100110100
            F20            309     100110101
            F21            310     100110110
            F22            311     100110111
            F23            312     100111000
            F24            313     100111001
            F25            314     100111010

            KP_0           320     101000000
            KP_1           321     101000001
            KP_2           322     101000010
            KP_3           323     101000011
            KP_4           324     101000100
            KP_5           325     101000101
            KP_6           326     101000110
            KP_7           327     101000111
            KP_8           328     101001000
            KP_9           329     101001001
            KP_DECIMAL     330     101001010
            KP_DIVIDE      331     101001011
            KP_MULTIPLY    332     101001100
            KP_SUBTRACT    333     101001101
            KP_ADD         334     101001110
            KP_ENTER       335     101001111
            KP_EQUAL       336     101010000

            LEFT_SHIFT     340     101010100
            LEFT_CONTROL   341     101010101
            LEFT_ALT       342     101010110
            LEFT_SUPER     343     101010111
            RIGHT_SHIFT    344     101011000
            RIGHT_CONTROL  345     101011001
            RIGHT_ALT      346     101011010
            RIGHT_SUPER    347     101011011
            MENU           348     101011100
    */

    /*Bitpos(9b).
        GLFW_KEY:
            SPACE          32      0001 00000 0

            APOSTROPHE     39      0001 00111 7

            COMMA          44      0001 01100 12
            MINUS          45      0001 01101 13
            PERIOD         46      0001 01110 14
            SLASH          47      0001 01111 15
            0              48      0001 10000 16
            1              49      0001 10001 17
            2              50      0001 10010 18
            3              51      0001 10011 19
            4              52      0001 10100 20
            5              53      0001 10101 21
            6              54      0001 10110 22
            7              55      0001 10111 23
            8              56      0001 11000 24
            9              57      0001 11001 25

            SEMICOLON      59      0001 11011 27

            EQUAL          61      0001 11101 29

            Bitmask:0x40 {
                A              65      0010 00001 1
                B              66      0010 00010 2
                C              67      0010 00011 3
                D              68      0010 00100 4
                E              69      0010 00101 5
                F              70      0010 00110 6
                G              71      0010 00111 7
                H              72      0010 01000 8
                I              73      0010 01001 9
                J              74      0010 01010 10
                K              75      0010 01011 11
                L              76      0010 01100 12
                M              77      0010 01101 13
                N              78      0010 01110 14
                O              79      0010 01111 15
                P              80      0010 10000 16
                Q              81      0010 10001 17
                R              82      0010 10010 18
                S              83      0010 10011 19
                T              84      0010 10100 20
                U              85      0010 10101 21
                V              86      0010 10110 22
                W              87      0010 10111 23
                X              88      0010 11000 24
                Y              89      0010 11001 25
                Z              90      0010 11010 26
                LEFT_BRACKET   91      0010 11011 27
                BACKSLASH      92      0010 11100 28
                RIGHT_BRACKET  93      0010 11101 29
            }

            GRAVE_ACCENT   96      0011 00000 0

            Bitmask:0x80 {
                WORLD_1        161     0101 00001 1
                WORLD_2        162     0101 00010 2
            }


            Bitmask:0x100 {
                ESCAPE         256     1000 00000 0
                ENTER          257     1000 00001 1
                TAB            258     1000 00010 2
                BACKSPACE      259     1000 00011 3
                INSERT         260     1000 00100 4
                DELETE         261     1000 00101 5
                RIGHT          262     1000 00110 6
                LEFT           263     1000 00111 7
                DOWN           264     1000 01000 8
                UP             265     1000 01001 9
                PAGE_UP        266     1000 01010 10
                PAGE_DOWN      267     1000 01011 11
                HOME           268     1000 01100 12
                END            269     1000 01101 13

                Bitmask:0x110 {
                    CAPS_LOCK      280     1000 11000 24
                    SCROLL_LOCK    281     1000 11001 25
                    NUM_LOCK       282     1000 11010 26
                    PRINT_SCREEN   283     1000 11011 27
                    PAUSE          284     1000 11100 28
                }

                Bitmask:0x20 {
                    F1             290     1001 00010 2
                    F2             291     1001 00011 3
                    F3             292     1001 00100 4
                    F4             293     1001 00101 5
                    F5             294     1001 00110 6
                    F6             295     1001 00111 7
                    F7             296     1001 01000 8
                    F8             297     1001 01001 9
                    F9             298     1001 01010 10
                    F10            299     1001 01011 11
                    F11            300     1001 01100 12
                    F12            301     1001 01101 13
                    F13            302     1001 01110 14
                    F14            303     1001 01111 15
                    F15            304     1001 10000 16
                    F16            305     1001 10001 17
                    F17            306     1001 10010 18
                    F18            307     1001 10011 19
                    F19            308     1001 10100 20
                    F20            309     1001 10101 21
                    F21            310     1001 10110 22
                    F22            311     1001 10111 23
                    F23            312     1001 11000 24
                    F24            313     1001 11001 25
                    F25            314     1001 11010 26
                }

                Bitmask:0x100 {
                    KP_0           320     1010 00000 0
                    KP_1           321     1010 00001 1
                    KP_2           322     1010 00010 2
                    KP_3           323     1010 00011 3
                    KP_4           324     1010 00100 4
                    KP_5           325     1010 00101 5
                    KP_6           326     1010 00110 6
                    KP_7           327     1010 00111 7
                    KP_8           328     1010 01000 8
                    KP_9           329     1010 01001 9
                    KP_DECIMAL     330     1010 01010 10
                    KP_DIVIDE      331     1010 01011 11
                    KP_MULTIPLY    332     1010 01100 12
                    KP_SUBTRACT    333     1010 01101 13
                    KP_ADD         334     1010 01110 14
                    KP_ENTER       335     1010 01111 15
                    KP_EQUAL       336     1010 10000 16

                    LEFT_SHIFT     340     1010 10100 20
                    LEFT_CONTROL   341     1010 10101 21
                    LEFT_ALT       342     1010 10110 22
                    LEFT_SUPER     343     1010 10111 23
                    RIGHT_SHIFT    344     1010 11000 24
                    RIGHT_CONTROL  345     1010 11001 25
                    RIGHT_ALT      346     1010 11010 26
                    RIGHT_SUPER    347     1010 11011 27
                    MENU           348     1010 11100 28
                }
            }
    */

    static void _CosaPanelKeyinputGLFW(GLFWwindow *pGLFWWindow, cosaI32 GLFWIKey, cosaI32 GLFWScancode, cosaI32 GLFWAction, cosaI32 GLFWMods) {
        if ((GLFWIKey == GLFW_KEY_UNKNOWN) || (GLFWIKey < GLFW_KEY_SPACE) || (GLFWIKey > GLFW_KEY_MENU)) { return; }
        cosaU32 GLFWKey = (COSA_MACRO_SIGNED_TO_UNSIGNED(GLFWIKey)) & 0x1FF;

        cosaU8 offset = cosaR5B(GLFWKey);
        cosaU8 bank = 0;

        switch (GLFWKey >> 5) {
            case 0x140: {
                if (GLFWKey > GLFW_KEY_KP_EQUAL) {
                    bank = 0;
                    offset -= 20;
                } else { bank = 1; }
                break;
            }
            case 0x120: {
                bank = 2;
                offset -= 2;
                break;
            }
            case 0x100: {
                if (cosaR1B_O(GLFWKey, 4) == 0x10) {
                    bank = 3;
                    offset -= 24;
                } else { bank = 4; }
                break;
            }
            case 0xA0: {
                bank = 5;
                offset -= 1;
                break;
            }
            case 0x60: {
                bank = 6;
                break;
            }
            case 0x40: {
                bank = 7;
                offset -= 1;
                break;
            }
            case 0x20: {
                switch (offset) {
                    case 0x0: {
                        bank = 9;
                        break;
                    }
                    case 0x7: {
                        bank = 9;
                        offset -= 6;
                        break;
                    }
                    case 0x1B: {
                        bank = 9;
                        offset -= 25;
                        break;
                    }
                    case 0x1D: {
                        bank = 9;
                        offset -= 26;
                        break;
                    }
                    default: {
                        bank = 8;
                        break;
                    }
                }
                break;
            }
        }
    }

    static void _CosaPanelExtensionCleanupGLFW(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock) {
        (void)_CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;
            return;
        }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBTrue) {
            pCosaGLFW->isInitialized = cosaBFalse;
            pCosaGLFW->monitorCount = 0;
            pCosaGLFW->pBMonitors = NULL;
        }
        glfwTerminate();
    }

    static void _CosaPanelExtensionInitGLFW(cosaContext *pContext, _CosaExtension *pExtension, _cosaGLFW_EXT *pCosaGLFW) {
        if (glfwInit() == GLFW_FALSE) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_LIBACC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_LIBACC;
        }
        pCosaGLFW->isInitialized = cosaBTrue;
        pExtension->pCleanup = _CosaPanelExtensionCleanupGLFW;
    }

    void linuxCosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel) {
        cosaU8 R = cosaR8B_O(pPanel->color, 24) >> 24;
        cosaU8 G = cosaR8B_O(pPanel->color, 16) >> 16;
        cosaU8 B = cosaR8B_O(pPanel->color, 8) >> 8;
        cosaU8 A = cosaR8B(pPanel->color) >> 0;
        glClearColor(
            (R > 0) ? (GLfloat)(1.0f/(255.0f/R)) : 0.0f,
            (G > 0) ? (GLfloat)(1.0f/(255.0f/G)) : 0.0f,
            (B > 0) ? (GLfloat)(1.0f/(255.0f/B)) : 0.0f,
            (A > 0) ? (GLfloat)(1.0f/(255.0f/A)) : 0.0f
        );
        glClear(GL_COLOR_BUFFER_BIT);
    }

    void linuxCosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        glfwSwapBuffers(pPanelMD_GLFW->pWindow);
        glfwPollEvents();

        if (glfwWindowShouldClose(pPanelMD_GLFW->pWindow) == GLFW_TRUE) { pPanel->flags |= COSA_PANEL_ACTIVE; }
    }

    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        if (pPanel->pIconPath != NULL) { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        glfwMakeContextCurrent(NULL);
        glfwDestroyWindow(pPanelMD_GLFW->pWindow);
        pPanelMD_GLFW->icon.width = 0;
        pPanelMD_GLFW->icon.height = 0;
        pPanelMD_GLFW->icon.pixels = NULL;
        pPanelMD_GLFW->pMonitor = NULL;
        pPanelMD_GLFW->pWindow = NULL;
        pPanel->pBlock->flags = 0x00;
        pPanel->pBlock = NULL;
        pPanel->pIconPath = NULL;
        pPanel->pTitle = NULL;
        pPanel->posX = 0;
        pPanel->posY = 0;
        pPanel->color = 0x000000FF;
        pPanel->width = 0;
        pPanel->height = 0;
        pPanel->flags = 0x0000;
    }

    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel) {
        _CosaExtension *pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, COSA_STACK_SIZE_SS);
        cosaU32 panelExtSlot = _CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;

            _CosaExtension panelExt = {0};

            linuxCosaCreateBlock(pContext, &panelExt.pBlock, 1, sizeof(_cosaGLFW_EXT));
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

            (void)memset(panelExt.pBlock->addr, 0, panelExt.pBlock->count * panelExt.pBlock->byteSize);
            panelExt.ID = COSA_EXTENSION_PANEL_ID;

            panelExtSlot = _CosaExtensionCreate(pContext, &panelExt);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        } else if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBFalse) {
            _CosaPanelExtensionInitGLFW(pContext, &pExtStack[panelExtSlot], pCosaGLFW);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                pExtStack[panelExtSlot].pBlock->flags = 0x00;
                _CosaExtensionRemove(pContext, panelExtSlot);
            }
        }
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, COSA_PANEL_CONTEXT_MAJOR);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, COSA_PANEL_CONTEXT_MINOR);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

        glfwWindowHint(GLFW_POSITION_X, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_POSITION_Y, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_CONTEXT_DEBUG,           ((pPanel->flags >> 9) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, ((pPanel->flags >> 1) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_FOCUS_ON_SHOW,           ((pPanel->flags >> 2) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #if defined(USING_X11) || defined(COSA_OS_WINDOWS)
            glfwWindowHint(GLFW_SCALE_TO_MONITOR,  ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #elif defined(USING_WAYLAND)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #endif

        #if defined(COSA_OS_MACOS)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
        #else
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_FALSE);
        #endif

        if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
            glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
            glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
            glfwWindowHint(GLFW_MAXIMIZED, GLFW_FALSE);
            glfwWindowHint(GLFW_VISIBLE,   GLFW_FALSE);
            glfwWindowHint(GLFW_FOCUSED,   GLFW_FALSE);
            glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & COSA_PANEL_MOUSE_PASSTHROUGH) == COSA_PANEL_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_AUTO_ICONIFY,      ((pPanel->flags & COSA_PANEL_AUTO_ICONIFY)      == COSA_PANEL_AUTO_ICONIFY     ) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_CENTER_CURSOR,     ((pPanel->flags & COSA_PANEL_CENTER_CURSOR)     == COSA_PANEL_CENTER_CURSOR    ) ? GLFW_TRUE : GLFW_FALSE);
        } else {
            glfwWindowHint(GLFW_MAXIMIZED, ((pPanel->flags & COSA_PANEL_MAXIMIZED) == COSA_PANEL_MAXIMIZED) ? GLFW_TRUE : GLFW_FALSE);

            if ((pPanel->flags & COSA_PANEL_DECORATED) == COSA_PANEL_DECORATED) {
                glfwWindowHint(GLFW_DECORATED, GLFW_TRUE);
                glfwWindowHint(GLFW_RESIZABLE, ((pPanel->flags & COSA_PANEL_RESIZABLE) == COSA_PANEL_RESIZABLE) ? GLFW_TRUE : GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
                glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & GLFW_MOUSE_PASSTHROUGH) == GLFW_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            }

            if ((pPanel->flags & COSA_PANEL_VISIBLE) == COSA_PANEL_VISIBLE) {
                glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);
                glfwWindowHint(GLFW_FOCUSED, ((pPanel->flags & COSA_PANEL_FOCUSED) == COSA_PANEL_FOCUSED) ? GLFW_TRUE : GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
                glfwWindowHint(GLFW_FOCUSED, GLFW_FALSE);
            }
        }


        linuxCosaCreateBlock(pContext, &pPanel->pBlock, 1, sizeof(cosaPanel_GLFW));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        (void)memset(pPanel->pBlock->addr, 0, pPanel->pBlock->count * pPanel->pBlock->byteSize);

        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        pPanelMD_GLFW->pWindow = glfwCreateWindow(pPanel->width, pPanel->height, pPanel->pTitle, NULL, NULL);
        if (pPanelMD_GLFW->pWindow == NULL) {
            pPanel->pBlock->flags = 0x00;
            pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
            return;
        }
        glfwMakeContextCurrent(pPanelMD_GLFW->pWindow);
        glfwSwapInterval(1); // V-Sync.

        if (pPanel->pIconPath != NULL) {
            cosaImage image;
            linuxCosaOpenImage(pContext, &image, pPanel->pIconPath);
            if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
                pPanelMD_GLFW->icon.width = image.width;
                pPanelMD_GLFW->icon.height = image.height;
                pPanelMD_GLFW->icon.pixels = image.pData;
                glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 1, &pPanelMD_GLFW->icon);
                linuxCosaCloseImage(pContext, &image);

                pPanelMD_GLFW->icon.width = 0;
                pPanelMD_GLFW->icon.height = 0;
                pPanelMD_GLFW->icon.pixels = NULL;
            } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }

        if (((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) ||
            ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) ||
            ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y)) {
                if (pCosaGLFW->pBMonitors == NULL) {
                    cosaI32 monitorCount = 0;
                    pCosaGLFW->pBMonitors = glfwGetMonitors(&monitorCount);
                    if ((monitorCount == 0) || (pCosaGLFW->pBMonitors == NULL)) {
                        pCosaGLFW->monitorCount = 0;
                        pCosaGLFW->pBMonitors = NULL;
                        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;

                        linuxCosaDestroyPanel(pContext, pPanel);
                        return;
                    }
                    pCosaGLFW->monitorCount = COSA_MACRO_SIGNED_TO_UNSIGNED(monitorCount);
                }
                pPanelMD_GLFW->pMonitor = NULL;

                for (cosaU32 i = 0; i < pCosaGLFW->monitorCount; i++) {
                    if (pCosaGLFW->pBMonitors[i] != NULL) {
                        pPanelMD_GLFW->pMonitor = pCosaGLFW->pBMonitors[i];
                        break;
                    }
                }
                if (pPanelMD_GLFW->pMonitor == NULL) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_NOMDIM;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_NOMDIM;
                } else {
                    const GLFWvidmode *pVideoMode = glfwGetVideoMode(pPanelMD_GLFW->pMonitor);
                    if (pVideoMode == NULL) {
                        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
                    } else if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
                        pPanel->width = pVideoMode->width;
                        pPanel->height = pVideoMode->height;
                        pPanel->posX = 0;
                        pPanel->posY = 0;
                        glfwSetWindowMonitor(pPanelMD_GLFW->pWindow, pPanelMD_GLFW->pMonitor, pPanel->posX, pPanel->posY, pPanel->width, pPanel->height, pVideoMode->refreshRate);
                    } else {
                        cosaI32 gotWindowPosX = 0;
                        cosaI32 gotWindowPosY = 0;
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);

                        cosaI32 gotMonitorPosX = 0;
                        cosaI32 gotMonitorPosY = 0;
                        glfwGetMonitorPos(pPanelMD_GLFW->pMonitor, &gotMonitorPosX, &gotMonitorPosY);
                        if ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) {
                            gotWindowPosX = gotMonitorPosX + pPanel->posX;
                            if ((gotWindowPosX + pPanel->width) > pVideoMode->width) {
                                gotWindowPosX -= (gotWindowPosX + pPanel->width) - pVideoMode->width;
                                if (gotWindowPosX < gotMonitorPosX) { gotWindowPosX = gotMonitorPosX; }
                            }
                        }
                        if ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y) {
                            gotWindowPosY = gotMonitorPosY + pPanel->posY;
                            if ((gotWindowPosY + pPanel->height) > pVideoMode->height) {
                                gotWindowPosY -= (gotWindowPosY + pPanel->height) - pVideoMode->height;
                                if (gotWindowPosY < gotMonitorPosY) { gotWindowPosY = gotMonitorPosY; }
                            }
                        }
                        glfwSetWindowPos(pPanelMD_GLFW->pWindow, gotWindowPosX, gotWindowPosY);
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);
                    }
                }
        }
        glfwSetKeyCallback(pPanelMD_GLFW->pWindow, _CosaPanelKeyinputGLFW);


        (void)gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
        glViewport(0, 0, pPanel->width, pPanel->height);
    }
#endif