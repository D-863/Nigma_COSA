#include "cosaLinux.h"
#include "../headers/error.h"
#include <math.h>

void _ExpandContextBlockPageRegion(cosaContext *pContext) {
    cosaPrintF("pContext->blockPage.count<%lu>\n", pContext->blockPage.count);
    COSA_PAGE_BLOCK_EXPAND(pContext->blockPage.count);
    cosaPrintF("pContext->blockPage.count<%lu>\n", pContext->blockPage.count);

    cosaMemBlock *pNewBlocks = mmap(
        NULL,
        pContext->blockPage.count * sizeof(cosaMemBlock),
        COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
        COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
        -1, 0);
    if (pNewBlocks == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);

        pContext->blockPage.count = pContext->blockPage.top;
        return;
    }
    (void)memcpy(pNewBlocks, pContext->blockPage.pBlocks, pContext->blockPage.top * sizeof(cosaMemBlock));
    (void)memset(pNewBlocks + pContext->blockPage.top, 0, (pContext->blockPage.count - pContext->blockPage.top) * sizeof(cosaMemBlock));

    if (munmap(pContext->blockPage.pBlocks, pContext->blockPage.top * sizeof(cosaMemBlock)) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)munmap(pNewBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));

        pContext->blockPage.count = pContext->blockPage.top;
        return;
    }
    pContext->blockPage.pBlocks = pNewBlocks;
} 

void _ExpandContextMemPageRegion(cosaContext *pContext) {
    COSA_PAGE_MEM_EXPAND(pContext->memPage.size);
    cosaUSize i;
    for (i = 0; (i < COSA_PAGE_MEM_MAX_CONTIGUOUS_EXPANSION) && (pContext->memPage.top >= pContext->memPage.size); ++i) {
        COSA_PAGE_MEM_EXPAND(pContext->memPage.size);
    }
    if (i == (COSA_PAGE_MEM_MAX_CONTIGUOUS_EXPANSION - 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPCLC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPCLC;
        #if defined(COSA_ENABLE_DEBUG)
            cosaPrintF("(_ExpandContextMemPageRegion)i<%lu>\n", i);
            cosaPrintF("(_ExpandContextMemPageRegion)pContext->memPage.size<%lu>\n", pContext->memPage.size);
            cosaPrintF("(_ExpandContextMemPageRegion)pContext->memPage.top<%lu>\n", pContext->memPage.top);
        #endif
        return;
    }

    cosaU8 *pNewMem = mmap(
        NULL,
        pContext->memPage.size,
        COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
        COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
        -1, 0);
    if (pNewMem == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);

        pContext->memPage.size = pContext->memPage.top;
        return;
    }
    (void)memcpy(pNewMem, pContext->memPage.pMem, pContext->memPage.top);
    (void)memset(pNewMem + pContext->memPage.top, 0, pContext->memPage.size - pContext->memPage.top);

    if (munmap(pContext->memPage.pMem, pContext->memPage.top) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)munmap(pNewMem, pContext->memPage.size);

        pContext->memPage.size = pContext->memPage.top;
        return;
    }

    bool isNewMemAddrBehind = cosaBFalse;
    cosaUSize newMemAddrDiff = 0;
    if (pContext->memPage.pMem < pNewMem) {
        isNewMemAddrBehind = cosaBFalse;
        newMemAddrDiff = pNewMem - pContext->memPage.pMem;
    } else {
        isNewMemAddrBehind = cosaBTrue;
        newMemAddrDiff = pContext->memPage.pMem - pNewMem;
    }

    for (i = 0; i < pContext->blockPage.top; ++i) {
        if (isNewMemAddrBehind == cosaBFalse) {
            pContext->blockPage.pBlocks[i].addr += newMemAddrDiff;
        } else {
            pContext->blockPage.pBlocks[i].addr -= newMemAddrDiff;
        }
    }

    pContext->memPage.pMem = pNewMem;
} 

void linuxInitializeCosaMD(cosaContext *pContext, _CosaMD *pCosaMD) {
    cosaU16 isBigEndian = 0x0001;
    pCosaMD->systemInfo.isBigEndian = cosaIsEndianBig(isBigEndian);
    if (getrlimit(RLIMIT_NOFILE, &pCosaMD->systemInfo.maxFileDescs) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
}

cosaMemBlock *linuxCosaMemoryAlloc(cosaContext *pContext, cosaUSize count, cosaUSize byteSize) {
    cosaBool foundBlock = cosaBFalse;
    cosaUSize blockSlot;
    cosaUSize currentRegion;
    cosaUSize blockRegion = count * byteSize;
    for (blockSlot = 0; blockSlot < pContext->blockPage.top; ++blockSlot) {
        if (cosaRB(pContext->blockPage.pBlocks[blockSlot].flags) == COSA_MEM_FLAG_IS_FREE) {
            currentRegion = pContext->blockPage.pBlocks[blockSlot].count;
            currentRegion *= pContext->blockPage.pBlocks[blockSlot].byteSize;
            if (currentRegion >= blockRegion) {
                foundBlock = cosaBTrue;
                break;
            }
        }
    }
    if (foundBlock == cosaBTrue) {
        if (currentRegion > blockRegion) {
            if (pContext->blockPage.top >= pContext->blockPage.count) {
                _ExpandContextBlockPageRegion(pContext);
                if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
            }
            cosaUSize excessBlockSlot = pContext->blockPage.top;
            pContext->blockPage.pBlocks[excessBlockSlot].flags = 0x00;
            cosaCB(pContext->blockPage.pBlocks[excessBlockSlot].flags);

            pContext->blockPage.pBlocks[excessBlockSlot].byteSize = sizeof(cosaU8);
            pContext->blockPage.pBlocks[excessBlockSlot].count = currentRegion - blockRegion;
            pContext->blockPage.pBlocks[excessBlockSlot].addr = pContext->blockPage.pBlocks[blockSlot].addr + blockRegion;
            ++pContext->blockPage.top;
        }
        pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
        cosaSB(pContext->blockPage.pBlocks[blockSlot].flags);

        pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
        pContext->blockPage.pBlocks[blockSlot].count = count;
        return &pContext->blockPage.pBlocks[blockSlot];
    }

    if (pContext->blockPage.top >= pContext->blockPage.count) {
        _ExpandContextBlockPageRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    }
    blockSlot = pContext->blockPage.top;
    cosaPrintF("blockSlot<%lu>\n", blockSlot);
    ++pContext->blockPage.top;

    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    cosaSB(pContext->blockPage.pBlocks[blockSlot].flags);

    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    pContext->blockPage.pBlocks[blockSlot].addr = pContext->memPage.pMem + pContext->memPage.top;

    if (pContext->memPage.top >= pContext->memPage.size) {
        _ExpandContextMemPageRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    }
    pContext->memPage.top += blockRegion;

    return &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaUSize top = (cosaUSize)pStack->addr[0];
    cosaUSize newTop = top + (itemSize + sizeof(cosaUSize));

    if (newTop > COSA_STACK_SIZE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pStackMem = (cosaU8*)(pStack->addr + sizeof(cosaUSize));
    pStackMem += top;

    (void)memcpy(pStackMem, pItem, itemSize);
    pStackMem += itemSize;

    (void)memcpy(pStackMem, &itemSize, sizeof(cosaUSize));
    (void)memcpy(pStack->addr, &newTop, sizeof(cosaUSize));
}

void *linuxCosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    cosaUSize *pTop = (cosaUSize*)pStack->addr;
    if (*pTop < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        if (pItemSize != NULL) { *pItemSize = 0; }
        return NULL;
    }
    cosaU8 *pStackMem = (cosaU8*)(pStack->addr + sizeof(cosaUSize));
    *pTop -= sizeof(cosaUSize);

    cosaUSize itemSize = 0;;
    (void)memcpy(&itemSize, pStackMem + *pTop, sizeof(cosaUSize));
    *pTop -= itemSize;

    if (pItemSize != NULL) { *pItemSize = itemSize; }
    return pStackMem + *pTop;
}

cosaMemBlock *linuxCosaCreateStack(cosaContext *pContext) {
    cosaMemBlock *pBlock = linuxCosaMemoryAlloc(pContext, COSA_STACK_SIZE + sizeof(cosaUSize), sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    return pBlock;
}

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pQueue->addr;
    cosaU8 *pQueueBks = (cosaU8*)(pQueue->addr + sizeof(cosaQueue_MD));

    cosaBool foundSlot = cosaBFalse;
    cosaUSize newTop;
    for (cosaUSize i = 0; i < pQueue_MD->count; ++i) {
        newTop = (pQueue_MD->top + i) % pQueue_MD->count;
        if (pQueueBks[newTop] == 0x00) {
            pQueue_MD->top = newTop;
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBFalse) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    pQueueBks[newTop] = 0x01;

    cosaU8 *pQueueMem = (cosaU8*)(pQueue->addr + pQueue_MD->count + sizeof(cosaQueue_MD));
    (void)memcpy(pQueueMem + (newTop * pQueue_MD->byteSize), pItem, pQueue_MD->byteSize);
}

void linuxCosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue, cosaUSize elemID) {
    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pQueue->addr;
    if (elemID > pQueue_MD->count) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    cosaU8 *pQueueBks = (cosaU8*)(pQueue->addr + sizeof(cosaQueue_MD));
    pQueueBks[elemID] = 0x00;
}

void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pQueue->addr;
    cosaU8 *pQueueBks = (cosaU8*)(pQueue->addr + sizeof(cosaQueue_MD));

    cosaBool foundSlot = cosaBFalse;
    cosaUSize newNext;
    for (cosaUSize i = 0; i < pQueue_MD->count; ++i) {
        newNext = (pQueue_MD->next + i) % pQueue_MD->count;
        if (pQueueBks[newNext] == 0x01) {
            pQueue_MD->next = (newNext + 1) % pQueue_MD->count;;
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBFalse) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }

    cosaU8 *pQueueMem = (cosaU8*)(pQueue->addr + pQueue_MD->count + sizeof(cosaQueue_MD));
    return pQueueMem + (newNext * pQueue_MD->byteSize);
}

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize) {
    cosaMemBlock *pBlock = linuxCosaMemoryAlloc(pContext, (count * byteSize) + count + sizeof(cosaQueue_MD), sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaQueue_MD *pQueue_MD = (cosaQueue_MD*)pBlock->addr;
    pQueue_MD->byteSize = byteSize;
    pQueue_MD->count = count;

    return pBlock;
}

cosaFile *linuxCosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]) {
    cosaFile *pFile = NULL;
    cosaU32 fileSlot;
    for (fileSlot = 0; fileSlot < pContext->filePage.count; ++fileSlot) {
        if (pContext->filePage.pFiles[fileSlot].desc == -1) {
            pFile = &pContext->filePage.pFiles[fileSlot];
            break;
        }
    }
    if (pFile == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
        return NULL;
    }
    cosaU8 fileFlags = cosaR3B(flags, 0);
    cosaI32 memFlags = cosaR2B(fileFlags, 0);

    pFile->desc = open(filePath, memFlags - 1);
    if (pFile->desc < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return NULL;
    }

    if (fstat(pFile->desc, &pFile->info) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    pFile->pMData = mmap(
        NULL, pFile->info.st_size,
        memFlags, COSA_MEM_FLAG_PVE,
        pFile->desc, 0);
    if (pFile->pMData == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    return pFile;
}

void linuxCosaFileClose(cosaContext *pContext, cosaFile *pFile) {
    cosaI32 errMem = munmap(pFile->pMData, pFile->info.st_size);
    cosaI32 err = close(pFile->desc);
    pFile->flags = 0x00;

    cosaU8 errFlg = 0x00;
    (errMem < 0) ? cosaSB(errFlg) : cosaCB(errFlg);
    (err < 0) ? cosaS1B(errFlg, 1) : cosaC1B(errFlg, 1);

    switch (errFlg) {
        case 0x03: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            break;
        }
        case 0x02: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->pMData = NULL;
            break;
        }
        case 0x01: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->desc = -1;
            break;
        }
        default: {
            pFile->pMData = NULL;
            pFile->desc = -1;
            break;
        }
    }
}

/*void linuxCosaOpenQOI(cosaContext *pContext, cosaChar filePath[]) {
    cosaUSize pathLength = strlen(filePath);
    if (strncmp(filePath + (pathLength - 4), ".qoi", 4) != 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    cosaFile *pFile = linuxCosaFileOpen(pContext, COSA_FILE_FLAG_PERM_RD, filePath);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaU32 sigQOI = *((cosaU32*)pFile->pMData);
    cosaBool isBigEndian = ((_CosaMD*)pContext->blockPage.pBlocks[0].addr)->systemInfo.isBigEndian;
    if (isBigEndian == cosaBFalse) { _EndianSWP32B(&sigQOI); }
    if (sigQOI != 0x716F6966) {
        linuxCosaFileClose(pContext, pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return;
    }
    cosaPrint("Valid sigQOI.");
    cosaU32 width  = *((cosaU32*)(pFile->pMData + 4));
    cosaU32 height = *((cosaU32*)(pFile->pMData + 8));
    cosaU8 chan    = 4; // *((cosaU32*)(pFile->pMData + 12));
    //cosaU8 cspa    = *((cosaU32*)pFile->pMData + 13);
    if (isBigEndian == cosaBFalse) {
        _EndianSWP32B(&width);
        _EndianSWP32B(&height);
    }

    cosaMemBlock *pImageBlock = linuxCosaMemoryAlloc(pContext, (width * height), chan);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        linuxCosaFileClose(pContext, pFile);
        return;
    }

    //cosaU32 arr[64] = {0};
    //cosaU8 bytes[4] = {0};

    //cosaU32 prev = 0x000000FF;
    cosaU32 curr = 0x00000000;
    cosaUSize pixIndex = 0;
    for (cosaUSize top = 14; top < pImageBlock->count; ++top) {
        cosaU8 block = pFile->pMData[top];
        switch (block & 0xC0) {
            case 0x00: {
                //QOI_OP_INDEX
                curr = 0xFFFFFFFF;
                break;
            }
            case 0x40: {
                //QOI_OP_DIFF
                curr = 0xFFFFFFFF;
                break;
            }
            case 0x80: {
                //QOI_OP_LUMA
                curr = 0xFFFFFFFF;
                break;
            }
            case 0xC0: {
                switch (block) {
                    case 0xFE: {
                        //QOI_OP_RGB
                        curr = 0xFFFFFFFF;
                        break;
                    }
                    case 0xFF: {
                        //QOI_OP_RGBA
                        curr = 0xFFFFFFFF;
                        break;
                    }
                    default: {
                        //QOI_OP_RUN
                        curr = cosaR6B(block, 0);
                        break;
                    }
                }
                break;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
                break;
            }
        }
        cosaPrintF("top<%lu>\n", top);
        cosaPrintF("pixIndex<%lu>\n", pixIndex);
        for (cosaU8 i = 0; i < chan; ++i) {
            pImageBlock->addr[pixIndex + i] = cosaR8B(curr, (((chan * 8) - 8) - (i * 8)));
        }
        ++pixIndex;
    }

    stbi_write_png("/mnt/30acb6ae-b008-4e33-aca9-eef8f48610d8/Code/Applications/new/Nigma_CEngine-main/build/mypng.png", width, height, chan, pImageBlock->addr, width * chan);

    pImageBlock->flags = 0x00;
    linuxCosaFileClose(pContext, pFile);
    assert(pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM);
}*/

void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]) {
    cosaUSize pathLength = strlen(filePath);
    pImage->type = 0;
    cosaChar imageTypes[COSA_IMAGE_TYPE_COUNT][COSA_IMAGE_TYPE_LENGTH] = COSA_IMAGE_TYPES;
    for (cosaU8 i = 0; i < COSA_IMAGE_TYPE_COUNT; ++i) {
        if (strncmp(filePath + (pathLength - 4), imageTypes[i], 4) == 0) {
            pImage->type = i + 1;
            break;
        }
    }
    if (pImage->type == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
        return;
    }
    pImage->pFile = linuxCosaFileOpen(pContext, COSA_FILE_FLAG_PERM_RD, filePath);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaI32 w = 0;
    cosaI32 h = 0;
    cosaI32 c = 0;
    pImage->pData = stbi_load_from_memory(pImage->pFile->pMData, pImage->pFile->info.st_size, &w, &h, &c, 0);
    if (pImage->pData == NULL) {
        linuxCosaFileClose(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
        return;
    } else if ((w < 1) || (h < 1) || (c < 1)) {
        linuxCosaFileClose(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
        return;
    }
    pImage->width    = COSA_MACRO_SIGNED_TO_UNSIGNED(w);
    pImage->height   = COSA_MACRO_SIGNED_TO_UNSIGNED(h);
    pImage->channels = COSA_MACRO_SIGNED_TO_UNSIGNED(c);
}

void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage) {
    if (pImage->pData != NULL) {
        stbi_image_free(pImage->pData);
        pImage->pData = NULL;
        pImage->width = 0;
        pImage->height = 0;
        pImage->channels = 0;
    }
    if (pImage->pFile != NULL) {
        linuxCosaFileClose(pContext, pImage->pFile);
        if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
            pImage->pFile = NULL;
            pImage->type = 0;
        }
    }
}

#if defined(COSA_ENABLE_EXTENSIONS)
    cosaU8 _CosaExtensionStackFind(cosaContext *pContext, cosaU8 extensionID) {
        _CosaMD *pCosaMD = (_CosaMD*)pContext->blockPage.pBlocks[0].addr;
        cosaU8 top = (cosaU8)pCosaMD->pExtensionStack->addr[0];
        if (top == 0) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
            return 0;
        }

        _CosaExtension *pStackMem = (_CosaExtension*)(pCosaMD->pExtensionStack->addr + sizeof(cosaU8));

        cosaBool foundSlot = cosaBFalse;
        cosaU8 extensionSlot;
        for (extensionSlot = 0; extensionSlot < top; ++extensionSlot) {
            if (pStackMem[extensionSlot].ID == extensionID) {
                foundSlot = cosaBTrue;
                break;
            }
        }
        if (foundSlot == cosaBFalse) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
        }
        return extensionSlot;
    }

    void _CosaExtensionStackRemove(cosaContext *pContext, cosaU8 extensionSlot) {
        _CosaMD *pCosaMD = (_CosaMD*)pContext->blockPage.pBlocks[0].addr;

        cosaU8 *pTop = (cosaU8*)pCosaMD->pExtensionStack->addr;
        _CosaExtension *pExtStack = (_CosaExtension*)(pCosaMD->pExtensionStack->addr + sizeof(cosaU8));
        for (cosaU8 i = extensionSlot + 1; i < *pTop; ++i) {
            pExtStack[extensionSlot].ID = pExtStack[i].ID;
            pExtStack[extensionSlot].pBlock = pExtStack[i].pBlock;
            ++extensionSlot;
        }
        if (*pTop > 0) {
            *pTop -= 1;
        }

        (*pExtStack[extensionSlot].pCleanup)(pContext, pExtStack[extensionSlot].ID, pExtStack[extensionSlot].pBlock);
        pExtStack[extensionSlot].ID = 0x00;
        pExtStack[extensionSlot].pCleanup = NULL;
        pExtStack[extensionSlot].pBlock = NULL;
    }

    cosaU8 _CosaExtensionStackPush(cosaContext *pContext) {
        _CosaMD *pCosaMD = (_CosaMD*)pContext->blockPage.pBlocks[0].addr;

        cosaU8 *pTop = (cosaU8*)pCosaMD->pExtensionStack->addr;
        cosaU8 top = *pTop;
        if (top >= COSA_EXTENSION_COUNT) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        } else {
            *pTop += 1;
        }
        return top;
    }

    cosaU8 _CosaExtensionStackPop(cosaContext *pContext) {
        _CosaMD *pCosaMD = (_CosaMD*)pContext->blockPage.pBlocks[0].addr;

        cosaU8 *pTop = (cosaU8*)pCosaMD->pExtensionStack->addr;
        cosaU8 top = *pTop;
        if (top < 1) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        } else {
            *pTop -= 1;
        }
        return top;
    }
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    void _CosaPanelExtensionCleanupGlfw(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock) {
        (void)_CosaExtensionStackFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_STR;
            return;
        }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBTrue) {
            pCosaGLFW->isInitialized = cosaBFalse;
            pCosaGLFW->monitorCount = 0;
            pCosaGLFW->pBMonitors = NULL;
        }
        glfwTerminate();
    }

    void _CosaPanelExtensionInitGlfw(cosaContext *pContext, _CosaExtension *pExtension, _cosaGLFW_EXT *pCosaGLFW) {
        if (glfwInit() == GLFW_FALSE) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_LIBACC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_LIBACC;
        }
        pCosaGLFW->isInitialized = cosaBTrue;
        pExtension->pCleanup = _CosaPanelExtensionCleanupGlfw;
    }

    void linuxCosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel) {
        cosaU8 R = cosaR8B(pPanel->color, 24) >> 24;
        cosaU8 G = cosaR8B(pPanel->color, 16) >> 16;
        cosaU8 B = cosaR8B(pPanel->color, 8) >> 8;
        cosaU8 A = cosaR8B(pPanel->color, 0) >> 0;
        glClearColor(
            (R > 0) ? (GLfloat)(1.0f/(255.0f/R)) : 0.0f,
            (G > 0) ? (GLfloat)(1.0f/(255.0f/G)) : 0.0f,
            (B > 0) ? (GLfloat)(1.0f/(255.0f/B)) : 0.0f,
            (A > 0) ? (GLfloat)(1.0f/(255.0f/A)) : 0.0f
        );
        glClear(GL_COLOR_BUFFER_BIT);
    }

    void linuxCosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        glfwSwapBuffers(pPanelMD_GLFW->pWindow);
        glfwPollEvents();

        if (glfwWindowShouldClose(pPanelMD_GLFW->pWindow) == GLFW_TRUE) { cosaWB(pPanel->flags, COSA_PANEL_ACTIVE); }
    }

    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        if (pPanel->pIconPath != NULL) { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        glfwMakeContextCurrent(NULL);
        glfwDestroyWindow(pPanelMD_GLFW->pWindow);
        pPanelMD_GLFW->icon.width = 0;
        pPanelMD_GLFW->icon.height = 0;
        pPanelMD_GLFW->icon.pixels = NULL;
        pPanelMD_GLFW->pMonitor = NULL;
        pPanelMD_GLFW->pWindow = NULL;
        pPanel->pBlock->flags = 0x00;
        pPanel->pBlock = NULL;
        pPanel->pIconPath = NULL;
        pPanel->pTitle = NULL;
        pPanel->posX = 0;
        pPanel->posY = 0;
        pPanel->color = 0x000000FF;
        pPanel->width = 0;
        pPanel->height = 0;
        pPanel->flags = 0x0000;
    }

    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel) {
        _CosaMD *pCosaMD = (_CosaMD*)pContext->blockPage.pBlocks[0].addr;
        _CosaExtension *pExtStack = (_CosaExtension*)(pCosaMD->pExtensionStack->addr + sizeof(cosaU8));

        cosaU8 panelExtSlot = _CosaExtensionStackFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_STR;

            panelExtSlot = _CosaExtensionStackPush(pContext);
            if (pContext->errorNUM == COSA_CONTEXT_ERRN_OOBSP) { return; }
            pExtStack[panelExtSlot].ID = COSA_EXTENSION_PANEL_ID;
            pExtStack[panelExtSlot].pBlock = linuxCosaMemoryAlloc(pContext, 1, sizeof(_cosaGLFW_EXT));
            (void)memset(pExtStack[panelExtSlot].pBlock->addr, 0, pExtStack[panelExtSlot].pBlock->count * pExtStack[panelExtSlot].pBlock->byteSize);
        }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBFalse) {
            _CosaPanelExtensionInitGlfw(pContext, &pExtStack[panelExtSlot], pCosaGLFW);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                pExtStack[panelExtSlot].pBlock->flags = 0x00;
                _CosaExtensionStackRemove(pContext, panelExtSlot);
            }
        }
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, COSA_PANEL_CONTEXT_MAJOR);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, COSA_PANEL_CONTEXT_MINOR);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

        glfwWindowHint(GLFW_POSITION_X, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_POSITION_Y, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_CONTEXT_DEBUG,           ((pPanel->flags >> 9) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, ((pPanel->flags >> 1) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_FOCUS_ON_SHOW,           ((pPanel->flags >> 2) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #if defined(USING_X11) || defined(COSA_OS_WINDOWS)
            glfwWindowHint(GLFW_SCALE_TO_MONITOR,  ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #elif defined(USING_WAYLAND)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #endif

        #if defined(COSA_OS_MACOS)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
        #else
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_FALSE);
        #endif

        if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
            glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
            glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
            glfwWindowHint(GLFW_MAXIMIZED, GLFW_FALSE);
            glfwWindowHint(GLFW_VISIBLE,   GLFW_FALSE);
            glfwWindowHint(GLFW_FOCUSED,   GLFW_FALSE);
            glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & COSA_PANEL_MOUSE_PASSTHROUGH) == COSA_PANEL_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_AUTO_ICONIFY,      ((pPanel->flags & COSA_PANEL_AUTO_ICONIFY)      == COSA_PANEL_AUTO_ICONIFY     ) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_CENTER_CURSOR,     ((pPanel->flags & COSA_PANEL_CENTER_CURSOR)     == COSA_PANEL_CENTER_CURSOR    ) ? GLFW_TRUE : GLFW_FALSE);
        } else {
            glfwWindowHint(GLFW_MAXIMIZED, ((pPanel->flags & COSA_PANEL_MAXIMIZED) == COSA_PANEL_MAXIMIZED) ? GLFW_TRUE : GLFW_FALSE);

            if ((pPanel->flags & COSA_PANEL_DECORATED) == COSA_PANEL_DECORATED) {
                glfwWindowHint(GLFW_DECORATED, GLFW_TRUE);
                glfwWindowHint(GLFW_RESIZABLE, ((pPanel->flags & COSA_PANEL_RESIZABLE) == COSA_PANEL_RESIZABLE) ? GLFW_TRUE : GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
                glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & GLFW_MOUSE_PASSTHROUGH) == GLFW_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            }

            if ((pPanel->flags & COSA_PANEL_VISIBLE) == COSA_PANEL_VISIBLE) {
                glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);
                glfwWindowHint(GLFW_FOCUSED, ((pPanel->flags & COSA_PANEL_FOCUSED) == COSA_PANEL_FOCUSED) ? GLFW_TRUE : GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
                glfwWindowHint(GLFW_FOCUSED, GLFW_FALSE);
            }
        }


        pPanel->pBlock = linuxCosaMemoryAlloc(pContext, 1, sizeof(cosaPanel_GLFW));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        (void)memset(pPanel->pBlock->addr, 0, pPanel->pBlock->count * pPanel->pBlock->byteSize);

        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        pPanelMD_GLFW->pWindow = glfwCreateWindow(pPanel->width, pPanel->height, pPanel->pTitle, NULL, NULL);
        if (pPanelMD_GLFW->pWindow == NULL) {
            pPanel->pBlock->flags = 0x00;
            pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
            return;
        }
        glfwMakeContextCurrent(pPanelMD_GLFW->pWindow);
        glfwSwapInterval(1); // V-Sync.

        if (pPanel->pIconPath != NULL) {
            cosaImage image;
            linuxCosaOpenImage(pContext, &image, pPanel->pIconPath);
            if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
                pPanelMD_GLFW->icon.width = image.width;
                pPanelMD_GLFW->icon.height = image.height;
                pPanelMD_GLFW->icon.pixels = image.pData;
                glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 1, &pPanelMD_GLFW->icon);
                linuxCosaCloseImage(pContext, &image);

                pPanelMD_GLFW->icon.width = 0;
                pPanelMD_GLFW->icon.height = 0;
                pPanelMD_GLFW->icon.pixels = NULL;
            } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }

        if (((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) ||
            ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) ||
            ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y)) {
                if (pCosaGLFW->pBMonitors == NULL) {
                    cosaI32 monitorCount = 0;
                    pCosaGLFW->pBMonitors = glfwGetMonitors(&monitorCount);
                    if ((monitorCount == 0) || (pCosaGLFW->pBMonitors == NULL)) {
                        pCosaGLFW->monitorCount = 0;
                        pCosaGLFW->pBMonitors = NULL;
                        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;

                        linuxCosaDestroyPanel(pContext, pPanel);
                        return;
                    }
                    pCosaGLFW->monitorCount = COSA_MACRO_SIGNED_TO_UNSIGNED(monitorCount);
                }
                pPanelMD_GLFW->pMonitor = NULL;

                for (cosaU32 i = 0; i < pCosaGLFW->monitorCount; i++) {
                    if (pCosaGLFW->pBMonitors[i] != NULL) {
                        pPanelMD_GLFW->pMonitor = pCosaGLFW->pBMonitors[i];
                        break;
                    }
                }
                if (pPanelMD_GLFW->pMonitor == NULL) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_NOMDIM;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_NOMDIM;
                } else {
                    const GLFWvidmode *pVideoMode = glfwGetVideoMode(pPanelMD_GLFW->pMonitor);
                    if (pVideoMode == NULL) {
                        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
                    } else if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
                        pPanel->width = pVideoMode->width;
                        pPanel->height = pVideoMode->height;
                        pPanel->posX = 0;
                        pPanel->posY = 0;
                        glfwSetWindowMonitor(pPanelMD_GLFW->pWindow, pPanelMD_GLFW->pMonitor, pPanel->posX, pPanel->posY, pPanel->width, pPanel->height, pVideoMode->refreshRate);
                    } else {
                        cosaI32 gotWindowPosX = 0;
                        cosaI32 gotWindowPosY = 0;
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);

                        cosaI32 gotMonitorPosX = 0;
                        cosaI32 gotMonitorPosY = 0;
                        glfwGetMonitorPos(pPanelMD_GLFW->pMonitor, &gotMonitorPosX, &gotMonitorPosY);
                        if ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) {
                            gotWindowPosX = gotMonitorPosX + pPanel->posX;
                            if ((gotWindowPosX + pPanel->width) > pVideoMode->width) {
                                gotWindowPosX -= (gotWindowPosX + pPanel->width) - pVideoMode->width;
                                if (gotWindowPosX < gotMonitorPosX) { gotWindowPosX = gotMonitorPosX; }
                            }
                        }
                        if ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y) {
                            gotWindowPosY = gotMonitorPosY + pPanel->posY;
                            if ((gotWindowPosY + pPanel->height) > pVideoMode->height) {
                                gotWindowPosY -= (gotWindowPosY + pPanel->height) - pVideoMode->height;
                                if (gotWindowPosY < gotMonitorPosY) { gotWindowPosY = gotMonitorPosY; }
                            }
                        }
                        glfwSetWindowPos(pPanelMD_GLFW->pWindow, gotWindowPosX, gotWindowPosY);
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);
                    }
                }
        }


        (void)gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
        glViewport(0, 0, pPanel->width, pPanel->height);
    }
#endif
