#ifndef NIGMA_COSA_OS_H
#define NIGMA_COSA_OS_H

#if !defined(COSA_OS_NOSUPPORT)
    #if defined(COSA_OS_LINUX)
        #include "Linux/src.h"
        #define cosaOS(x) linuxCosa##x
        #define cosaOS_PRET(x) linuxCosa##x
    #endif

    #define cosaOS_ARGS(...) (__VA_ARGS__)
#else
    #define cosaOS(x)
    #define cosaOS_PRET(x) NULL;
    #define cosaOS_ARGS(...)
#endif

//Operations:
#define osMemSet(...)  cosaOS(MemSet)  cosaOS_ARGS(__VA_ARGS__)
#define osMemCopy(...) cosaOS(MemCopy) cosaOS_ARGS(__VA_ARGS__)
#define osMemSwap(...) cosaOS(MemSwap) cosaOS_ARGS(__VA_ARGS__)

//RAM:
#define osCreateBlock(...)   cosaOS_PRET(CreateBlock) cosaOS_ARGS(__VA_ARGS__)
#define osBlockExpand(...)   cosaOS(BlockExpand)      cosaOS_ARGS(__VA_ARGS__)
#define osBlockShrink(...)   cosaOS(BlockShrink)      cosaOS_ARGS(__VA_ARGS__)
#define osBlockSegment(...)  cosaOS(BlockSegment)     cosaOS_ARGS(__VA_ARGS__)
#define osBlockGetMD(...)    cosaOS(BlockGetMD)       cosaOS_ARGS(__VA_ARGS__)
#define osBlockLinkMD(...)   cosaOS(BlockLinkMD)      cosaOS_ARGS(__VA_ARGS__)
#define osBlockRelinkMD(...) cosaOS(BlockRelinkMD)    cosaOS_ARGS(__VA_ARGS__)
#define osBlockUnlinkMD(...) cosaOS(BlockUnlinkMD)    cosaOS_ARGS(__VA_ARGS__)
#define osFreeBlock(...)     cosaOS(FreeBlock)        cosaOS_ARGS(__VA_ARGS__)
#define osDestroyBlock(...)  cosaOS(DestroyBlock)     cosaOS_ARGS(__VA_ARGS__)

//Stacks:
#define osCreateStackSS(...) cosaOS(CreateStackSS)   cosaOS_ARGS(__VA_ARGS__)
#define osCreateStackSD(...) cosaOS(CreateStackSD)   cosaOS_ARGS(__VA_ARGS__)
#define osCreateStackDS(...) cosaOS(CreateStackDS)   cosaOS_ARGS(__VA_ARGS__)
#define osCreateStackDD(...) cosaOS(CreateStackDD)   cosaOS_ARGS(__VA_ARGS__)
#define osStackSXPush(...)   cosaOS(StackSXPush)     cosaOS_ARGS(__VA_ARGS__)
#define osStackDXPush(...)   cosaOS(StackDXPush)     cosaOS_ARGS(__VA_ARGS__)
#define osStackSXPop(...)    cosaOS_PRET(StackSXPop) cosaOS_ARGS(__VA_ARGS__)
#define osStackDXPop(...)    cosaOS_PRET(StackDXPop) cosaOS_ARGS(__VA_ARGS__)

//Queues:
#define osCreateQueue(...) cosaOS(CreateQueue)    cosaOS_ARGS(__VA_ARGS__)
#define osQueueAdd(...)    cosaOS(QueueAdd)       cosaOS_ARGS(__VA_ARGS__)
#define osQueueNext(...)   cosaOS_PRET(QueueNext) cosaOS_ARGS(__VA_ARGS__)

//Strings:

//Files:
#define osFileOpen(...)       cosaOS(FileOpen)       cosaOS_ARGS(__VA_ARGS__)
#define osFileLoadInfo(...)   cosaOS(FileLoadInfo)   cosaOS_ARGS(__VA_ARGS__)
#define osFileUnloadInfo(...) cosaOS(FileUnloadInfo) cosaOS_ARGS(__VA_ARGS__)
#define osFileCreate(...)     cosaOS(FileCreate)     cosaOS_ARGS(__VA_ARGS__)
#define osFileWrite(...)      cosaOS(FileWrite)      cosaOS_ARGS(__VA_ARGS__)
#define osFileRead(...)       cosaOS(FileRead)       cosaOS_ARGS(__VA_ARGS__)

//CosaContext:
#define osInitContext(...)    cosaOS(InitContext)    cosaOS_ARGS(__VA_ARGS__)
#define osDestroyContext(...) cosaOS(DestroyContext) cosaOS_ARGS(__VA_ARGS__)

#endif