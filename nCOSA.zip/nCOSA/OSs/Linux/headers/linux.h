#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

//Operations:
cosaCompilifics(INLINE, void linuxCosaMemSet(const void *pAddr, cosaU8 value, cosaUSize size));
cosaCompilifics(INLINE, void linuxCosaMemCopy(const void *pSrc, const void *pDest, cosaUSize size));
cosaCompilifics(INLINE, void linuxCosaMemSwap(const void *pSrc, const void *pDest, cosaUSize size));

//RAM:
cosaCompilifics(INLINE, void *linuxCosaCreateBlock(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaBlockSegment(cosaContext *pContext, cosaBlock *pBSrc, cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size));
cosaCompilifics(INLINE, void linuxCosaBlockGetMD(cosaContext *pContext, cosaBlock **ppBAddr, void *pAddr));
cosaCompilifics(INLINE, void linuxCosaBlockLinkMD(cosaContext *pContext, cosaBlock **ppBAddr));
cosaCompilifics(INLINE, void linuxCosaBlockUnlinkMD(cosaContext *pContext, cosaBlock **ppBAddr));
cosaCompilifics(INLINE, void linuxCosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr));
cosaCompilifics(INLINE, void linuxCosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr));

//Stacks:
cosaCompilifics(INLINE, void linuxCosaCreateStackSS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)); //SS -> Type:Static  Size:Static.
cosaCompilifics(INLINE, void linuxCosaCreateStackSD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)); //SD -> Type:Static  Size:Dynamic.
cosaCompilifics(INLINE, void linuxCosaCreateStackDS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size)); //DS -> Type:Dynamic Size:Static.
cosaCompilifics(INLINE, void linuxCosaCreateStackDD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size)); //DD -> Type:Dynamic Size:Dynamic.
cosaCompilifics(INLINE, void linuxCosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, void *pItem));
cosaCompilifics(INLINE, void linuxCosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, void *pItem, cosaUSize itemSize));
cosaCompilifics(INLINE, void *linuxCosaStackSXPop(cosaContext *pContext, cosaBlock *pStack));
cosaCompilifics(INLINE, void *linuxCosaStackDXPop(cosaContext *pContext, cosaBlock *pStack, cosaUSize *pItemSize));

//Queues:
cosaCompilifics(INLINE, void linuxCosaCreateQueue(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaQueueAdd(cosaContext *pContext, cosaBlock *pQueue, void *pItem));
cosaCompilifics(INLINE, void *linuxCosaQueueNext(cosaContext *pContext, cosaBlock *pQueue));

//Files:
cosaCompilifics(INLINE, void linuxCosaCreateFile(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaFileOpen(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaFileWrite(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaFileRead(cosaContext *pContext));

//CosaContext:
cosaCompilifics(INLINE, void linuxCosaInitContext(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaDestroyContext(cosaContext *pContext));

#endif