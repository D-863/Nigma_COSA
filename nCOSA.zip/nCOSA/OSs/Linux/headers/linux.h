#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

//Operations:
cosaCompilifics(INLINE, void linuxCosaMemSet(const void *pAddr, cosaU8 value, cosaUSize size));
cosaCompilifics(INLINE, void linuxCosaMemCopy(const void *pSrc, const void *pDest, cosaUSize size));
cosaCompilifics(INLINE, void linuxCosaMemSwap(const void *pSrc, const void *pDest, cosaUSize size));

//RAM:
cosaCompilifics(INLINE, void *linuxCosaCreateBlock(cosaContext *pContext, const cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaBlockSegment(cosaContext *pContext, const cosaBlock *pBSrc, const cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size));
cosaCompilifics(INLINE, void linuxCosaBlockGetMD(cosaContext *pContext, const cosaBlock **ppBAddr, const void *pAddr));
cosaCompilifics(INLINE, void linuxCosaBlockLinkMD(cosaContext *pContext, cosaBlock **ppBAddr));
cosaCompilifics(INLINE, void linuxCosaBlockUnlinkMD(cosaContext *pContext, cosaBlock **ppBAddr));
cosaCompilifics(INLINE, void linuxCosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr));
cosaCompilifics(INLINE, void linuxCosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr));

//Stacks:
cosaCompilifics(INLINE, void linuxCosaCreateStackSS(cosaContext *pContext, const cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)); //SS -> Type:Static  Size:Static.
cosaCompilifics(INLINE, void linuxCosaCreateStackSD(cosaContext *pContext, const cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)); //SD -> Type:Static  Size:Dynamic.
cosaCompilifics(INLINE, void linuxCosaCreateStackDS(cosaContext *pContext, const cosaBlock **ppBAddr, cosaUSize size)); //DS -> Type:Dynamic Size:Static.
cosaCompilifics(INLINE, void linuxCosaCreateStackDD(cosaContext *pContext, const cosaBlock **ppBAddr, cosaUSize size)); //DD -> Type:Dynamic Size:Dynamic.
cosaCompilifics(INLINE, void linuxCosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem));
cosaCompilifics(INLINE, void linuxCosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem, cosaUSize itemSize));
cosaCompilifics(INLINE, void *linuxCosaStackSXPop(cosaContext *pContext, const cosaBlock *pStack));
cosaCompilifics(INLINE, void *linuxCosaStackDXPop(cosaContext *pContext, const cosaBlock *pStack, cosaUSize *pItemSize));

//Queues:
cosaCompilifics(INLINE, void linuxCosaCreateQueue(cosaContext *pContext, const cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize));
cosaCompilifics(INLINE, void linuxCosaQueueAdd(cosaContext *pContext, const cosaBlock *pQueue, const void *pItem));
cosaCompilifics(INLINE, void *linuxCosaQueueNext(cosaContext *pContext, const cosaBlock *pQueue));

//Files:
cosaCompilifics(INLINE, cosaFile *linuxCosaFileOpen(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaFileCreate(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaFileWrite(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaFileRead(cosaContext *pContext));

//CosaContext:
cosaCompilifics(INLINE, void linuxCosaInitContext(cosaContext *pContext));
cosaCompilifics(INLINE, void linuxCosaDestroyContext(cosaContext *pContext));

#endif