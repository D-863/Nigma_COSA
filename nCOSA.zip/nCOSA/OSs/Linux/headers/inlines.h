#ifndef NIGMA_COSA_LINUX_INLINES_H
#define NIGMA_COSA_LINUX_INLINES_H

#include "utilities.h"

//RAM:
cosaCompilifics(INLINE, void _BlockFreed_Remove_LV3(const cosaContext *pContext, cosaU64 index)) {
    cosaPage pageBlocks = {0};
    cosaPage pageFreed = {0};
    cosaPageGetMD(pContext, &pageBlocks, COSA_MEMPAGE_BLOCKS_ID);
    cosaPageGetMD(pContext, &pageFreed, COSA_MEMPAGE_FREED_ID);
    cosaBlock *pBlocks = pageBlocks.pData;
    cosaU64 *pFreed = pageFreed.pData;

    if (pageFreed.top < 2) {
        if (pageFreed.top == 1) {
            pBlocks[pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;
            --pageFreed.top;
            cosaPageSetMD(pContext, &pageFreed, COSA_MEMPAGE_FREED_ID);
        }
        return;
    }
    pBlocks[pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;

    --pageFreed.top;
    while (index < pageFreed.top) {
        pFreed[index] = pFreed[index + 1];
        ++index;
    }
    cosaPageSetMD(pContext, &pageFreed, COSA_MEMPAGE_FREED_ID);
}

cosaCompilifics(INLINE, void _BlockFreed_Search_LV3(const cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize area)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            cosaBlock *pBlock = &pMemPage->pBlocks[pMemPage->pFreed[pMemPage->freedTop - 1]];
            cosaUSize bArea = pBlock->count * pBlock->byteSize;
            if (bArea >= area) {
                (*ppBAddr) = pBlock;
                _BlockFreed_Remove_LV3(pContext, pMemPage->freedTop - 1);
            }
        }
        return;
    }

    //Modified shade of _BinarySearch.
    cosaBlock *pBlock = NULL;
    cosaUSize m,bArea;
    cosaUSize l = 0;
    cosaUSize r = pMemPage->freedTop;
    while (l <= r) {
        m = l + ((r - l) / 2);

        pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        bArea = pBlock->count * pBlock->byteSize;

        if (bArea == area) { break; }
        if (bArea < area) { l = ++m; } else { r = --m; }
    }
    if (cosaCUnlikely(bArea == area)) {
        //Possibly the second return state of _BinarySearch, go to the absolute top instance.
        while (bArea == area) {
            ++m;
            if (m < pMemPage->freedTop) {
                pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
                bArea = pBlock->count * pBlock->byteSize;
            }
        }
        --m;

        //The first return state of _BinarySearch.
        (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        _BlockFreed_Remove_LV3(pContext, m);
    } else {
        //The third return state of _BinarySearch.
        ++m;
        if (m < pMemPage->freedTop) {
            //Use the next-best instance.
            (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
            _BlockFreed_Remove_LV3(pContext, m);
        }
    }
}

cosaCompilifics(INLINE, void _BlockMD_GetNew_LV3(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if ((pMemPage->blockTop + 1) >= pMemPage->blockCount) {
        cosaUSize newCount = COSA_MEMPAGE_BLOCK_EXPAND(pMemPage->blockCount);

        cosaBlock *pNBlocks = realloc(pMemPage->pBlocks, newCount * sizeof(cosaBlock));
        if (pNBlocks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNBlocks[pMemPage->blockCount], 0x00, (newCount - pMemPage->blockCount) * sizeof(cosaBlock));
        pMemPage->blockCount = newCount;

        if (pNBlocks != pMemPage->pBlocks) { _BlockLink_Update_LV3(pContext, pNBlocks); }
        pMemPage->pBlocks = pNBlocks;
    }
    (*ppBAddr) = &pMemPage->pBlocks[pMemPage->blockTop];
    ++pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_FindByAddr_LV3(const cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;

    cosaBlock *pBlock = pMemPage->pBlocks;
    while (pBlock != &pMemPage->pBlocks[pMemPage->blockTop]) {
        if (pBlock->addr == pAddr) {
            (*ppBAddr) = pBlock;
            break;
        }
        ++pBlock;
    }
}

cosaCompilifics(INLINE, void _BlockMD_Destroy_LV3(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if (pMemPage->blockTop == 0) { return; }

    cosaBlock *pBlock = *ppBAddr;
    if (pBlock->flags & COSA_MEM_FLAGS_FREED)  { _BlockFreed_Remove_LV3(pContext, 0); }
    if (pBlock->flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_UnlinkMD_LV3(pContext, ppBAddr); }
    free(pBlock->addr);
    pBlock->addr = NULL;
    (*ppBAddr) = NULL;

    --pMemPage->blockTop;
    register cosaU64 tIndex = pMemPage->blockTop;
    cosaU64 bIndex = pBlock - pMemPage->pBlocks;
    if (bIndex == tIndex) { return; }
    pBlock->flags    = pMemPage->pBlocks[tIndex].flags;
    pBlock->byteSize = pMemPage->pBlocks[tIndex].byteSize;
    pBlock->count    = pMemPage->pBlocks[tIndex].count;
    pBlock->addr     = pMemPage->pBlocks[tIndex].addr;

    if (pMemPage->pBlocks[tIndex].flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_ChangeBlockMD_LV3(pContext, tIndex, bIndex); }
}

//Strings:
cosaCompilifics(INLINE, void _StringMD_GetNew_LV3(cosaContext *pContext, cosaDictionary **ppDictionary, cosaU64 *pDictionaryID)) {
    _StrPage_LV3 *pStrPage = (_StrPage_LV3*)pContext->systemMD.pStrPage;
    if ((pStrPage->dictionariesTop + 1) >= pStrPage->dictionariesCount) {
        cosaUSize newCount = COSA_STRPAGE_DICTIONARIES_EXPAND(pStrPage->dictionariesCount);

        cosaDictionary *pNDictionarys = realloc(pStrPage->pDictionaries, newCount * sizeof(cosaDictionary));
        if (pNDictionarys == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNDictionarys[pStrPage->dictionariesCount], 0x00, (newCount - pStrPage->dictionariesCount) * sizeof(cosaDictionary));
        pStrPage->dictionariesCount = newCount;
        pStrPage->pDictionaries = pNDictionarys;
    }
    (*pDictionaryID) = pStrPage->dictionariesTop;
    (*ppDictionary) = &pStrPage->pDictionaries[pStrPage->dictionariesTop];
    ++pStrPage->dictionariesTop;
}

cosaCompilifics(INLINE, void _StringMD_Destroy_LV3(cosaContext *pContext, cosaU64 dictionaryID)) {
}

//Files:
cosaCompilifics(INLINE, void _FileMD_GetNew_LV3(cosaContext *pContext, cosaFile **ppFile)) {
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    if ((pFilePage->fileTop + 1) >= pFilePage->fileCount) {
        cosaUSize newCount = COSA_FILEPAGE_FILE_EXPAND(pFilePage->fileCount);
        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 1: {
                _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 2: {
                _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 3: {
                _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
        }

        cosaFile *pNFiles = realloc(pFilePage->pFiles, newCount * sizeof(cosaFile));
        if (pNFiles == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNFiles[pFilePage->fileCount], 0x00, (newCount - pFilePage->fileCount) * sizeof(cosaFile));
        pFilePage->fileCount = newCount;

        if (pNFiles != pFilePage->pFiles) { /*_FileLink_Update_LV3(pContext, pNFiles);*/ }
        pFilePage->pFiles = pNFiles;
    }
    (*ppFile) = &pFilePage->pFiles[pFilePage->fileTop];
    ++pFilePage->fileTop;
}

cosaCompilifics(INLINE, void _FileMD_GetFINFO_LV3(cosaContext *pContext, cosaFile *pFile)) {
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    if ((pFilePage->finfoTop + 1) >= pFilePage->finfoCount) {
        cosaUSize newCount = COSA_FILEPAGE_FINFO_EXPAND(pFilePage->finfoCount);

        cosaFInfo *pNFINFOs = realloc(pFilePage->pFInfos, newCount * sizeof(cosaFInfo));
        if (pNFINFOs == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNFINFOs[pFilePage->finfoCount], 0x00, (newCount - pFilePage->finfoCount) * sizeof(cosaFInfo));
        pFilePage->finfoCount = newCount;

        if (pNFINFOs != pFilePage->pFInfos) { /*_FInfoLink_Update_LV3(pContext, pNFINFOs);*/ }
        pFilePage->pFInfos = pNFINFOs;
    }
    pFile->pFInfo = &pFilePage->pFInfos[pFilePage->finfoTop];
    ++pFilePage->finfoTop;
}

cosaCompilifics(INLINE, void _FileMD_RemoveFINFO_LV3(cosaContext *pContext, cosaFile *pFile)) {
}

//CosaContext:
cosaCompilifics(INLINE, void _InitSysInfo_LV3(cosaContext *pContext, const _CosaLinux_RLIMIT *pLinuxInfo_RLIMIT)) {
    pContext->systemMD.pSysInfo = malloc(sizeof(_SysInfo_LV3));
    if (pContext->systemMD.pSysInfo == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPSETArea(pContext, pContext->systemMD.pSysInfo, 0x00, sizeof(_SysInfo_LV3));

    _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
    pSysInfo->minFDs = (cosaU64)pLinuxInfo_RLIMIT->rlim_cur;
    pSysInfo->maxFDs = (cosaU64)pLinuxInfo_RLIMIT->rlim_max;

    const cosaU16 isSysBigEndian = 0x0001;
    pSysInfo->isBigEndian = cosaSysEndianIsBig(isSysBigEndian);
}

cosaCompilifics(INLINE, void _InitMemPage_LV3(cosaContext *pContext)) {
    pContext->systemMD.pMemPage = malloc(sizeof(_MemPage_LV3));
    if (pContext->systemMD.pMemPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPSETArea(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(_MemPage_LV3));
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    pMemPage->blockCount = COSA_MEMPAGE_BLOCK_START;
    pMemPage->freedCount = COSA_MEMPAGE_FREED_START;
    pMemPage->linkCount = COSA_MEMPAGE_LINK_START;

    pMemPage->pBlocks = malloc(COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock*));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pMemPage);

        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pFreed = malloc(COSA_MEMPAGE_FREED_START * sizeof(cosaU64*));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pLinks = malloc(COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink*));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pFreed);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pFreed = NULL;
        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }
    cosaOPSETArea(pContext, pMemPage->pBlocks, 0x00, COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock*));
    cosaOPSETArea(pContext, pMemPage->pFreed,  0x00, COSA_MEMPAGE_FREED_START * sizeof(cosaU64*));
    cosaOPSETArea(pContext, pMemPage->pLinks,  0x00, COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink*));
}

cosaCompilifics(INLINE, void _InitStrPage_LV3(cosaContext *pContext)) {
    pContext->systemMD.pStrPage = malloc(sizeof(_StrPage_LV3));
    if (pContext->systemMD.pStrPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPSETArea(pContext, pContext->systemMD.pStrPage, 0x00, sizeof(_StrPage_LV3));
    _StrPage_LV3 *pStrPage = (_StrPage_LV3*)pContext->systemMD.pStrPage;
    pStrPage->dictionariesCount = COSA_STRPAGE_DICTIONARIES_COUNT_START;

    pStrPage->pDictionaries = malloc(COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));
    if (pStrPage->pDictionaries == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pStrPage);

        pContext->systemMD.pStrPage = NULL;
        return;
    }
    cosaOPSETArea(pContext, pStrPage->pDictionaries, 0x00, COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));
}

cosaCompilifics(INLINE, void _InitFilePage_LV3(cosaContext *pContext)) {
    pContext->systemMD.pFilePage = malloc(sizeof(_FilePage_LV3));
    if (pContext->systemMD.pFilePage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPSETArea(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(_FilePage_LV3));
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    pFilePage->finfoCount = COSA_FILEPAGE_FINFO_COUNT_START;
    pFilePage->fileCount = COSA_FILEPAGE_FILE_COUNT_START;

    pFilePage->pFInfos = malloc(COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    if (pFilePage->pFInfos == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pFilePage);

        pContext->systemMD.pFilePage = NULL;
        return;
    }

    pFilePage->pFiles = malloc(COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
    if (pFilePage->pFiles == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pFilePage->pFInfos);
        free(pContext->systemMD.pFilePage);

        pFilePage->pFInfos = NULL;
        pContext->systemMD.pFilePage = NULL;
        return;
    }
    cosaOPSETArea(pContext, pFilePage->pFInfos, 0x00, COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    cosaOPSETArea(pContext, pFilePage->pFiles,  0x00, COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
}

cosaCompilifics(INLINE, void _DestroySysInfo_LV3(void)) {
}

cosaCompilifics(INLINE, void _DestroyMemPage_LV3(const cosaContext *pContext)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    free(pMemPage->pLinks);
    free(pMemPage->pFreed);
    free(pMemPage->pBlocks);

    pMemPage->pLinks = NULL;
    pMemPage->pFreed = NULL;
    pMemPage->pBlocks = NULL;
}

cosaCompilifics(INLINE, void _DestroyStrPage_LV3(const cosaContext *pContext)) {
}

cosaCompilifics(INLINE, void _DestroyFilePage_LV3(const cosaContext *pContext)) {
}

#endif