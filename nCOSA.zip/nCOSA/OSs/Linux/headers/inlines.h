#ifndef NIGMA_COSA_LINUX_INLINES_H
#define NIGMA_COSA_LINUX_INLINES_H

#include "utilities.h"

//RAM:
cosaCompilifics(INLINE, void _BlockFreed_Remove_LV0(const cosaContext *pContext, cosaU8 index)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;
            --pMemPage->freedTop;
        }
        return;
    }
    pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;

    --pMemPage->freedTop;
    while (index < pMemPage->freedTop) {
        pMemPage->pFreed[index] = pMemPage->pFreed[index + 1];
        ++index;
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Remove_LV1(const cosaContext *pContext, cosaU16 index)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;
            --pMemPage->freedTop;
        }
        return;
    }
    pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;

    --pMemPage->freedTop;
    while (index < pMemPage->freedTop) {
        pMemPage->pFreed[index] = pMemPage->pFreed[index + 1];
        ++index;
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Remove_LV2(const cosaContext *pContext, cosaU32 index)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;
            --pMemPage->freedTop;
        }
        return;
    }
    pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;

    --pMemPage->freedTop;
    while (index < pMemPage->freedTop) {
        pMemPage->pFreed[index] = pMemPage->pFreed[index + 1];
        ++index;
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Remove_LV3(const cosaContext *pContext, cosaU64 index)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;
            --pMemPage->freedTop;
        }
        return;
    }
    pMemPage->pBlocks[pMemPage->pFreed[index]].flags ^= COSA_MEM_FLAGS_FREED;

    --pMemPage->freedTop;
    while (index < pMemPage->freedTop) {
        pMemPage->pFreed[index] = pMemPage->pFreed[index + 1];
        ++index;
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Search_LV0(const cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize area)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            cosaBlock *pBlock = &pMemPage->pBlocks[pMemPage->pFreed[pMemPage->freedTop - 1]];
            cosaUSize bArea = pBlock->count * pBlock->byteSize;
            if (bArea >= area) {
                (*ppBAddr) = pBlock;
                _BlockFreed_Remove_LV0(pContext, pMemPage->freedTop - 1);
            }
        }
        return;
    }

    //Modified shade of _BinarySearch.
    cosaBlock *pBlock = NULL;
    cosaUSize m,bArea;
    cosaUSize l = 0;
    cosaUSize r = pMemPage->freedTop;
    while (l <= r) {
        m = l + ((r - l) / 2);

        pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        bArea = pBlock->count * pBlock->byteSize;

        if (bArea == area) { break; }
        if (bArea < area) { l = ++m; } else { r = --m; }
    }
    if (cosaCUnlikely(bArea == area)) {
        //Possibly the second return state of _BinarySearch, go to the absolute top instance.
        while (bArea == area) {
            ++m;
            if (m < pMemPage->freedTop) {
                pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
                bArea = pBlock->count * pBlock->byteSize;
            }
        }
        --m;

        //The first return state of _BinarySearch.
        (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        _BlockFreed_Remove_LV0(pContext, m);
    } else {
        //The third return state of _BinarySearch.
        ++m;
        if (m < pMemPage->freedTop) {
            //Use the next-best instance.
            (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
            _BlockFreed_Remove_LV0(pContext, m);
        }
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Search_LV1(const cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize area)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            cosaBlock *pBlock = &pMemPage->pBlocks[pMemPage->pFreed[pMemPage->freedTop - 1]];
            cosaUSize bArea = pBlock->count * pBlock->byteSize;
            if (bArea >= area) {
                (*ppBAddr) = pBlock;
                _BlockFreed_Remove_LV1(pContext, pMemPage->freedTop - 1);
            }
        }
        return;
    }

    //Modified shade of _BinarySearch.
    cosaBlock *pBlock = NULL;
    cosaUSize m,bArea;
    cosaUSize l = 0;
    cosaUSize r = pMemPage->freedTop;
    while (l <= r) {
        m = l + ((r - l) / 2);

        pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        bArea = pBlock->count * pBlock->byteSize;

        if (bArea == area) { break; }
        if (bArea < area) { l = ++m; } else { r = --m; }
    }
    if (cosaCUnlikely(bArea == area)) {
        //Possibly the second return state of _BinarySearch, go to the absolute top instance.
        while (bArea == area) {
            ++m;
            if (m < pMemPage->freedTop) {
                pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
                bArea = pBlock->count * pBlock->byteSize;
            }
        }
        --m;

        //The first return state of _BinarySearch.
        (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        _BlockFreed_Remove_LV1(pContext, m);
    } else {
        //The third return state of _BinarySearch.
        ++m;
        if (m < pMemPage->freedTop) {
            //Use the next-best instance.
            (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
            _BlockFreed_Remove_LV1(pContext, m);
        }
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Search_LV2(const cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize area)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            cosaBlock *pBlock = &pMemPage->pBlocks[pMemPage->pFreed[pMemPage->freedTop - 1]];
            cosaUSize bArea = pBlock->count * pBlock->byteSize;
            if (bArea >= area) {
                (*ppBAddr) = pBlock;
                _BlockFreed_Remove_LV2(pContext, pMemPage->freedTop - 1);
            }
        }
        return;
    }

    //Modified shade of _BinarySearch.
    cosaBlock *pBlock = NULL;
    cosaUSize m,bArea;
    cosaUSize l = 0;
    cosaUSize r = pMemPage->freedTop;
    while (l <= r) {
        m = l + ((r - l) / 2);

        pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        bArea = pBlock->count * pBlock->byteSize;

        if (bArea == area) { break; }
        if (bArea < area) { l = ++m; } else { r = --m; }
    }
    if (cosaCUnlikely(bArea == area)) {
        //Possibly the second return state of _BinarySearch, go to the absolute top instance.
        while (bArea == area) {
            ++m;
            if (m < pMemPage->freedTop) {
                pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
                bArea = pBlock->count * pBlock->byteSize;
            }
        }
        --m;

        //The first return state of _BinarySearch.
        (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        _BlockFreed_Remove_LV2(pContext, m);
    } else {
        //The third return state of _BinarySearch.
        ++m;
        if (m < pMemPage->freedTop) {
            //Use the next-best instance.
            (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
            _BlockFreed_Remove_LV2(pContext, m);
        }
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Search_LV3(const cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize area)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if (pMemPage->freedTop < 2) {
        if (pMemPage->freedTop == 1) {
            cosaBlock *pBlock = &pMemPage->pBlocks[pMemPage->pFreed[pMemPage->freedTop - 1]];
            cosaUSize bArea = pBlock->count * pBlock->byteSize;
            if (bArea >= area) {
                (*ppBAddr) = pBlock;
                _BlockFreed_Remove_LV3(pContext, pMemPage->freedTop - 1);
            }
        }
        return;
    }

    //Modified shade of _BinarySearch.
    cosaBlock *pBlock = NULL;
    cosaUSize m,bArea;
    cosaUSize l = 0;
    cosaUSize r = pMemPage->freedTop;
    while (l <= r) {
        m = l + ((r - l) / 2);

        pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        bArea = pBlock->count * pBlock->byteSize;

        if (bArea == area) { break; }
        if (bArea < area) { l = ++m; } else { r = --m; }
    }
    if (cosaCUnlikely(bArea == area)) {
        //Possibly the second return state of _BinarySearch, go to the absolute top instance.
        while (bArea == area) {
            ++m;
            if (m < pMemPage->freedTop) {
                pBlock = &pMemPage->pBlocks[pMemPage->pFreed[m]];
                bArea = pBlock->count * pBlock->byteSize;
            }
        }
        --m;

        //The first return state of _BinarySearch.
        (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
        _BlockFreed_Remove_LV3(pContext, m);
    } else {
        //The third return state of _BinarySearch.
        ++m;
        if (m < pMemPage->freedTop) {
            //Use the next-best instance.
            (*ppBAddr) = &pMemPage->pBlocks[pMemPage->pFreed[m]];
            _BlockFreed_Remove_LV3(pContext, m);
        }
    }
}

cosaCompilifics(INLINE, void _BlockFreed_Add_LV0(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    if ((pMemPage->freedTop + 1) >= pMemPage->freedCount) {
        cosaUSize newCount = COSA_MEMPAGE_FREED_EXPAND(pMemPage->freedCount);

        cosaBlockLink *pNFreed = realloc(pMemPage->pFreed, newCount * sizeof(cosaU8));
        if (pNFreed == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFreed[pMemPage->freedCount], 0x00, (newCount - pMemPage->freedCount) * sizeof(cosaU8));
        pMemPage->freedCount = newCount;
        pMemPage->pLinks = pNFreed;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_FREED;
    pMemPage->pFreed[pMemPage->freedTop] = (*ppBAddr) - pMemPage->pBlocks;
    ++pMemPage->freedTop;
}

cosaCompilifics(INLINE, void _BlockFreed_Add_LV1(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    if ((pMemPage->freedTop + 1) >= pMemPage->freedCount) {
        cosaUSize newCount = COSA_MEMPAGE_FREED_EXPAND(pMemPage->freedCount);

        cosaBlockLink *pNFreed = realloc(pMemPage->pFreed, newCount * sizeof(cosaU16));
        if (pNFreed == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFreed[pMemPage->freedCount], 0x00, (newCount - pMemPage->freedCount) * sizeof(cosaU16));
        pMemPage->freedCount = newCount;
        pMemPage->pLinks = pNFreed;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_FREED;
    pMemPage->pFreed[pMemPage->freedTop] = (*ppBAddr) - pMemPage->pBlocks;
    ++pMemPage->freedTop;
}

cosaCompilifics(INLINE, void _BlockFreed_Add_LV2(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    if ((pMemPage->freedTop + 1) >= pMemPage->freedCount) {
        cosaUSize newCount = COSA_MEMPAGE_FREED_EXPAND(pMemPage->freedCount);

        cosaBlockLink *pNFreed = realloc(pMemPage->pFreed, newCount * sizeof(cosaU32));
        if (pNFreed == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFreed[pMemPage->freedCount], 0x00, (newCount - pMemPage->freedCount) * sizeof(cosaU32));
        pMemPage->freedCount = newCount;
        pMemPage->pLinks = pNFreed;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_FREED;
    pMemPage->pFreed[pMemPage->freedTop] = (*ppBAddr) - pMemPage->pBlocks;
    ++pMemPage->freedTop;
}

cosaCompilifics(INLINE, void _BlockFreed_Add_LV3(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if ((pMemPage->freedTop + 1) >= pMemPage->freedCount) {
        cosaUSize newCount = COSA_MEMPAGE_FREED_EXPAND(pMemPage->freedCount);

        cosaBlockLink *pNFreed = realloc(pMemPage->pFreed, newCount * sizeof(cosaU64));
        if (pNFreed == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFreed[pMemPage->freedCount], 0x00, (newCount - pMemPage->freedCount) * sizeof(cosaU64));
        pMemPage->freedCount = newCount;
        pMemPage->pLinks = pNFreed;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_FREED;
    pMemPage->pFreed[pMemPage->freedTop] = (*ppBAddr) - pMemPage->pBlocks;
    ++pMemPage->freedTop;
}

cosaCompilifics(INLINE, void _BlockLink_LinkMD_LV0(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    if ((pMemPage->linkTop + 1) >= pMemPage->linkCount) {
        cosaUSize newCount = COSA_MEMPAGE_LINK_EXPAND(pMemPage->linkCount);

        cosaBlockLink *pNLinks = realloc(pMemPage->pLinks, newCount * sizeof(cosaBlockLink));
        if (pNLinks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNLinks[pMemPage->linkCount], 0x00, (newCount - pMemPage->linkCount) * sizeof(cosaBlockLink));
        pMemPage->linkCount = newCount;
        pMemPage->pLinks = pNLinks;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
    pMemPage->pLinks[pMemPage->linkTop].blockSlot = (*ppBAddr) - pMemPage->pBlocks;
    pMemPage->pLinks[pMemPage->linkTop].ppBAddr = ppBAddr;
    ++pMemPage->linkTop;
}

cosaCompilifics(INLINE, void _BlockLink_LinkMD_LV1(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    if ((pMemPage->linkTop + 1) >= pMemPage->linkCount) {
        cosaUSize newCount = COSA_MEMPAGE_LINK_EXPAND(pMemPage->linkCount);

        cosaBlockLink *pNLinks = realloc(pMemPage->pLinks, newCount * sizeof(cosaBlockLink));
        if (pNLinks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNLinks[pMemPage->linkCount], 0x00, (newCount - pMemPage->linkCount) * sizeof(cosaBlockLink));
        pMemPage->linkCount = newCount;
        pMemPage->pLinks = pNLinks;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
    pMemPage->pLinks[pMemPage->linkTop].blockSlot = (*ppBAddr) - pMemPage->pBlocks;
    pMemPage->pLinks[pMemPage->linkTop].ppBAddr = ppBAddr;
    ++pMemPage->linkTop;
}

cosaCompilifics(INLINE, void _BlockLink_LinkMD_LV2(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    if ((pMemPage->linkTop + 1) >= pMemPage->linkCount) {
        cosaUSize newCount = COSA_MEMPAGE_LINK_EXPAND(pMemPage->linkCount);

        cosaBlockLink *pNLinks = realloc(pMemPage->pLinks, newCount * sizeof(cosaBlockLink));
        if (pNLinks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNLinks[pMemPage->linkCount], 0x00, (newCount - pMemPage->linkCount) * sizeof(cosaBlockLink));
        pMemPage->linkCount = newCount;
        pMemPage->pLinks = pNLinks;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
    pMemPage->pLinks[pMemPage->linkTop].blockSlot = (*ppBAddr) - pMemPage->pBlocks;
    pMemPage->pLinks[pMemPage->linkTop].ppBAddr = ppBAddr;
    ++pMemPage->linkTop;
}

cosaCompilifics(INLINE, void _BlockLink_LinkMD_LV3(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if ((pMemPage->linkTop + 1) >= pMemPage->linkCount) {
        cosaUSize newCount = COSA_MEMPAGE_LINK_EXPAND(pMemPage->linkCount);

        cosaBlockLink *pNLinks = realloc(pMemPage->pLinks, newCount * sizeof(cosaBlockLink));
        if (pNLinks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNLinks[pMemPage->linkCount], 0x00, (newCount - pMemPage->linkCount) * sizeof(cosaBlockLink));
        pMemPage->linkCount = newCount;
        pMemPage->pLinks = pNLinks;
    }
    (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
    pMemPage->pLinks[pMemPage->linkTop].blockSlot = (*ppBAddr) - pMemPage->pBlocks;
    pMemPage->pLinks[pMemPage->linkTop].ppBAddr = ppBAddr;
    ++pMemPage->linkTop;
}

cosaCompilifics(INLINE, void _BlockLink_Update_LV0(const cosaContext *pContext, cosaBlock *pNewBAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        (*pLink->ppBAddr) = &pNewBAddr[pLink->blockSlot];
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_Update_LV1(const cosaContext *pContext, cosaBlock *pNewBAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        (*pLink->ppBAddr) = &pNewBAddr[pLink->blockSlot];
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_Update_LV2(const cosaContext *pContext, cosaBlock *pNewBAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        (*pLink->ppBAddr) = &pNewBAddr[pLink->blockSlot];
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_Update_LV3(const cosaContext *pContext, cosaBlock *pNewBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        (*pLink->ppBAddr) = &pNewBAddr[pLink->blockSlot];
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_ChangeBlockMD_LV0(const cosaContext *pContext, cosaU8 iBSrc, cosaU8 iBDest)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->blockSlot == iBSrc) {
            pLink->blockSlot = iBDest;
            (*pLink->ppBAddr) = &pMemPage->pBlocks[iBDest];
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_ChangeBlockMD_LV1(const cosaContext *pContext, cosaU16 iBSrc, cosaU16 iBDest)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->blockSlot == iBSrc) {
            pLink->blockSlot = iBDest;
            (*pLink->ppBAddr) = &pMemPage->pBlocks[iBDest];
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_ChangeBlockMD_LV2(const cosaContext *pContext, cosaU32 iBSrc, cosaU32 iBDest)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->blockSlot == iBSrc) {
            pLink->blockSlot = iBDest;
            (*pLink->ppBAddr) = &pMemPage->pBlocks[iBDest];
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_ChangeBlockMD_LV3(const cosaContext *pContext, cosaU64 iBSrc, cosaU64 iBDest)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->blockSlot == iBSrc) {
            pLink->blockSlot = iBDest;
            (*pLink->ppBAddr) = &pMemPage->pBlocks[iBDest];
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_UnlinkMD_LV0(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->ppBAddr == ppBAddr) {
            pLink->blockSlot = 0;
            pLink->ppBAddr = NULL;
            (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_UnlinkMD_LV1(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->ppBAddr == ppBAddr) {
            pLink->blockSlot = 0;
            pLink->ppBAddr = NULL;
            (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_UnlinkMD_LV2(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pMemPage->pLinks[pMemPage->linkTop]) {
        if (pLink->ppBAddr == ppBAddr) {
            pLink->blockSlot = 0;
            pLink->ppBAddr = NULL;
            (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockLink_UnlinkMD_LV3(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;

    cosaBlockLink *pLink = pMemPage->pLinks;
    while (pLink != &pLink[pMemPage->linkTop]) {
        if (pLink->ppBAddr == ppBAddr) {
            pLink->blockSlot = 0;
            pLink->ppBAddr = NULL;
            (*ppBAddr)->flags |= COSA_MEM_FLAGS_LINKED;
            break;
        }
        ++pLink;
    }
}

cosaCompilifics(INLINE, void _BlockMD_GetNew_LV0(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    if ((pMemPage->blockTop + 1) >= pMemPage->blockCount) {
        cosaUSize newCount = COSA_MEMPAGE_BLOCK_EXPAND(pMemPage->blockCount);

        cosaBlock *pNBlocks = realloc(pMemPage->pBlocks, newCount * sizeof(cosaBlock));
        if (pNBlocks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNBlocks[pMemPage->blockCount], 0x00, (newCount - pMemPage->blockCount) * sizeof(cosaBlock));
        pMemPage->blockCount = newCount;

        if (pNBlocks != pMemPage->pBlocks) { _BlockLink_Update_LV0(pContext, pNBlocks); }
        pMemPage->pBlocks = pNBlocks;
    }
    (*ppBAddr) = &pMemPage->pBlocks[pMemPage->blockTop];
    ++pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_GetNew_LV1(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    if ((pMemPage->blockTop + 1) >= pMemPage->blockCount) {
        cosaUSize newCount = COSA_MEMPAGE_BLOCK_EXPAND(pMemPage->blockCount);

        cosaBlock *pNBlocks = realloc(pMemPage->pBlocks, newCount * sizeof(cosaBlock));
        if (pNBlocks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNBlocks[pMemPage->blockCount], 0x00, (newCount - pMemPage->blockCount) * sizeof(cosaBlock));
        pMemPage->blockCount = newCount;

        if (pNBlocks != pMemPage->pBlocks) { _BlockLink_Update_LV1(pContext, pNBlocks); }
        pMemPage->pBlocks = pNBlocks;
    }
    (*ppBAddr) = &pMemPage->pBlocks[pMemPage->blockTop];
    ++pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_GetNew_LV2(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    if (pMemPage->blockTop >= pMemPage->blockCount) {
        cosaUSize newCount = COSA_MEMPAGE_BLOCK_EXPAND(pMemPage->blockCount);

        cosaBlock *pNBlocks = realloc(pMemPage->pBlocks, newCount * sizeof(cosaBlock));
        if (pNBlocks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNBlocks[pMemPage->blockCount], 0x00, (newCount - pMemPage->blockCount) * sizeof(cosaBlock));
        pMemPage->blockCount = newCount;

        if (pNBlocks != pMemPage->pBlocks) { _BlockLink_Update_LV2(pContext, pNBlocks); }
        pMemPage->pBlocks = pNBlocks;
    }
    (*ppBAddr) = &pMemPage->pBlocks[pMemPage->blockTop];
    ++pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_GetNew_LV3(cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if ((pMemPage->blockTop + 1) >= pMemPage->blockCount) {
        cosaUSize newCount = COSA_MEMPAGE_BLOCK_EXPAND(pMemPage->blockCount);

        cosaBlock *pNBlocks = realloc(pMemPage->pBlocks, newCount * sizeof(cosaBlock));
        if (pNBlocks == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNBlocks[pMemPage->blockCount], 0x00, (newCount - pMemPage->blockCount) * sizeof(cosaBlock));
        pMemPage->blockCount = newCount;

        if (pNBlocks != pMemPage->pBlocks) { _BlockLink_Update_LV3(pContext, pNBlocks); }
        pMemPage->pBlocks = pNBlocks;
    }
    (*ppBAddr) = &pMemPage->pBlocks[pMemPage->blockTop];
    ++pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_FindByAddr_LV0(const cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;

    cosaBlock *pBlock = pMemPage->pBlocks;
    while (pBlock != &pMemPage->pBlocks[pMemPage->blockTop]) {
        if (pBlock->addr == pAddr) {
            (*ppBAddr) = pBlock;
            break;
        }
        ++pBlock;
    }
}

cosaCompilifics(INLINE, void _BlockMD_FindByAddr_LV1(const cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;

    cosaBlock *pBlock = pMemPage->pBlocks;
    while (pBlock != &pMemPage->pBlocks[pMemPage->blockTop]) {
        if (pBlock->addr == pAddr) {
            (*ppBAddr) = pBlock;
            break;
        }
        ++pBlock;
    }
}

cosaCompilifics(INLINE, void _BlockMD_FindByAddr_LV2(const cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;

    cosaBlock *pBlock = pMemPage->pBlocks;
    while (pBlock != &pMemPage->pBlocks[pMemPage->blockTop]) {
        if (pBlock->addr == pAddr) {
            (*ppBAddr) = pBlock;
            break;
        }
        ++pBlock;
    }
}

cosaCompilifics(INLINE, void _BlockMD_FindByAddr_LV3(const cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;

    cosaBlock *pBlock = pMemPage->pBlocks;
    while (pBlock != &pMemPage->pBlocks[pMemPage->blockTop]) {
        if (pBlock->addr == pAddr) {
            (*ppBAddr) = pBlock;
            break;
        }
        ++pBlock;
    }
}

cosaCompilifics(INLINE, void _BlockMD_Destroy_LV0(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    if (pMemPage->blockTop == 0) { return; }

    cosaBlock *pBlock = *ppBAddr;
    if (pBlock->flags & COSA_MEM_FLAGS_FREED)  { _BlockFreed_Remove_LV0(pContext, 0); }
    if (pBlock->flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_UnlinkMD_LV0(pContext, ppBAddr); }
    free(pBlock->addr);
    pBlock->addr = NULL;

    cosaU8 tIndex = pMemPage->blockTop - 1;
    cosaU8 bIndex = pBlock - pMemPage->pBlocks;
    if (bIndex == tIndex) {
        --pMemPage->blockTop;
        return;
    }
    pBlock->flags    = pMemPage->pBlocks[tIndex].flags;
    pBlock->byteSize = pMemPage->pBlocks[tIndex].byteSize;
    pBlock->count    = pMemPage->pBlocks[tIndex].count;
    pBlock->addr     = pMemPage->pBlocks[tIndex].addr;

    if (pMemPage->pBlocks[tIndex].flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_ChangeBlockMD_LV0(pContext, tIndex, bIndex); }
    --pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_Destroy_LV1(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    if (pMemPage->blockTop == 0) { return; }

    cosaBlock *pBlock = *ppBAddr;
    if (pBlock->flags & COSA_MEM_FLAGS_FREED)  { _BlockFreed_Remove_LV1(pContext, 0); }
    if (pBlock->flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_UnlinkMD_LV1(pContext, ppBAddr); }
    free(pBlock->addr);
    pBlock->addr = NULL;

    cosaU16 tIndex = pMemPage->blockTop - 1;
    cosaU16 bIndex = pBlock - pMemPage->pBlocks;
    if (bIndex == tIndex) {
        --pMemPage->blockTop;
        return;
    }
    pBlock->flags    = pMemPage->pBlocks[tIndex].flags;
    pBlock->byteSize = pMemPage->pBlocks[tIndex].byteSize;
    pBlock->count    = pMemPage->pBlocks[tIndex].count;
    pBlock->addr     = pMemPage->pBlocks[tIndex].addr;

    if (pMemPage->pBlocks[tIndex].flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_ChangeBlockMD_LV1(pContext, tIndex, bIndex); }
    --pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_Destroy_LV2(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    if (pMemPage->blockTop == 0) { return; }

    cosaBlock *pBlock = *ppBAddr;
    if (pBlock->flags & COSA_MEM_FLAGS_FREED)  { _BlockFreed_Remove_LV2(pContext, 0); }
    if (pBlock->flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_UnlinkMD_LV2(pContext, ppBAddr); }
    free(pBlock->addr);
    pBlock->addr = NULL;

    cosaU32 tIndex = pMemPage->blockTop - 1;
    cosaU32 bIndex = pBlock - pMemPage->pBlocks;
    if (bIndex == tIndex) {
        --pMemPage->blockTop;
        return;
    }
    pBlock->flags    = pMemPage->pBlocks[tIndex].flags;
    pBlock->byteSize = pMemPage->pBlocks[tIndex].byteSize;
    pBlock->count    = pMemPage->pBlocks[tIndex].count;
    pBlock->addr     = pMemPage->pBlocks[tIndex].addr;

    if (pMemPage->pBlocks[tIndex].flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_ChangeBlockMD_LV2(pContext, tIndex, bIndex); }
    --pMemPage->blockTop;
}

cosaCompilifics(INLINE, void _BlockMD_Destroy_LV3(const cosaContext *pContext, cosaBlock **ppBAddr)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    if (pMemPage->blockTop == 0) { return; }

    cosaBlock *pBlock = *ppBAddr;
    if (pBlock->flags & COSA_MEM_FLAGS_FREED)  { _BlockFreed_Remove_LV3(pContext, 0); }
    if (pBlock->flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_UnlinkMD_LV3(pContext, ppBAddr); }
    free(pBlock->addr);
    pBlock->addr = NULL;

    cosaU64 tIndex = pMemPage->blockTop - 1;
    cosaU64 bIndex = pBlock - pMemPage->pBlocks;
    if (bIndex == tIndex) {
        --pMemPage->blockTop;
        return;
    }
    pBlock->flags    = pMemPage->pBlocks[tIndex].flags;
    pBlock->byteSize = pMemPage->pBlocks[tIndex].byteSize;
    pBlock->count    = pMemPage->pBlocks[tIndex].count;
    pBlock->addr     = pMemPage->pBlocks[tIndex].addr;

    if (pMemPage->pBlocks[tIndex].flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_ChangeBlockMD_LV3(pContext, tIndex, bIndex); }
    --pMemPage->blockTop;
}

//Files:
cosaCompilifics(INLINE, void _FileMD_GetNew_LV0(cosaContext *pContext, cosaFile **ppFile)) {
    _FilePage_LV0 *pFilePage = (_FilePage_LV0*)pContext->systemMD.pFilePage;
    if ((pFilePage->fileTop + 1) >= pFilePage->fileCount) {
        cosaUSize newCount = COSA_FILEPAGE_FILE_EXPAND(pFilePage->fileCount);
        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 1: {
                _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 2: {
                _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 3: {
                _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
        }

        cosaFile *pNFiles = realloc(pFilePage->pFiles, newCount * sizeof(cosaFile));
        if (pNFiles == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFiles[pFilePage->fileCount], 0x00, (newCount - pFilePage->fileCount) * sizeof(cosaFile));
        pFilePage->fileCount = newCount;

        if (pNFiles != pFilePage->pFiles) { /*_FileLink_Update_LV0(pContext, pNFiles);*/ }
        pFilePage->pFiles = pNFiles;
    }
    (*ppFile) = &pFilePage->pFiles[pFilePage->fileTop];
    ++pFilePage->fileTop;
}

cosaCompilifics(INLINE, void _FileMD_GetNew_LV1(cosaContext *pContext, cosaFile **ppFile)) {
    _FilePage_LV1 *pFilePage = (_FilePage_LV1*)pContext->systemMD.pFilePage;
    if ((pFilePage->fileTop + 1) >= pFilePage->fileCount) {
        cosaUSize newCount = COSA_FILEPAGE_FILE_EXPAND(pFilePage->fileCount);
        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 1: {
                _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 2: {
                _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 3: {
                _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
        }

        cosaFile *pNFiles = realloc(pFilePage->pFiles, newCount * sizeof(cosaFile));
        if (pNFiles == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFiles[pFilePage->fileCount], 0x00, (newCount - pFilePage->fileCount) * sizeof(cosaFile));
        pFilePage->fileCount = newCount;

        if (pNFiles != pFilePage->pFiles) { /*_FileLink_Update_LV1(pContext, pNFiles);*/ }
        pFilePage->pFiles = pNFiles;
    }
    (*ppFile) = &pFilePage->pFiles[pFilePage->fileTop];
    ++pFilePage->fileTop;
}

cosaCompilifics(INLINE, void _FileMD_GetNew_LV2(cosaContext *pContext, cosaFile **ppFile)) {
    _FilePage_LV2 *pFilePage = (_FilePage_LV2*)pContext->systemMD.pFilePage;
    if ((pFilePage->fileTop + 1) >= pFilePage->fileCount) {
        cosaUSize newCount = COSA_FILEPAGE_FILE_EXPAND(pFilePage->fileCount);
        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 1: {
                _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 2: {
                _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 3: {
                _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
        }

        cosaFile *pNFiles = realloc(pFilePage->pFiles, newCount * sizeof(cosaFile));
        if (pNFiles == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFiles[pFilePage->fileCount], 0x00, (newCount - pFilePage->fileCount) * sizeof(cosaFile));
        pFilePage->fileCount = newCount;

        if (pNFiles != pFilePage->pFiles) { /*_FileLink_Update_LV2(pContext, pNFiles);*/ }
        pFilePage->pFiles = pNFiles;
    }
    (*ppFile) = &pFilePage->pFiles[pFilePage->fileTop];
    ++pFilePage->fileTop;
}

cosaCompilifics(INLINE, void _FileMD_GetNew_LV3(cosaContext *pContext, cosaFile **ppFile)) {
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    if ((pFilePage->fileTop + 1) >= pFilePage->fileCount) {
        cosaUSize newCount = COSA_FILEPAGE_FILE_EXPAND(pFilePage->fileCount);
        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 1: {
                _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 2: {
                _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 3: {
                _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
        }

        cosaFile *pNFiles = realloc(pFilePage->pFiles, newCount * sizeof(cosaFile));
        if (pNFiles == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFiles[pFilePage->fileCount], 0x00, (newCount - pFilePage->fileCount) * sizeof(cosaFile));
        pFilePage->fileCount = newCount;

        if (pNFiles != pFilePage->pFiles) { /*_FileLink_Update_LV3(pContext, pNFiles);*/ }
        pFilePage->pFiles = pNFiles;
    }
    (*ppFile) = &pFilePage->pFiles[pFilePage->fileTop];
    ++pFilePage->fileTop;
}

cosaCompilifics(INLINE, void _FileMD_GetFINFO_LV0(cosaContext *pContext, cosaFile *pFile)) {
    _FilePage_LV0 *pFilePage = (_FilePage_LV0*)pContext->systemMD.pFilePage;
    if ((pFilePage->finfoTop + 1) >= pFilePage->finfoCount) {
        cosaUSize newCount = COSA_FILEPAGE_FINFO_EXPAND(pFilePage->finfoCount);

        cosaFInfo *pNFINFOs = realloc(pFilePage->pFInfos, newCount * sizeof(cosaFInfo));
        if (pNFINFOs == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFINFOs[pFilePage->finfoCount], 0x00, (newCount - pFilePage->finfoCount) * sizeof(cosaFInfo));
        pFilePage->finfoCount = newCount;

        if (pNFINFOs != pFilePage->pFInfos) { /*_FInfoLink_Update_LV0(pContext, pNFINFOs);*/ }
        pFilePage->pFInfos = pNFINFOs;
    }
    pFile->pFInfo = &pFilePage->pFInfos[pFilePage->finfoTop];
    ++pFilePage->finfoTop;
}

cosaCompilifics(INLINE, void _FileMD_GetFINFO_LV1(cosaContext *pContext, cosaFile *pFile)) {
    _FilePage_LV1 *pFilePage = (_FilePage_LV1*)pContext->systemMD.pFilePage;
    if ((pFilePage->finfoTop + 1) >= pFilePage->finfoCount) {
        cosaUSize newCount = COSA_FILEPAGE_FINFO_EXPAND(pFilePage->finfoCount);

        cosaFInfo *pNFINFOs = realloc(pFilePage->pFInfos, newCount * sizeof(cosaFInfo));
        if (pNFINFOs == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFINFOs[pFilePage->finfoCount], 0x00, (newCount - pFilePage->finfoCount) * sizeof(cosaFInfo));
        pFilePage->finfoCount = newCount;

        if (pNFINFOs != pFilePage->pFInfos) { /*_FInfoLink_Update_LV1(pContext, pNFINFOs);*/ }
        pFilePage->pFInfos = pNFINFOs;
    }
    pFile->pFInfo = &pFilePage->pFInfos[pFilePage->finfoTop];
    ++pFilePage->finfoTop;
}

cosaCompilifics(INLINE, void _FileMD_GetFINFO_LV2(cosaContext *pContext, cosaFile *pFile)) {
    _FilePage_LV2 *pFilePage = (_FilePage_LV2*)pContext->systemMD.pFilePage;
    if ((pFilePage->finfoTop + 1) >= pFilePage->finfoCount) {
        cosaUSize newCount = COSA_FILEPAGE_FINFO_EXPAND(pFilePage->finfoCount);

        cosaFInfo *pNFINFOs = realloc(pFilePage->pFInfos, newCount * sizeof(cosaFInfo));
        if (pNFINFOs == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFINFOs[pFilePage->finfoCount], 0x00, (newCount - pFilePage->finfoCount) * sizeof(cosaFInfo));
        pFilePage->finfoCount = newCount;

        if (pNFINFOs != pFilePage->pFInfos) { /*_FInfoLink_Update_LV2(pContext, pNFINFOs);*/ }
        pFilePage->pFInfos = pNFINFOs;
    }
    pFile->pFInfo = &pFilePage->pFInfos[pFilePage->finfoTop];
    ++pFilePage->finfoTop;
}

cosaCompilifics(INLINE, void _FileMD_GetFINFO_LV3(cosaContext *pContext, cosaFile *pFile)) {
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    if ((pFilePage->finfoTop + 1) >= pFilePage->finfoCount) {
        cosaUSize newCount = COSA_FILEPAGE_FINFO_EXPAND(pFilePage->finfoCount);

        cosaFInfo *pNFINFOs = realloc(pFilePage->pFInfos, newCount * sizeof(cosaFInfo));
        if (pNFINFOs == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, &pNFINFOs[pFilePage->finfoCount], 0x00, (newCount - pFilePage->finfoCount) * sizeof(cosaFInfo));
        pFilePage->finfoCount = newCount;

        if (pNFINFOs != pFilePage->pFInfos) { /*_FInfoLink_Update_LV3(pContext, pNFINFOs);*/ }
        pFilePage->pFInfos = pNFINFOs;
    }
    pFile->pFInfo = &pFilePage->pFInfos[pFilePage->finfoTop];
    ++pFilePage->finfoTop;
}

cosaCompilifics(INLINE, void _FileMD_RemoveFINFO_LV0(cosaContext *pContext, cosaFile *pFile)) {
}

//CosaContext:
cosaCompilifics(INLINE, void _InitSysInfo_LV0(cosaContext *pContext, const _CosaLinux_RLIMIT *pLinuxInfo_RLIMIT)) {
    pContext->systemMD.pSysInfo = malloc(sizeof(_SysInfo_LV0));
    if (pContext->systemMD.pSysInfo == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pSysInfo, 0x00, sizeof(_SysInfo_LV0));

    _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
    pSysInfo->minFDs = (cosaU8)pLinuxInfo_RLIMIT->rlim_cur;
    pSysInfo->maxFDs = (cosaU8)pLinuxInfo_RLIMIT->rlim_max;

    const cosaU16 isSysBigEndian = 0x0001;
    pSysInfo->isBigEndian = cosaSysEndianIsBig(isSysBigEndian);
}

cosaCompilifics(INLINE, void _InitSysInfo_LV1(cosaContext *pContext, const _CosaLinux_RLIMIT *pLinuxInfo_RLIMIT)) {
    pContext->systemMD.pSysInfo = malloc(sizeof(_SysInfo_LV1));
    if (pContext->systemMD.pSysInfo == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pSysInfo, 0x00, sizeof(_SysInfo_LV1));

    _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
    pSysInfo->minFDs = (cosaU16)pLinuxInfo_RLIMIT->rlim_cur;
    pSysInfo->maxFDs = (cosaU16)pLinuxInfo_RLIMIT->rlim_max;

    const cosaU16 isSysBigEndian = 0x0001;
    pSysInfo->isBigEndian = cosaSysEndianIsBig(isSysBigEndian);
}

cosaCompilifics(INLINE, void _InitSysInfo_LV2(cosaContext *pContext, const _CosaLinux_RLIMIT *pLinuxInfo_RLIMIT)) {
    pContext->systemMD.pSysInfo = malloc(sizeof(_SysInfo_LV2));
    if (pContext->systemMD.pSysInfo == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pSysInfo, 0x00, sizeof(_SysInfo_LV2));

    _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
    pSysInfo->minFDs = (cosaU32)pLinuxInfo_RLIMIT->rlim_cur;
    pSysInfo->maxFDs = (cosaU32)pLinuxInfo_RLIMIT->rlim_max;

    const cosaU16 isSysBigEndian = 0x0001;
    pSysInfo->isBigEndian = cosaSysEndianIsBig(isSysBigEndian);
}

cosaCompilifics(INLINE, void _InitSysInfo_LV3(cosaContext *pContext, const _CosaLinux_RLIMIT *pLinuxInfo_RLIMIT)) {
    pContext->systemMD.pSysInfo = malloc(sizeof(_SysInfo_LV3));
    if (pContext->systemMD.pSysInfo == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pSysInfo, 0x00, sizeof(_SysInfo_LV3));

    _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
    pSysInfo->minFDs = (cosaU64)pLinuxInfo_RLIMIT->rlim_cur;
    pSysInfo->maxFDs = (cosaU64)pLinuxInfo_RLIMIT->rlim_max;

    const cosaU16 isSysBigEndian = 0x0001;
    pSysInfo->isBigEndian = cosaSysEndianIsBig(isSysBigEndian);
}

cosaCompilifics(INLINE, void _InitMemPage_LV0(cosaContext *pContext)) {
    pContext->systemMD.pMemPage = malloc(sizeof(_MemPage_LV0));
    if (pContext->systemMD.pMemPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(_MemPage_LV0));
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    pMemPage->blockCount = COSA_MEMPAGE_BLOCK_START;
    pMemPage->freedCount = COSA_MEMPAGE_FREED_START;
    pMemPage->linkCount = COSA_MEMPAGE_LINK_START;

    pMemPage->pBlocks = malloc(COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pMemPage);

        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pFreed = malloc(COSA_MEMPAGE_FREED_START * sizeof(cosaU8));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pLinks = malloc(COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pFreed);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pFreed = NULL;
        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }
    cosaMemSet(pContext, pMemPage->pBlocks, 0x00, COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock));
    cosaMemSet(pContext, pMemPage->pFreed,  0x00, COSA_MEMPAGE_FREED_START * sizeof(cosaU8));
    cosaMemSet(pContext, pMemPage->pLinks,  0x00, COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink));
}

cosaCompilifics(INLINE, void _InitMemPage_LV1(cosaContext *pContext)) {
    pContext->systemMD.pMemPage = malloc(sizeof(_MemPage_LV1));
    if (pContext->systemMD.pMemPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(_MemPage_LV1));
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    pMemPage->blockCount = COSA_MEMPAGE_BLOCK_START;
    pMemPage->freedCount = COSA_MEMPAGE_FREED_START;
    pMemPage->linkCount = COSA_MEMPAGE_LINK_START;

    pMemPage->pBlocks = malloc(COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pMemPage);

        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pFreed = malloc(COSA_MEMPAGE_FREED_START * sizeof(cosaU16));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pLinks = malloc(COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pFreed);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pFreed = NULL;
        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }
    cosaMemSet(pContext, pMemPage->pBlocks, 0x00, COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock));
    cosaMemSet(pContext, pMemPage->pFreed,  0x00, COSA_MEMPAGE_FREED_START * sizeof(cosaU16));
    cosaMemSet(pContext, pMemPage->pLinks,  0x00, COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink));
}

cosaCompilifics(INLINE, void _InitMemPage_LV2(cosaContext *pContext)) {
    pContext->systemMD.pMemPage = malloc(sizeof(_MemPage_LV2));
    if (pContext->systemMD.pMemPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(_MemPage_LV2));
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    pMemPage->blockCount = COSA_MEMPAGE_BLOCK_START;
    pMemPage->freedCount = COSA_MEMPAGE_FREED_START;
    pMemPage->linkCount = COSA_MEMPAGE_LINK_START;

    pMemPage->pBlocks = malloc(COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pMemPage);

        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pFreed = malloc(COSA_MEMPAGE_FREED_START * sizeof(cosaU32));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pLinks = malloc(COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pFreed);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pFreed = NULL;
        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }
    cosaMemSet(pContext, pMemPage->pBlocks, 0x00, COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock));
    cosaMemSet(pContext, pMemPage->pFreed,  0x00, COSA_MEMPAGE_FREED_START * sizeof(cosaU32));
    cosaMemSet(pContext, pMemPage->pLinks,  0x00, COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink));
}

cosaCompilifics(INLINE, void _InitMemPage_LV3(cosaContext *pContext)) {
    pContext->systemMD.pMemPage = malloc(sizeof(_MemPage_LV3));
    if (pContext->systemMD.pMemPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(_MemPage_LV3));
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    pMemPage->blockCount = COSA_MEMPAGE_BLOCK_START;
    pMemPage->freedCount = COSA_MEMPAGE_FREED_START;
    pMemPage->linkCount = COSA_MEMPAGE_LINK_START;

    pMemPage->pBlocks = malloc(COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock*));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pMemPage);

        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pFreed = malloc(COSA_MEMPAGE_FREED_START * sizeof(cosaU64*));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }

    pMemPage->pLinks = malloc(COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink*));
    if (pMemPage->pBlocks == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pMemPage->pFreed);
        free(pMemPage->pBlocks);
        free(pContext->systemMD.pMemPage);

        pMemPage->pFreed = NULL;
        pMemPage->pBlocks = NULL;
        pContext->systemMD.pMemPage = NULL;
        return;
    }
    cosaMemSet(pContext, pMemPage->pBlocks, 0x00, COSA_MEMPAGE_BLOCK_START * sizeof(cosaBlock*));
    cosaMemSet(pContext, pMemPage->pFreed,  0x00, COSA_MEMPAGE_FREED_START * sizeof(cosaU64*));
    cosaMemSet(pContext, pMemPage->pLinks,  0x00, COSA_MEMPAGE_LINK_START * sizeof(cosaBlockLink*));
}

cosaCompilifics(INLINE, void _InitFilePage_LV0(cosaContext *pContext)) {
    pContext->systemMD.pFilePage = malloc(sizeof(_FilePage_LV0));
    if (pContext->systemMD.pFilePage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(_FilePage_LV0));
    _FilePage_LV0 *pFilePage = (_FilePage_LV0*)pContext->systemMD.pFilePage;
    pFilePage->finfoCount = COSA_FILEPAGE_FINFO_COUNT_START;
    pFilePage->fileCount = COSA_FILEPAGE_FILE_COUNT_START;

    pFilePage->pFInfos = malloc(COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    if (pFilePage->pFInfos == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pFilePage);

        pContext->systemMD.pFilePage = NULL;
        return;
    }

    pFilePage->pFiles = malloc(COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
    if (pFilePage->pFiles == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pFilePage->pFInfos);
        free(pContext->systemMD.pFilePage);

        pFilePage->pFInfos = NULL;
        pContext->systemMD.pFilePage = NULL;
        return;
    }
    cosaMemSet(pContext, pFilePage->pFInfos, 0x00, COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    cosaMemSet(pContext, pFilePage->pFiles,  0x00, COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
}

cosaCompilifics(INLINE, void _InitFilePage_LV1(cosaContext *pContext)) {
    pContext->systemMD.pFilePage = malloc(sizeof(_FilePage_LV1));
    if (pContext->systemMD.pFilePage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(_FilePage_LV1));
    _FilePage_LV1 *pFilePage = (_FilePage_LV1*)pContext->systemMD.pFilePage;
    pFilePage->finfoCount = COSA_FILEPAGE_FINFO_COUNT_START;
    pFilePage->fileCount = COSA_FILEPAGE_FILE_COUNT_START;

    pFilePage->pFInfos = malloc(COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    if (pFilePage->pFInfos == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pFilePage);

        pContext->systemMD.pFilePage = NULL;
        return;
    }

    pFilePage->pFiles = malloc(COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
    if (pFilePage->pFiles == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pFilePage->pFInfos);
        free(pContext->systemMD.pFilePage);

        pFilePage->pFInfos = NULL;
        pContext->systemMD.pFilePage = NULL;
        return;
    }
    cosaMemSet(pContext, pFilePage->pFInfos, 0x00, COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    cosaMemSet(pContext, pFilePage->pFiles,  0x00, COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
}

cosaCompilifics(INLINE, void _InitFilePage_LV2(cosaContext *pContext)) {
    pContext->systemMD.pFilePage = malloc(sizeof(_FilePage_LV2));
    if (pContext->systemMD.pFilePage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(_FilePage_LV2));
    _FilePage_LV2 *pFilePage = (_FilePage_LV2*)pContext->systemMD.pFilePage;
    pFilePage->finfoCount = COSA_FILEPAGE_FINFO_COUNT_START;
    pFilePage->fileCount = COSA_FILEPAGE_FILE_COUNT_START;

    pFilePage->pFInfos = malloc(COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    if (pFilePage->pFInfos == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pFilePage);

        pContext->systemMD.pFilePage = NULL;
        return;
    }

    pFilePage->pFiles = malloc(COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
    if (pFilePage->pFiles == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pFilePage->pFInfos);
        free(pContext->systemMD.pFilePage);

        pFilePage->pFInfos = NULL;
        pContext->systemMD.pFilePage = NULL;
        return;
    }
    cosaMemSet(pContext, pFilePage->pFInfos, 0x00, COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    cosaMemSet(pContext, pFilePage->pFiles,  0x00, COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
}

cosaCompilifics(INLINE, void _InitFilePage_LV3(cosaContext *pContext)) {
    pContext->systemMD.pFilePage = malloc(sizeof(_FilePage_LV3));
    if (pContext->systemMD.pFilePage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaMemSet(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(_FilePage_LV3));
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    pFilePage->finfoCount = COSA_FILEPAGE_FINFO_COUNT_START;
    pFilePage->fileCount = COSA_FILEPAGE_FILE_COUNT_START;

    pFilePage->pFInfos = malloc(COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    if (pFilePage->pFInfos == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pFilePage);

        pContext->systemMD.pFilePage = NULL;
        return;
    }

    pFilePage->pFiles = malloc(COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
    if (pFilePage->pFiles == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pFilePage->pFInfos);
        free(pContext->systemMD.pFilePage);

        pFilePage->pFInfos = NULL;
        pContext->systemMD.pFilePage = NULL;
        return;
    }
    cosaMemSet(pContext, pFilePage->pFInfos, 0x00, COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    cosaMemSet(pContext, pFilePage->pFiles,  0x00, COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
}

cosaCompilifics(INLINE, void _DestroySysInfo_LV0(void)) {
}

cosaCompilifics(INLINE, void _DestroySysInfo_LV1(void)) {
}

cosaCompilifics(INLINE, void _DestroySysInfo_LV2(void)) {
}

cosaCompilifics(INLINE, void _DestroySysInfo_LV3(void)) {
}

cosaCompilifics(INLINE, void _DestroyMemPage_LV0(const cosaContext *pContext)) {
    _MemPage_LV0 *pMemPage = (_MemPage_LV0*)pContext->systemMD.pMemPage;
    free(pMemPage->pLinks);
    free(pMemPage->pFreed);
    free(pMemPage->pBlocks);

    pMemPage->pLinks = NULL;
    pMemPage->pFreed = NULL;
    pMemPage->pBlocks = NULL;
}

cosaCompilifics(INLINE, void _DestroyMemPage_LV1(const cosaContext *pContext)) {
    _MemPage_LV1 *pMemPage = (_MemPage_LV1*)pContext->systemMD.pMemPage;
    free(pMemPage->pLinks);
    free(pMemPage->pFreed);
    free(pMemPage->pBlocks);

    pMemPage->pLinks = NULL;
    pMemPage->pFreed = NULL;
    pMemPage->pBlocks = NULL;
}

cosaCompilifics(INLINE, void _DestroyMemPage_LV2(const cosaContext *pContext)) {
    _MemPage_LV2 *pMemPage = (_MemPage_LV2*)pContext->systemMD.pMemPage;
    free(pMemPage->pLinks);
    free(pMemPage->pFreed);
    free(pMemPage->pBlocks);

    pMemPage->pLinks = NULL;
    pMemPage->pFreed = NULL;
    pMemPage->pBlocks = NULL;
}

cosaCompilifics(INLINE, void _DestroyMemPage_LV3(const cosaContext *pContext)) {
    _MemPage_LV3 *pMemPage = (_MemPage_LV3*)pContext->systemMD.pMemPage;
    free(pMemPage->pLinks);
    free(pMemPage->pFreed);
    free(pMemPage->pBlocks);

    pMemPage->pLinks = NULL;
    pMemPage->pFreed = NULL;
    pMemPage->pBlocks = NULL;
}

#endif