#ifndef NIGMA_COSA_LINUX_INLINES_H
#define NIGMA_COSA_LINUX_INLINES_H

#include "utilities.h"

//Files:
/*
cosaCompilifics(INLINE, void _FileMD_GetNew_LV3(cosaContext *pContext, cosaFile **ppFile)) {
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    if ((pFilePage->fileTop + 1) >= pFilePage->fileCount) {
        cosaUSize newCount = COSA_FILEPAGE_FILE_EXPAND(pFilePage->fileCount);
        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _SysInfo_LV0 *pSysInfo = (_SysInfo_LV0*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 1: {
                _SysInfo_LV1 *pSysInfo = (_SysInfo_LV1*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 2: {
                _SysInfo_LV2 *pSysInfo = (_SysInfo_LV2*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
            case 3: {
                _SysInfo_LV3 *pSysInfo = (_SysInfo_LV3*)pContext->systemMD.pSysInfo;
                if (newCount >= pSysInfo->minFDs) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
                    cosaError(pContext, __FILE__, __LINE__);
                    return;
                }
                break;
            }
        }

        cosaFile *pNFiles = realloc(pFilePage->pFiles, newCount * sizeof(cosaFile));
        if (pNFiles == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNFiles[pFilePage->fileCount], 0x00, (newCount - pFilePage->fileCount) * sizeof(cosaFile));
        pFilePage->fileCount = newCount;

        if (pNFiles != pFilePage->pFiles) { //_FileLink_Update_LV3(pContext, pNFiles); }
        pFilePage->pFiles = pNFiles;
    }
    (*ppFile) = &pFilePage->pFiles[pFilePage->fileTop];
    ++pFilePage->fileTop;
}

cosaCompilifics(INLINE, void _FileMD_GetFINFO_LV3(cosaContext *pContext, cosaFile *pFile)) {
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    if ((pFilePage->finfoTop + 1) >= pFilePage->finfoCount) {
        cosaUSize newCount = COSA_FILEPAGE_FINFO_EXPAND(pFilePage->finfoCount);

        cosaFInfo *pNFINFOs = realloc(pFilePage->pFInfos, newCount * sizeof(cosaFInfo));
        if (pNFINFOs == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNFINFOs[pFilePage->finfoCount], 0x00, (newCount - pFilePage->finfoCount) * sizeof(cosaFInfo));
        pFilePage->finfoCount = newCount;

        if (pNFINFOs != pFilePage->pFInfos) { //_FInfoLink_Update_LV3(pContext, pNFINFOs); }
        pFilePage->pFInfos = pNFINFOs;
    }
    pFile->pFInfo = &pFilePage->pFInfos[pFilePage->finfoTop];
    ++pFilePage->finfoTop;
}

cosaCompilifics(INLINE, void _FileMD_RemoveFINFO_LV3(cosaContext *pContext, cosaFile *pFile)) {
}
*/

#endif