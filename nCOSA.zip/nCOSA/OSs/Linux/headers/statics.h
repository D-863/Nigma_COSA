#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

#endif