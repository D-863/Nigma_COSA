#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

//CosaContext:
#if (COSA_SYSTEM_IS_STATIC == 1)
    static void _InitSysInfo(cosaContext *pContext) {
        _CosaLinux_RLIMIT linuxInfo_RLIMIT = {0};
        if (getrlimit(RLIMIT_NOFILE, &linuxInfo_RLIMIT) < 0) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }

        /*
            This is the static initialization of sysInfo,
            so we do have to worry about pre-set level types.
        */
        cosaU8 definedLV = 0;
        switch (sizeof(COSA_SYSINFO_TYPE)) {
            default: {
                //[definedLV] = UNDEFINED.
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                break;
            }
            case sizeof(_SysInfo_LV3): ++definedLV; //[definedLV] = 3.
            case sizeof(_SysInfo_LV2): ++definedLV; //[definedLV] = 2.
            case sizeof(_SysInfo_LV1): ++definedLV; //[definedLV] = 1.
            case sizeof(_SysInfo_LV0): {            //[definedLV] = 0.
                break;
            }
        }

        /*
            The or just makes so we check both RLIMIT's cur & max ranges,
            delightfully _CosaLinux_RLIMIT_FD_T(rlim_t) already is unsigned.
        */
        cosaU64 testVal = ((cosaU64)linuxInfo_RLIMIT.rlim_cur) | ((cosaU64)linuxInfo_RLIMIT.rlim_max);
        cosaU8 minLV = 0;

        //The "!!()" is equivalent to "(() != 0)", just more neat.
        minLV += !!(testVal & 0xFFFFFFFFFFFFFF00); //Is it above 8-Bit?
        minLV += !!(testVal & 0xFFFFFFFFFFFF0000); //Is it above 16-Bit?
        minLV += !!(testVal & 0xFFFFFFFF00000000); //Is it above 32-Bit?
        //If none above succeed, it's minimally a 8-Bit value and hence [minLV] will be 0.

        //Is the defined level not enough for required level?
        if (minLV > definedLV) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
            cosaError(pContext, __FILE__, __LINE__);
        }
        //This is the first check, so we can guarantee there's no possible overwrite.
        pContext->systemMD.dataLevels.levels.sysInfo = minLV;

        cosaSystemLVFunc(definedLV, _InitSysInfo, pContext, &linuxInfo_RLIMIT);
    }

    static void _InitMemPage(cosaContext *pContext) {
        /*
            This is the static initialization of memPage,
            so we do have to worry about pre-set level types.
        */
        cosaU8 definedLV = 0;
        switch (sizeof(COSA_MEMPAGE_TYPE)) {
            default: {
                //[definedLV] = UNDEFINED.
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                break;
            }
            case sizeof(_MemPage_LV3): ++definedLV; //[definedLV] = 3.
            case sizeof(_MemPage_LV2): ++definedLV; //[definedLV] = 2.
            case sizeof(_MemPage_LV1): ++definedLV; //[definedLV] = 1.
            case sizeof(_MemPage_LV0): {            //[definedLV] = 0.
                break;
            }
        }
        pContext->systemMD.dataLevels.levels.memPage = definedLV;

        pContext->systemMD.pMemPage = malloc(sizeof(COSA_MEMPAGE_TYPE));
        if (pContext->systemMD.pMemPage == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(COSA_MEMPAGE_TYPE));

        cosaSystemLVFunc(definedLV, _InitMemPage, pContext);
    }

    static void _InitFilePage(cosaContext *pContext) {
        /*
            This is the static initialization of filePage,
            so we do have to worry about pre-set level types.
        */
        cosaU8 definedLV = 0;
        switch (sizeof(COSA_FILEPAGE_TYPE)) {
            default: {
                //[definedLV] = UNDEFINED.
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                break;
            }
            case sizeof(_FilePage_LV3): ++definedLV; //[definedLV] = 3.
            case sizeof(_FilePage_LV2): ++definedLV; //[definedLV] = 2.
            case sizeof(_FilePage_LV1): ++definedLV; //[definedLV] = 1.
            case sizeof(_FilePage_LV0): {            //[definedLV] = 0.
                break;
            }
        }
        COSA_SYSINFO_TYPE *pSysInfo = pContext->systemMD.pSysInfo;
        cosaU64 testVal = pSysInfo->minFDs;
        cosaU8 minLV = 0;

        //The "!!()" is equivalent to "(() != 0)", just more neat.
        minLV += !!(testVal & 0xFFFFFFFFFFFFFF00); //Is it above 8-Bit?
        minLV += !!(testVal & 0xFFFFFFFFFFFF0000); //Is it above 16-Bit?
        minLV += !!(testVal & 0xFFFFFFFF00000000); //Is it above 32-Bit?
        //If none above succeed, it's minimally a 8-Bit value and hence [minLV] will be 0.

        #if (COSA_FILEPAGE_CHECK_EXPLICIT_RANGE != 0)
            //The defined level is not allowed to be less than the maximum.

            //Is the defined level not enough for required level?
            if (definedLV != minLV) {
                pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
                cosaError(pContext, __FILE__, __LINE__);
            }
        #else
            //Is the defined level more than the maximum?
            if (definedLV > minLV) {
                pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
                cosaError(pContext, __FILE__, __LINE__);
            }
        #endif
        //This is the first check, so we can guarantee there's no possible overwrite.
        pContext->systemMD.dataLevels.levels.filePage = definedLV;

        pContext->systemMD.pFilePage = malloc(sizeof(COSA_FILEPAGE_TYPE));
        if (pContext->systemMD.pFilePage == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(COSA_FILEPAGE_TYPE));

        cosaSystemLVFunc(definedLV, _InitFilePage_LV0, pContext);
    }
#else
    static void _InitSysInfo(cosaContext *pContext) {
        _CosaLinux_RLIMIT linuxInfo_RLIMIT = {0};
        if (getrlimit(RLIMIT_NOFILE, &linuxInfo_RLIMIT) < 0) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        /*
            This is the dynamic initialization of sysInfo,
            so we do not have to worry about pre-set level types.
        */

        /*
            The or just makes so we check both RLIMIT's cur & max ranges,
            delightfully _CosaLinux_RLIMIT_FD_T(rlim_t) already is unsigned.
        */
        cosaU64 testVal = ((cosaU64)linuxInfo_RLIMIT.rlim_cur) | ((cosaU64)linuxInfo_RLIMIT.rlim_max);
        cosaU8 minLV = 0;

        //The "!!()" is equivalent to "(() != 0)", just more neat.
        minLV += !!(testVal & 0xFFFFFFFFFFFFFF00); //Is it above 8-Bit?
        minLV += !!(testVal & 0xFFFFFFFFFFFF0000); //Is it above 16-Bit?
        minLV += !!(testVal & 0xFFFFFFFF00000000); //Is it above 32-Bit?
        //If none above succeed, it's minimally a 8-Bit value and hence [minLV] will be 0.
        //This is the first check, so we can guarantee there's no possible overwrite.
        pContext->systemMD.dataLevels.levels.sysInfo = minLV;

        switch (pContext->systemMD.dataLevels.levels.sysInfo) {
            case 0: {
                _InitSysInfo_LV0(pContext, &linuxInfo_RLIMIT);
                break;
            }
            case 1: {
                _InitSysInfo_LV1(pContext, &linuxInfo_RLIMIT);
                break;
            }
            case 2: {
                _InitSysInfo_LV2(pContext, &linuxInfo_RLIMIT);
                break;
            }
            case 3: {
                _InitSysInfo_LV3(pContext, &linuxInfo_RLIMIT);
                break;
            }
        }
    }

    static void _InitMemPage(cosaContext *pContext) {
        pContext->systemMD.dataLevels.levels.memPage = 0;
        pContext->systemMD.pMemPage = malloc(sizeof(_MemPage_LV0));
        if (pContext->systemMD.pMemPage == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaMemSet(pContext, pContext->systemMD.pMemPage, 0x00, sizeof(_MemPage_LV0));

        _InitMemPage_LV0(pContext);
    }
#endif

#endif