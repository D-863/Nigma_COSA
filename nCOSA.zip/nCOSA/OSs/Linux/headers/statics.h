#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

static void _LinuxCosaFInfoParse(cosaFile *pFile, const _CosaLinux_STAT *pFileStat) {
    pFile->pFInfo->uid   = pFileStat->st_uid;
    pFile->pFInfo->gid   = pFileStat->st_gid;
    pFile->pFInfo->atime = pFileStat->st_atime;
    pFile->pFInfo->mtime = pFileStat->st_mtime;
    pFile->pFInfo->stime = pFileStat->st_ctime;

    if ((pFileStat->st_mode & __S_IFMT) == __S_IFLNK) { pFile->flags |= COSA_FILE_FLAG_IS_LINK; }
    if ((pFileStat->st_mode & __S_IFMT) == __S_IFDIR) { pFile->flags |= COSA_FILE_FLAG_IS_DIRE; }
    if ((pFileStat->st_mode & S_IRUSR) == S_IRUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_RD; }
    if ((pFileStat->st_mode & S_IWUSR) == S_IWUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_WE; }
    if ((pFileStat->st_mode & S_IXUSR) == S_IXUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_EX; }
    if ((pFileStat->st_mode & S_IRGRP) == S_IRGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_RD; }
    if ((pFileStat->st_mode & S_IWGRP) == S_IWGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_WE; }
    if ((pFileStat->st_mode & S_IXGRP) == S_IXGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_EX; }
    if ((pFileStat->st_mode & S_IROTH) == S_IROTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_RD; }
    if ((pFileStat->st_mode & S_IWOTH) == S_IWOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_WE; }
    if ((pFileStat->st_mode & S_IXOTH) == S_IXOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_EX; }
    if ((pFileStat->st_mode & S_ISUID) == S_ISUID) { pFile->flags |= COSA_FILE_FLAG_SET_UID; }
    if ((pFileStat->st_mode & S_ISGID) == S_ISGID) { pFile->flags |= COSA_FILE_FLAG_SET_GID; }
}

#endif