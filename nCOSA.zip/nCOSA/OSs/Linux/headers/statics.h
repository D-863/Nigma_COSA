#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

static void _LinuxCosaFormatMap_LV0(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    const void *pMSrc = *ppMSrc;
    const cosaU8 byteLV = 
    cosaU8 *pSrc = pMSrc;
    cosaU8 *pDest = pMSrc;
    while (pDest != &((cosaU8*)pMSrc)[count]) {
        pDest[0] = pSrc[byteLV - 1];
        pSrc += byteLV;
        ++pDest;
    }

    (*ppMSrc) = realloc(pMSrc, count * sizeof(cosaU8));
    if ((*ppMSrc) == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        (*ppMSrc) = pMSrc;
    }
}

static void _LinuxCosaFormatMap_LV1(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU16 *pMSrc = *ppMSrc;
    if (srcLV != 0) {
        const cosaU8 byteLV = sizeof(cosaU8) << ((srcLV & 0x01) + (srcLV & 0x02));
        cosaU8 *pSrc = pMSrc;
        cosaU8 *pDest = pMSrc;
        while (pDest != &((cosaU8*)pMSrc)[count]) {
            pDest[0] = pSrc[byteLV - 1];
            pSrc += byteLV;
            ++pDest;
        }
    }
    pMSrc = realloc(pMSrc, count * sizeof(cosaU16));
    if (pMSrc == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pMSrc;

    if (srcLV == 0) {
        const cosaU8 *pSrc = pMSrc;
        while (count != 0) {
            --count;
            pMSrc[count] = pSrc[count];
        }
    }
}

static void _LinuxCosaFormatMap_LV2(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU32 *pDest = *ppMSrc;
    if (srcLV == 3) {
        cosaU32 *pNew = &pDest[count];
        cosaU64 *pOld = &((cosaU64*)pDest)[count];
        while (pNew != pDest) {
            --pOld;
            --pNew;
            pNew[0] = pOld[0];
        }
    }
    pDest = realloc(pDest, count * sizeof(cosaU32));
    if (pDest == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pDest;

    switch (srcLV) {
        case 0: {
            const cosaU8 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 1: {
            const cosaU16 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
        }
        case 2:
        case 3:
    }
}

static void _LinuxCosaFormatMap_LV3(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU64 *pDest = realloc(*ppMSrc, count * sizeof(cosaU64));
    if (pDest == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pDest;

    switch (srcLV) {
        case 0: {
            const cosaU8 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 1: {
            const cosaU16 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 2: {
            const cosaU32 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
        }
        case 3:
    }
}

static void _LinuxCosaFInfoParse(cosaFile *pFile, const _CosaLinux_STAT *pFileStat) {
    pFile->pFInfo->uid   = pFileStat->st_uid;
    pFile->pFInfo->gid   = pFileStat->st_gid;
    pFile->pFInfo->atime = pFileStat->st_atime;
    pFile->pFInfo->mtime = pFileStat->st_mtime;
    pFile->pFInfo->stime = pFileStat->st_ctime;

    if ((pFileStat->st_mode & __S_IFMT) == __S_IFLNK) { pFile->flags |= COSA_FILE_FLAG_IS_LINK; }
    if ((pFileStat->st_mode & __S_IFMT) == __S_IFDIR) { pFile->flags |= COSA_FILE_FLAG_IS_DIRE; }
    if ((pFileStat->st_mode & S_IRUSR) == S_IRUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_RD; }
    if ((pFileStat->st_mode & S_IWUSR) == S_IWUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_WE; }
    if ((pFileStat->st_mode & S_IXUSR) == S_IXUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_EX; }
    if ((pFileStat->st_mode & S_IRGRP) == S_IRGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_RD; }
    if ((pFileStat->st_mode & S_IWGRP) == S_IWGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_WE; }
    if ((pFileStat->st_mode & S_IXGRP) == S_IXGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_EX; }
    if ((pFileStat->st_mode & S_IROTH) == S_IROTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_RD; }
    if ((pFileStat->st_mode & S_IWOTH) == S_IWOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_WE; }
    if ((pFileStat->st_mode & S_IXOTH) == S_IXOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_EX; }
    if ((pFileStat->st_mode & S_ISUID) == S_ISUID) { pFile->flags |= COSA_FILE_FLAG_SET_UID; }
    if ((pFileStat->st_mode & S_ISGID) == S_ISGID) { pFile->flags |= COSA_FILE_FLAG_SET_GID; }
}

#endif