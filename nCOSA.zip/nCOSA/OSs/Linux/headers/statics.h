#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

/*
static void _LinuxCosaFormatMap_LV0(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    const cosaU8 byteLV = sizeof(cosaU8) << ((srcLV & 0x01) + (srcLV & 0x02));
    void *pMSrc = *ppMSrc;
    cosaU8 *pSrc = pMSrc;
    cosaU8 *pDest = pMSrc;
    while (pDest != &((cosaU8*)pMSrc)[count]) {
        pDest[0] = pSrc[byteLV - 1];
        pSrc += byteLV;
        ++pDest;
    }

    (*ppMSrc) = realloc(pMSrc, count * sizeof(cosaU8));
    if ((*ppMSrc) == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        (*ppMSrc) = pMSrc;
    }
}

static void _LinuxCosaFormatMap_LV1(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    void *pMSrc = *ppMSrc;
    if (srcLV != 0) {
        const cosaU8 byteLV = sizeof(cosaU8) << ((srcLV & 0x01) + (srcLV & 0x02));
        cosaU8 *pSrc = pMSrc;
        cosaU8 *pDest = pMSrc;
        while (pDest != &((cosaU8*)pMSrc)[count]) {
            pDest[0] = pSrc[byteLV - 1];
            pSrc += byteLV;
            ++pDest;
        }
    }
    pMSrc = realloc(pMSrc, count * sizeof(cosaU16));
    if (pMSrc == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pMSrc;

    if (srcLV == 0) {
        const cosaU8 *pSrc = pMSrc;
        while (count != 0) {
            --count;
            ((cosaU16*)pMSrc)[count] = pSrc[count];
        }
    }
}

static void _LinuxCosaFormatMap_LV2(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU32 *pDest = *ppMSrc;
    if (srcLV == 3) {
        cosaU32 *pNew = &pDest[count];
        cosaU64 *pOld = &((cosaU64*)pDest)[count];
        while (pNew != pDest) {
            --pOld;
            --pNew;
            pNew[0] = pOld[0];
        }
    }
    pDest = realloc(pDest, count * sizeof(cosaU32));
    if (pDest == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pDest;

    switch (srcLV) {
        case 0: {
            const cosaU8 *pSrc = (cosaU8*)pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 1: {
            const cosaU16 *pSrc = (cosaU16*)pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
        }
        case 2:
        case 3: {
            break;
        }
    }
}

static void _LinuxCosaFormatMap_LV3(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU64 *pDest = realloc(*ppMSrc, count * sizeof(cosaU64));
    if (pDest == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pDest;

    switch (srcLV) {
        case 0: {
            const cosaU8 *pSrc = (cosaU8*)pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 1: {
            const cosaU16 *pSrc = (cosaU16*)pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 2: {
            const cosaU32 *pSrc = (cosaU32*)pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
        }
        case 3: {
            break;
        }
    }
}

static void _LinuxCosaFInfoParse(cosaFile *pFile, const _CosaLinux_STAT *pFileStat) {
    pFile->pFInfo->uid   = pFileStat->st_uid;
    pFile->pFInfo->gid   = pFileStat->st_gid;
    pFile->pFInfo->atime = pFileStat->st_atime;
    pFile->pFInfo->mtime = pFileStat->st_mtime;
    pFile->pFInfo->stime = pFileStat->st_ctime;

    if ((pFileStat->st_mode & __S_IFMT) == __S_IFLNK) { pFile->flags |= COSA_FILE_FLAG_IS_LINK; }
    if ((pFileStat->st_mode & __S_IFMT) == __S_IFDIR) { pFile->flags |= COSA_FILE_FLAG_IS_DIRE; }
    if ((pFileStat->st_mode & S_IRUSR) == S_IRUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_RD; }
    if ((pFileStat->st_mode & S_IWUSR) == S_IWUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_WE; }
    if ((pFileStat->st_mode & S_IXUSR) == S_IXUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_EX; }
    if ((pFileStat->st_mode & S_IRGRP) == S_IRGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_RD; }
    if ((pFileStat->st_mode & S_IWGRP) == S_IWGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_WE; }
    if ((pFileStat->st_mode & S_IXGRP) == S_IXGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_EX; }
    if ((pFileStat->st_mode & S_IROTH) == S_IROTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_RD; }
    if ((pFileStat->st_mode & S_IWOTH) == S_IWOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_WE; }
    if ((pFileStat->st_mode & S_IXOTH) == S_IXOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_EX; }
    if ((pFileStat->st_mode & S_ISUID) == S_ISUID) { pFile->flags |= COSA_FILE_FLAG_SET_UID; }
    if ((pFileStat->st_mode & S_ISGID) == S_ISGID) { pFile->flags |= COSA_FILE_FLAG_SET_GID; }
}*/

//CosaContext:
static void _LinuxCosaInitSysInfo(cosaContext *pContext) {
    struct rlimit sysPageInfo_Limits[COSA_SYSPAGE_INFO_COUNT] = {0};
    cosaU8 sysPageInfo_Ranges[COSA_SYSPAGE_INFO_SIZE] = {0};
    cosaU64 sysPageInfo_Size = 0;
    cosaS32 linuxInfo_Limits[COSA_SYSPAGE_INFO_COUNT] = {
        RLIMIT_AS,
        RLIMIT_CORE,
        RLIMIT_CPU,
        RLIMIT_DATA,
        RLIMIT_FSIZE,
        RLIMIT_LOCKS, //limCountFLeases
        RLIMIT_LOCKS, //limCountFLocks
        RLIMIT_MEMLOCK,
        RLIMIT_MSGQUEUE,
        RLIMIT_NICE,
        RLIMIT_NOFILE,
        RLIMIT_NPROC,
        //RLIMIT_RSS, //Not used.
        RLIMIT_RTPRIO,
        RLIMIT_RTTIME,
        RLIMIT_SIGPENDING,
        RLIMIT_STACK
    };
    for (COSA_SYSPAGE_INFO_COUNT_TYPE i = 0; i < COSA_SYSPAGE_INFO_COUNT; ++i) {
        if (getrlimit(linuxInfo_Limits[i], &sysPageInfo_Limits[i]) == -1) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        /*
            The or just makes so we check both RLIMIT's cur & max ranges,
            delightfully the 'rlimit' struct's '__rlim_t' type is already unsigned.
        */
        cosaU64 testVal = ((cosaU64)sysPageInfo_Limits[i].rlim_cur) | ((cosaU64)sysPageInfo_Limits[i].rlim_max);
        cosaU8 minLV = 0;
        minLV += !!(testVal & 0xFFFFFFFFFFFFFF00); //Is it above 8-Bit?
        minLV += !!(testVal & 0xFFFFFFFFFFFF0000); //Is it above 16-Bit?
        minLV += !!(testVal & 0xFFFFFFFF00000000); //Is it above 32-Bit?
        //If none above succeed, it's minimally a 8-Bit value and hence [minLV] will be 0.
        sysPageInfo_Size += sizeof(cosaU8) << ((minLV & 0x01) + (minLV & 0x02));
        sysPageInfo_Ranges[i/COSA_SYSPAGE_INFO_SIZE] |= minLV << ((i % COSA_SYSPAGE_INFO_SIZE) * 2);
    }
    sysPageInfo_Size = (sysPageInfo_Size * 2) + sizeof(cosaMDSysInfo);

    cosaPage sysPage_Info = {0};
    cosaPageGetMD(pContext, &sysPage_Info, COSA_SYSPAGE_INFO_ID);
    sysPage_Info.dataCount = sysPageInfo_Size;
    sysPage_Info.dataTop = sysPageInfo_Size - 1;
    sysPage_Info.pData = malloc(sysPageInfo_Size);
    if (sysPage_Info.pData == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPCPYArea(pContext, sysPageInfo_Ranges, sysPage_Info.pData, sizeof(cosaMDSysInfo));

    cosaU8 *pMDLimitData = ((cosaU8*)sysPage_Info.pData) + sizeof(cosaMDSysInfo);
    for (COSA_SYSPAGE_INFO_COUNT_TYPE i = 0; i < COSA_SYSPAGE_INFO_COUNT; ++i) {
        const cosaU8 range = cosaBit2R(sysPageInfo_Ranges[i/COSA_SYSPAGE_INFO_SIZE] >> ((i % COSA_SYSPAGE_INFO_SIZE) * 2));
        switch (range) {
            case 0: {
                pMDLimitData[0] = (cosaU8)sysPageInfo_Limits[i].rlim_cur;
                pMDLimitData[1] = (cosaU8)sysPageInfo_Limits[i].rlim_max;
                pMDLimitData += sizeof(cosaU8) * 2;
                break;
            }
            case 1: {
                cosaU16 *pData = (cosaU16*)pMDLimitData;
                pData[0] = (cosaU16)sysPageInfo_Limits[i].rlim_cur;
                pData[1] = (cosaU16)sysPageInfo_Limits[i].rlim_max;
                pMDLimitData += sizeof(cosaU16) * 2;
                break;
            }
            case 2: {
                cosaU32 *pData = (cosaU32*)pMDLimitData;
                pData[0] = (cosaU32)sysPageInfo_Limits[i].rlim_cur;
                pData[1] = (cosaU32)sysPageInfo_Limits[i].rlim_max;
                pMDLimitData += sizeof(cosaU32) * 2;
                break;
            }
            case 3: {
                cosaU64 *pData = (cosaU64*)pMDLimitData;
                pData[0] = (cosaU64)sysPageInfo_Limits[i].rlim_cur;
                pData[1] = (cosaU64)sysPageInfo_Limits[i].rlim_max;
                pMDLimitData += sizeof(cosaU64) * 2;
                break;
            }
        }
    }
    cosaPageSetMD(pContext, &sysPage_Info, COSA_SYSPAGE_INFO_ID);
}

static void _LinuxCosaInitMemPage(cosaContext *pContext) {
    cosaPage memPage_Blocks = {0};
    cosaPageGetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);
    memPage_Blocks.dataCount = COSA_MEMPAGE_BLOCKS_START;
    memPage_Blocks.dataTop = 0;
    memPage_Blocks.pData = malloc(COSA_MEMPAGE_BLOCKS_START * sizeof(cosaBlock));
    if (memPage_Blocks.pData == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }

    cosaPage memPage_Freed = {0};
    cosaPageGetMD(pContext, &memPage_Freed, COSA_MEMPAGE_FREED_ID);
    memPage_Freed.dataCount = COSA_MEMPAGE_FREED_START;
    memPage_Freed.dataTop = 0;
    memPage_Freed.pData = malloc(COSA_MEMPAGE_FREED_START * sizeof(cosaU64));
    if (memPage_Freed.pData == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(memPage_Blocks.pData);
        return;
    }
    cosaOPZEROArea(pContext, memPage_Blocks.pData, COSA_MEMPAGE_BLOCKS_START * sizeof(cosaBlock));
    cosaOPZEROArea(pContext, memPage_Freed.pData, COSA_MEMPAGE_FREED_START * sizeof(cosaU64));

    cosaPageSetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);
    cosaPageSetMD(pContext, &memPage_Freed, COSA_MEMPAGE_FREED_ID);
}

static void _LinuxCosaInitStrPage(cosaContext *pContext) {
/*
    pContext->systemMD.pStrPage = malloc(sizeof(_StrPage_LV3));
    if (pContext->systemMD.pStrPage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPSETArea(pContext, pContext->systemMD.pStrPage, 0x00, sizeof(_StrPage_LV3));
    _StrPage_LV3 *pStrPage = (_StrPage_LV3*)pContext->systemMD.pStrPage;
    pStrPage->dictionariesCount = COSA_STRPAGE_DICTIONARIES_COUNT_START;

    pStrPage->pDictionaries = malloc(COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));
    if (pStrPage->pDictionaries == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pStrPage);

        pContext->systemMD.pStrPage = NULL;
        return;
    }
    cosaOPSETArea(pContext, pStrPage->pDictionaries, 0x00, COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));
*/
}

static void _LinuxCosaInitFilePage(cosaContext *pContext) {
/*
    pContext->systemMD.pFilePage = malloc(sizeof(_FilePage_LV3));
    if (pContext->systemMD.pFilePage == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPSETArea(pContext, pContext->systemMD.pFilePage, 0x00, sizeof(_FilePage_LV3));
    _FilePage_LV3 *pFilePage = (_FilePage_LV3*)pContext->systemMD.pFilePage;
    pFilePage->finfoCount = COSA_FILEPAGE_FINFO_COUNT_START;
    pFilePage->fileCount = COSA_FILEPAGE_FILE_COUNT_START;

    pFilePage->pFInfos = malloc(COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    if (pFilePage->pFInfos == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pContext->systemMD.pFilePage);

        pContext->systemMD.pFilePage = NULL;
        return;
    }

    pFilePage->pFiles = malloc(COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
    if (pFilePage->pFiles == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        free(pFilePage->pFInfos);
        free(pContext->systemMD.pFilePage);

        pFilePage->pFInfos = NULL;
        pContext->systemMD.pFilePage = NULL;
        return;
    }
    cosaOPSETArea(pContext, pFilePage->pFInfos, 0x00, COSA_FILEPAGE_FINFO_COUNT_START * sizeof(cosaFInfo));
    cosaOPSETArea(pContext, pFilePage->pFiles,  0x00, COSA_FILEPAGE_FILE_COUNT_START * sizeof(cosaFile));
*/
}

static void _LinuxCosaDestroySysInfo(cosaContext *pContext) {
    cosaPage sysPage_Info = {0};
    cosaPageGetMD(pContext, &sysPage_Info, COSA_SYSPAGE_INFO_ID);
    if (sysPage_Info.pData == NULL) { return; }
    sysPage_Info.dataCount = 1;
    sysPage_Info.dataTop = 0;

    free(sysPage_Info.pData);
    sysPage_Info.pData = NULL;
    cosaPageSetMD(pContext, &sysPage_Info, COSA_SYSPAGE_INFO_ID);
}

static void _LinuxCosaDestroyMemPage(cosaContext *pContext) {
    cosaPage memPage_Blocks = {0};
    cosaPageGetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);
    cosaBlock *pMDBlocks = memPage_Blocks.pData;
    if (pMDBlocks == NULL) { return; }

    while (memPage_Blocks.dataTop != 0) {
        --memPage_Blocks.dataTop;
        cosaBlock *pBlockMD = &pMDBlocks[memPage_Blocks.dataTop];
        cosaDestroyBlock(pContext, &pBlockMD);
    }
    memPage_Blocks.dataCount = 1;

    free(memPage_Blocks.pData);
    memPage_Blocks.pData = NULL;
    cosaPageSetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);

    cosaPage memPage_Freed = {0};
    cosaPageGetMD(pContext, &memPage_Freed, COSA_MEMPAGE_FREED_ID);
    memPage_Freed.dataCount = 1;
    memPage_Freed.dataTop = 0;

    free(memPage_Freed.pData);
    memPage_Freed.pData = NULL;
    cosaPageSetMD(pContext, &memPage_Freed, COSA_MEMPAGE_FREED_ID);
}

static void _LinuxCosaDestroyStrPage(cosaContext *pContext) {
}

static void _LinuxCosaDestroyFilePage(cosaContext *pContext) {
}

#endif