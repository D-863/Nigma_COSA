#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

static void _LinuxCosaExpandPages(cosaContext *pContext, cosaMDPages *pMDPages) {
    void **pNPages = malloc((pMDPages->pageCount + 1) * sizeof(void*));
    if (pNPages == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    } else if ((pMDPages->pageCount != 0) && ((pMDPages->pageCount % 4) == 0)) {
        cosaU8 *pNDataLevels = realloc(pMDPages->pDataLevels, (pMDPages->pageCount + 1) * sizeof(cosaU8));
        if (pNDataLevels == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            free(pNPages);
            return;
        }
        pNDataLevels[pMDPages->pageCount] = 0x00;
        pMDPages->pDataLevels = pNDataLevels;
    }
    cosaOPCPYArea(pContext, pMDPages->pPages, pNPages, pMDPages->pageCount * sizeof(void*));
    pNPages[pMDPages->pageCount] = NULL;
    pMDPages->pPages = pNPages;
    ++pMDPages->pageCount;
}

static void _LinuxCosaFormatMap_LV0(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    void *pMSrc = *ppMSrc;
    switch (srcLV) {
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            break;
        }
        case 1: {
            cosaU16 *pSrc = pMSrc;
            cosaU8 *pDest = pMSrc;
            while (pSrc != &((cosaU16*)pMSrc)[count]) {
                pDest[0] = pSrc[0];
                ++pSrc;
                ++pDest;
            }
            break;
        }
        case 2: {
            cosaU32 *pSrc = pMSrc;
            cosaU8 *pDest = pMSrc;
            while (pSrc != &((cosaU32*)pMSrc)[count]) {
                pDest[0] = pSrc[0];
                ++pSrc;
                ++pDest;
            }
            break;
        }
        case 3: {
            cosaU64 *pSrc = pMSrc;
            cosaU8 *pDest = pMSrc;
            while (pSrc != &((cosaU64*)pMSrc)[count]) {
                pDest[0] = pSrc[0];
                ++pSrc;
                ++pDest;
            }
            break;
        }
    }
    pMSrc = realloc(pMSrc, count * sizeof(cosaU8));
    if (pMSrc != NULL) {
        (*ppMSrc) = pMSrc;
    } else {
        cosaErrno(pContext, __FILE__, __LINE__);
    }
}

static void _LinuxCosaFormatMap_LV1(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    void *pMSrc = *ppMSrc;
    switch (srcLV) {
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            break;
        }
        case 0: {
            pMSrc = realloc(pMSrc, count * sizeof(cosaU16));
            if (pMSrc == NULL) {
                cosaErrno(pContext, __FILE__, __LINE__);
                return;
            }
            (*ppMSrc) = pMSrc;

            cosaU8 *pSrc = pMSrc;
            cosaU16 *pDest = pMSrc;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            return;
        }
        case 2: {
            cosaU32 *pSrc = pMSrc;
            cosaU16 *pDest = pMSrc;
            while (pSrc != &((cosaU32*)pMSrc)[count]) {
                pDest[0] = pSrc[0];
                ++pSrc;
                ++pDest;
            }
            break;
        }
        case 3: {
            cosaU64 *pSrc = pMSrc;
            cosaU16 *pDest = pMSrc;
            while (pSrc != &((cosaU64*)pMSrc)[count]) {
                pDest[0] = pSrc[0];
                ++pSrc;
                ++pDest;
            }
            break;
        }
    }
    pMSrc = realloc(pMSrc, count * sizeof(cosaU16));
    if (pMSrc != NULL) {
        (*ppMSrc) = pMSrc;
    } else {
        cosaErrno(pContext, __FILE__, __LINE__);
    }
}

static void _LinuxCosaFormatMap_LV2(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU32 *pDest = *ppMSrc;
    if (srcLV == 3) {
        cosaU32 *pNew = pDest;
        cosaU64 *pOld = pDest;
        while (pOld != &((cosaU64*)pDest)[count]) {
            pNew[0] = pOld[0];
            ++pOld;
            ++pNew;
        }
    }
    pDest = realloc(pDest, count * sizeof(cosaU32));
    if (pDest == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pDest;

    switch (srcLV) {
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            break;
        }
        case 0: {
            cosaU8 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 1: {
            cosaU16 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 3:
    }
}

static void _LinuxCosaFormatMap_LV3(cosaContext *pContext, void **ppMSrc, cosaU64 count, cosaU8 srcLV) {
    cosaU64 *pDest = realloc(*ppMSrc, count * sizeof(cosaU64));
    if (pDest == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    (*ppMSrc) = pDest;

    switch (srcLV) {
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            break;
        }
        case 0: {
            cosaU8 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 1: {
            cosaU16 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
        case 2: {
            cosaU32 *pSrc = pDest;
            while (count != 0) {
                --count;
                pDest[count] = pSrc[count];
            }
            break;
        }
    }
}

static void _LinuxCosaFInfoParse(cosaFile *pFile, const _CosaLinux_STAT *pFileStat) {
    pFile->pFInfo->uid   = pFileStat->st_uid;
    pFile->pFInfo->gid   = pFileStat->st_gid;
    pFile->pFInfo->atime = pFileStat->st_atime;
    pFile->pFInfo->mtime = pFileStat->st_mtime;
    pFile->pFInfo->stime = pFileStat->st_ctime;

    if ((pFileStat->st_mode & __S_IFMT) == __S_IFLNK) { pFile->flags |= COSA_FILE_FLAG_IS_LINK; }
    if ((pFileStat->st_mode & __S_IFMT) == __S_IFDIR) { pFile->flags |= COSA_FILE_FLAG_IS_DIRE; }
    if ((pFileStat->st_mode & S_IRUSR) == S_IRUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_RD; }
    if ((pFileStat->st_mode & S_IWUSR) == S_IWUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_WE; }
    if ((pFileStat->st_mode & S_IXUSR) == S_IXUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_EX; }
    if ((pFileStat->st_mode & S_IRGRP) == S_IRGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_RD; }
    if ((pFileStat->st_mode & S_IWGRP) == S_IWGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_WE; }
    if ((pFileStat->st_mode & S_IXGRP) == S_IXGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_EX; }
    if ((pFileStat->st_mode & S_IROTH) == S_IROTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_RD; }
    if ((pFileStat->st_mode & S_IWOTH) == S_IWOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_WE; }
    if ((pFileStat->st_mode & S_IXOTH) == S_IXOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_EX; }
    if ((pFileStat->st_mode & S_ISUID) == S_ISUID) { pFile->flags |= COSA_FILE_FLAG_SET_UID; }
    if ((pFileStat->st_mode & S_ISGID) == S_ISGID) { pFile->flags |= COSA_FILE_FLAG_SET_GID; }
}

#endif