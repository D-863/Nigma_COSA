#ifndef NIGMA_COSA_LINUX_STATICS_H
#define NIGMA_COSA_LINUX_STATICS_H

#include "utilities.h"

static void _LinuxCosaExpandPages(cosaContext *pContext, cosaMDPages *pMDPages) {
    register cosaMDPages *pPages = pMDPages;

    void **pNPages = malloc((pPages->pageCount + 1) * sizeof(void*));
    if (pNPages == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    } else if ((pPages->pageCount != 0) && ((pPages->pageCount % 4) == 0)) {
        cosaU8 *pNDataLevels = realloc(pPages->pDataLevels, (pPages->pageCount + 1) * sizeof(cosaU8));
        if (pNDataLevels == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            free(pNPages);
            return;
        }
        pNDataLevels[pPages->pageCount] = 0x00;
        pPages->pDataLevels = pNDataLevels;
    }
    cosaOPCPYArea(pContext, pPages->pPages, pNPages, pPages->pageCount * sizeof(void*));
    pNPages[pPages->pageCount] = NULL;
    pPages->pPages = pNPages;
    ++pPages->pageCount;
}

static void _LinuxCosaTranslatePage(cosaContext *pContext, cosaMDPages *pMDPages, cosaPage *pPAddr, const cosaPage *pPage, cosaU8 newLV, cosaU8 curLV) {
}

static void _LinuxCosaFInfoParse(cosaFile *pFile, const _CosaLinux_STAT *pFileStat) {
    pFile->pFInfo->uid   = pFileStat->st_uid;
    pFile->pFInfo->gid   = pFileStat->st_gid;
    pFile->pFInfo->atime = pFileStat->st_atime;
    pFile->pFInfo->mtime = pFileStat->st_mtime;
    pFile->pFInfo->stime = pFileStat->st_ctime;

    if ((pFileStat->st_mode & __S_IFMT) == __S_IFLNK) { pFile->flags |= COSA_FILE_FLAG_IS_LINK; }
    if ((pFileStat->st_mode & __S_IFMT) == __S_IFDIR) { pFile->flags |= COSA_FILE_FLAG_IS_DIRE; }
    if ((pFileStat->st_mode & S_IRUSR) == S_IRUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_RD; }
    if ((pFileStat->st_mode & S_IWUSR) == S_IWUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_WE; }
    if ((pFileStat->st_mode & S_IXUSR) == S_IXUSR) { pFile->flags |= COSA_FILE_FLAG_UPRM_EX; }
    if ((pFileStat->st_mode & S_IRGRP) == S_IRGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_RD; }
    if ((pFileStat->st_mode & S_IWGRP) == S_IWGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_WE; }
    if ((pFileStat->st_mode & S_IXGRP) == S_IXGRP) { pFile->flags |= COSA_FILE_FLAG_GPRM_EX; }
    if ((pFileStat->st_mode & S_IROTH) == S_IROTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_RD; }
    if ((pFileStat->st_mode & S_IWOTH) == S_IWOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_WE; }
    if ((pFileStat->st_mode & S_IXOTH) == S_IXOTH) { pFile->flags |= COSA_FILE_FLAG_OPRM_EX; }
    if ((pFileStat->st_mode & S_ISUID) == S_ISUID) { pFile->flags |= COSA_FILE_FLAG_SET_UID; }
    if ((pFileStat->st_mode & S_ISGID) == S_ISGID) { pFile->flags |= COSA_FILE_FLAG_SET_GID; }
}

#endif