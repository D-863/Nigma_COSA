#ifndef NIGMA_COSA_LINUX_UTILITIES_H
#define NIGMA_COSA_LINUX_UTILITIES_H

#include "../../../headers/utilities.h"
#include "../../../headers/compilics.h"
#include "inlines.h"
#include "statics.h"

#endif