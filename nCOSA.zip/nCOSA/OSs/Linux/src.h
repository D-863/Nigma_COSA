#ifndef NIGMA_COSA_LINUX_SRC_H
#define NIGMA_COSA_LINUX_SRC_H

#include "headers/utilities.h"

//Operations:
cosaCompilifics(INLINE, void linuxCosaOPZEROArea(void *pAddr, cosaUSize size)) {
    while (size > 7) {
        ((cosaU64*)pAddr)[0] = 0x0000000000000000;
        pAddr = ((cosaU64*)pAddr) + 1;
        size -= sizeof(cosaU64);
    }

    while (size != 0) {
        --size;
        ((cosaU8*)pAddr)[size] = 0x00;
    }
}

cosaCompilifics(INLINE, void linuxCosaOPSETArea(void *pAddr, cosaU8 value, cosaUSize size)) {
    register cosaU64 bValue = value;
    bValue |= bValue << 8;
    bValue |= bValue << 16;
    bValue |= bValue << 32;
    while (size > 7) {
        ((cosaU64*)pAddr)[0] = bValue;
        pAddr = ((cosaU64*)pAddr) + 1;
        size -= sizeof(cosaU64);
    }

    while (size != 0) {
        --size;
        ((cosaU8*)pAddr)[size] = bValue;
    }
}

cosaCompilifics(INLINE, void linuxCosaOPMOVLArea(void *pAddr, cosaUSize offset, cosaUSize size)) {
    register cosaU8 *pSA = ((cosaU8*)pAddr) - offset;

    while (size != 0) {
        --size;
        pSA[0] = pSA[offset];
        pSA += offset;
    }
}

cosaCompilifics(INLINE, void linuxCosaOPMOVRArea(void *pAddr, cosaUSize offset, cosaUSize size)) {
    register cosaU8 *pSA = &((cosaU8*)pAddr)[size];
    while (size > 7) {
        size -= sizeof(cosaU64);
        pSA -= sizeof(cosaU64);
        ((cosaU64*)&pSA[offset])[0] = ((cosaU64*)pSA)[0];
    }

    while (size != 0) {
        --size;
        --pSA;
        pSA[offset] = pSA[0];
    }
}

cosaCompilifics(INLINE, void linuxCosaOPCPYArea(const void *pSrc, void *pDest, cosaUSize size)) {
    register cosaU64 *pA = (cosaU64*)pSrc;
    while (size > 7) {
        ((cosaU64*)pDest)[0] = *pA;
        pDest = ((cosaU64*)pDest) + 1;
        size -= sizeof(cosaU64);
        ++pA;
    }

    register cosaU8 *pSA = (cosaU8*)pA;
    while (size != 0) {
        ((cosaU8*)pDest)[0] = *pSA;
        pDest = ((cosaU8*)pDest) + 1;
        --size;
        ++pSA;
    }
}

cosaCompilifics(INLINE, void linuxCosaOPSWPArea(void *pAddrA, void *pAddrB, cosaUSize size)) {
    register cosaU64 *pA = (cosaU64*)pAddrA;
    register cosaU64 C;
    while (size > 7) {
        C = *pA;
        pA[0] = *((cosaU64*)pAddrB);
        ((cosaU64*)pAddrB)[0] = C;
        pAddrB = ((cosaU64*)pAddrB) + 1;
        size -= sizeof(cosaU64);
        ++pA;
    }

    register cosaU8 *pSA = (cosaU8*)pA;
    register cosaU8 nC = C;
    while (size != 0) {
        nC = *pSA;
        pSA[0] = *((cosaU8*)pAddrB);
        ((cosaU8*)pAddrB)[0] = nC;
        pAddrB = ((cosaU8*)pAddrB) + 1;
        --size;
        ++pSA;
    }
}

//Pages:
cosaCompilifics(INLINE, void linuxCosaCreatePage(cosaContext *pContext, cosaU64 *pPageID, cosaU8 startLV)) {
    cosaMDBuffers *pMDBuffers = &pContext->systemMD.buffers;
    if (pMDBuffers->pageCount >= COSA_BUFFERS_PAGECOUNT_MAX) {
        pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
        pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }

    const register cosaU64 bufferCount = pMDBuffers->pageCount;
    if ((bufferCount != 0) && ((bufferCount % 4) == 0)) {
        cosaU8 *pNDataLevels = realloc(pMDBuffers->pDataLevels, (bufferCount + 1) * sizeof(cosaU8));
        if (pNDataLevels == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        pNDataLevels[bufferCount] = 0x00;
        pMDBuffers->pDataLevels = pNDataLevels;
    }

    void **pNPages = realloc(pMDBuffers->pPages, (bufferCount + 1) * sizeof(void*));
    if (pNPages == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    pMDBuffers->pPages = pNPages;

    cosaUSize sizePageLV = sizeof(cosaMDPage_LV0);
    switch (startLV) {
        case 1: { 
            sizePageLV = sizeof(cosaMDPage_LV1);
            break;
        }
        case 2: { 
            sizePageLV = sizeof(cosaMDPage_LV2);
            break;
        }
        case 3: { 
            sizePageLV = sizeof(cosaMDPage_LV3);
            break;
        }
    }
    pNPages[bufferCount] = malloc(sizePageLV);
    if (pNPages[bufferCount] == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPZEROArea(pContext, pNPages[bufferCount], sizePageLV);
    pMDBuffers->pDataLevels[bufferCount >> 2] |= startLV << ((bufferCount % 4) * 2);

    pMDBuffers->pageCount = bufferCount + 1;
    (*pPageID) = bufferCount;
}

cosaCompilifics(INLINE, void linuxCosaPageGetMD(cosaContext *pContext, cosaPage *pPage, cosaU64 pageID)) {
    const cosaMDBuffers *pMDBuffers = &pContext->systemMD.buffers;
    if (pageID >= pMDBuffers->pageCount) {
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }

    const void *pPAddr = pMDBuffers->pPages[pageID];
    pPage->LV = cosaBit2R(pMDBuffers->pDataLevels[pageID >> 2] >> ((pageID % 4) * 2));
    switch (pPage->LV) {
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            break;
        }
        case 0: {
            const cosaMDPage_LV0 *pPageMD = pPAddr;
            pPage->dataCount = pPageMD->dataCount;
            pPage->dataTop = pPageMD->dataTop;
            pPage->pData = pPageMD->pData;
            break;
        }
        case 1: {
            const cosaMDPage_LV1 *pPageMD = pPAddr;
            pPage->dataCount = pPageMD->dataCount;
            pPage->dataTop = pPageMD->dataTop;
            pPage->pData = pPageMD->pData;
            break;
        }
        case 2: {
            const cosaMDPage_LV2 *pPageMD = pPAddr;
            pPage->dataCount = pPageMD->dataCount;
            pPage->dataTop = pPageMD->dataTop;
            pPage->pData = pPageMD->pData;
            break;
        }
        case 3: {
            const cosaMDPage_LV3 *pPageMD = pPAddr;
            pPage->dataCount = pPageMD->dataCount;
            pPage->dataTop = pPageMD->dataTop;
            pPage->pData = pPageMD->pData;
            break;
        }
    }
}

cosaCompilifics(INLINE, void linuxCosaPageSetMD(cosaContext *pContext, cosaPage *pPage, cosaU64 pageID)) {
    const cosaMDBuffers *pMDBuffers = &pContext->systemMD.buffers;
    if (pageID >= pMDBuffers->pageCount) {
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
    const cosaU64 testVal = pPage->dataCount | pPage->dataTop;
    cosaU8 minLV = 0;
    minLV += !!(testVal & 0xFFFFFFFFFFFFFF00); //Is it above 8-Bit?
    minLV += !!(testVal & 0xFFFFFFFFFFFF0000); //Is it above 16-Bit?
    minLV += !!(testVal & 0xFFFFFFFF00000000); //Is it above 32-Bit?
    //If none above succeed, it's minimally a 8-Bit value and hence [minLV] will be 0.

    register void *pPAddr = pMDBuffers->pPages[pageID];
    pPage->LV = cosaBit2R(pMDBuffers->pDataLevels[pageID >> 2] >> ((pageID % 4) * 2));
    switch (minLV) {
        default: {
            pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            break;
        }
        case 0: {
            if (minLV != pPage->LV) {
                pPAddr = realloc(pPAddr, sizeof(cosaMDPage_LV0));
                if (pPAddr == NULL) {
                    cosaErrno(pContext, __FILE__, __LINE__);
                    return;
                }
            }
            cosaMDPage_LV0 *pPageMD = pPAddr;
            pPageMD->dataCount = pPage->dataCount;
            pPageMD->dataTop = pPage->dataTop;
            pPageMD->pData = pPage->pData;
            break;
        }
        case 1: {
            if (minLV != pPage->LV) {
                pPAddr = realloc(pPAddr, sizeof(cosaMDPage_LV1));
                if (pPAddr == NULL) {
                    cosaErrno(pContext, __FILE__, __LINE__);
                    return;
                }
            }
            cosaMDPage_LV1 *pPageMD = pPAddr;
            pPageMD->dataCount = pPage->dataCount;
            pPageMD->dataTop = pPage->dataTop;
            pPageMD->pData = pPage->pData;
            break;
        }
        case 2: {
            if (minLV != pPage->LV) {
                pPAddr = realloc(pPAddr, sizeof(cosaMDPage_LV2));
                if (pPAddr == NULL) {
                    cosaErrno(pContext, __FILE__, __LINE__);
                    return;
                }
            }
            cosaMDPage_LV2 *pPageMD = pPAddr;
            pPageMD->dataCount = pPage->dataCount;
            pPageMD->dataTop = pPage->dataTop;
            pPageMD->pData = pPage->pData;
            break;
        }
        case 3: {
            if (minLV != pPage->LV) {
                pPAddr = realloc(pPAddr, sizeof(cosaMDPage_LV3));
                if (pPAddr == NULL) {
                    cosaErrno(pContext, __FILE__, __LINE__);
                    return;
                }
            }
            cosaMDPage_LV3 *pPageMD = pPAddr;
            pPageMD->dataCount = pPage->dataCount;
            pPageMD->dataTop = pPage->dataTop;
            pPageMD->pData = pPage->pData;
            break;
        }
    }
    pMDBuffers->pPages[pageID] = pPAddr;
    pPage->LV = minLV;

    pMDBuffers->pDataLevels[pageID >> 2] &= ~(0x03 << ((pageID % 4) * 2));
    pMDBuffers->pDataLevels[pageID >> 2] |= minLV << ((pageID % 4) * 2);
}

cosaCompilifics(INLINE, void linuxCosaPageExpand(cosaContext *pContext, cosaPage *pPage, cosaU64 byteSize, cosaU64 pageID)) {
    const cosaMDBuffers *pMDBuffers = &pContext->systemMD.buffers;
    if (pageID >= pMDBuffers->pageCount) {
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }

    if ((pPage->dataTop + 1) >= pPage->dataCount) {
        register cosaU8 *pData = pPage->pData;
        if (pData == NULL) {
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            cosaError(pContext, __FILE__, __LINE__);
            return;
        }
        const cosaU64 area = pPage->dataCount * byteSize;
        const cosaU64 newArea = area * 2;

        pData = realloc(pData, newArea);
        if (pData == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pData[area], 0x00, newArea - area);
        pPage->dataCount *= 2;
        pPage->pData = pData;
    }

    ++pPage->dataTop;
    cosaPageSetMD(pContext, pPage, pageID);
}

//System:
cosaCompilifics(INLINE, void linuxCosaSystemGetInfo(cosaContext *pContext, cosaSysInfo *pSysInfo)) {
    if (pSysInfo->pMinLimits != NULL) {
        free(pSysInfo->pMinLimits);
        pSysInfo->pMinLimits = NULL;
        pSysInfo->pMaxLimits = NULL;
    }

    cosaU64 reqCount = 0;
    COSA_SYSPAGE_INFO_REQLIM_COUNT_TYPE reqArr[COSA_SYSPAGE_INFO_REQLIM_COUNT] = {0};
    for (COSA_SYSPAGE_INFO_REQLIM_COUNT_TYPE i = 0; i < COSA_SYSPAGE_INFO_REQLIM_COUNT; ++i) {
        if (cosaBit1R(pSysInfo->reqLimits.data[i >> 3] >> (i % 8)) == 0x01) {
            reqArr[reqCount] = i;
            ++reqCount;
        }
    }
    pSysInfo->pMinLimits = malloc((2 * reqCount) * sizeof(cosaU64));
    if (pSysInfo->pMinLimits == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    pSysInfo->pMaxLimits = &pSysInfo->pMinLimits[reqCount];

    cosaPage sysPage_Info = {0};
    cosaPageGetMD(pContext, &sysPage_Info, COSA_SYSPAGE_INFO_ID);
    cosaMDSysInfo *pMDInfo = sysPage_Info.pData;
    cosaU8 *pMDLimitData = ((cosaU8*)sysPage_Info.pData) + sizeof(cosaMDSysInfo);

    while (reqCount != 0) {
        --reqCount;
        const COSA_SYSPAGE_INFO_REQLIM_COUNT_TYPE i = reqArr[reqCount];
        const cosaU8 range = cosaBit2R(pMDInfo->data[i/COSA_SYSPAGE_INFO_SIZE] >> ((i % COSA_SYSPAGE_INFO_SIZE) * 2));
        switch (range) {
            case 0: {
                pSysInfo->pMinLimits[i] = (cosaU64)pMDLimitData[0];
                pSysInfo->pMaxLimits[i] = (cosaU64)pMDLimitData[1];
                pMDLimitData += sizeof(cosaU8) * 2;
                break;
            }
            case 1: {
                const cosaU16 *pData = (cosaU16*)pMDLimitData;
                pSysInfo->pMinLimits[i] = (cosaU64)pData[0];
                pSysInfo->pMaxLimits[i] = (cosaU64)pData[1];
                pMDLimitData += sizeof(cosaU16) * 2;
                break;
            }
            case 2: {
                const cosaU32 *pData = (cosaU32*)pMDLimitData;
                pSysInfo->pMinLimits[i] = (cosaU64)pData[0];
                pSysInfo->pMaxLimits[i] = (cosaU64)pData[1];
                pMDLimitData += sizeof(cosaU32) * 2;
                break;
            }
            case 3: {
                const cosaU64 *pData = (cosaU64*)pMDLimitData;
                pSysInfo->pMinLimits[i] = pData[0];
                pSysInfo->pMaxLimits[i] = pData[1];
                pMDLimitData += sizeof(cosaU64) * 2;
                break;
            }
        }
    }
}

//RAM:
cosaCompilifics(INLINE, void *linuxCosaCreateBlock(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    if (ppBAddr != NULL) {
        if ((*ppBAddr) != NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
            cosaError(pContext, __FILE__, __LINE__);
            return NULL;
        }
    }
    const cosaUSize area = count * byteSize;

    // area > PTRDIFF_MAX
    if (cosaCUnlikely((area >> 63) & 0x1)) {
        /*
            Somehow, the program needs more than 8EB(PTRDIFF_MAX / (1024 ^ 6) = 8) of RAM.. <_<'
            And glibc doesn't like that, infact the Kernel itself doesn't like that.
        */
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;;
    }
    cosaPage memPage_Blocks = {0};
    cosaPageGetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);
    cosaBlock *pMDBlocks = memPage_Blocks.pData;
    cosaU64 blockIndex = 0;

    //Find a adequate freed block, otherwise get a fresh one.
    /*NOTE:
        I know this is a nightmare but give me a damn breather,
        I am sick while coding this and it feels like my head is going to explode.
    */
    cosaBool found = cosaBFalse;
    cosaPage memPage_Freed = {0};
    cosaPageGetMD(pContext, &memPage_Freed, COSA_MEMPAGE_FREED_ID);
    cosaU64 *pMDFreed = memPage_Freed.pData;
    cosaU64 freedIndex = 0;
    cosaU64 pL = 0;
    cosaU64 pR = memPage_Freed.dataTop;
    while (pL <= pR) {
        freedIndex = pL + ((pR - pL) / 2);

        const cosaUSize freedArea = pMDBlocks[pMDFreed[freedIndex]].count * pMDBlocks[pMDFreed[freedIndex]].byteSize;
        if (freedArea == area) {
            blockIndex = pMDFreed[freedIndex];
            found = cosaBTrue;

            --memPage_Freed.dataTop;
            while (&pMDFreed[freedIndex] != &pMDFreed[memPage_Freed.dataTop]) {
                pMDFreed[freedIndex] = pMDFreed[freedIndex + 1];
                ++freedIndex;
            }
            cosaPageSetMD(pContext, &memPage_Freed, COSA_MEMPAGE_FREED_ID);
            break;
        }
        if (freedArea < area) { pL = freedIndex + 1; } else { pR = freedIndex - 1; }
    }

    if (found == cosaBFalse) {
        //The block is fresh, allocate more ram.
        linuxCosaPageExpand(pContext, &memPage_Blocks, sizeof(cosaBlock), COSA_MEMPAGE_BLOCKS_ID);
        pMDBlocks = memPage_Blocks.pData;
        blockIndex = memPage_Blocks.dataTop - 1;
    
        pMDBlocks[blockIndex].addr = malloc(area);
        if (pMDBlocks[blockIndex].addr == NULL) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return NULL;
        }
    }
    //Initialize acquired block for usage.
    pMDBlocks[blockIndex].flags = COSA_MEM_FLAGS_DEFAULT;
    pMDBlocks[blockIndex].byteSize = byteSize;
    pMDBlocks[blockIndex].count = count;

    if (ppBAddr != NULL) { (*ppBAddr) = &pMDBlocks[blockIndex]; }
    return pMDBlocks[blockIndex].addr;
}

cosaCompilifics(INLINE, void linuxCosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize)) {
    const cosaUSize oldArea = pBAddr->count * pBAddr->byteSize;
    const cosaUSize newArea = count * byteSize;
    if (newArea <= oldArea) { return; }

    cosaU8 *pNAddr = realloc(pBAddr->addr, newArea);
    if (pNAddr == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    pBAddr->byteSize = byteSize;
    pBAddr->count = count;
    pBAddr->addr = pNAddr;
}

cosaCompilifics(INLINE, void linuxCosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize)) {
    const cosaUSize oldArea = pBAddr->count * pBAddr->byteSize;
    const cosaUSize newArea = count * byteSize;
    if (newArea >= oldArea) { return; }

    cosaU8 *pNAddr = realloc(pBAddr->addr, newArea);
    if (pNAddr == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    pBAddr->byteSize = byteSize;
    pBAddr->count = count;
    pBAddr->addr = pNAddr;
}

cosaCompilifics(INLINE, void linuxCosaBlockSegment(cosaContext *pContext, const cosaBlock *pBSrc, cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size)) {
    const cosaUSize srcArea = pBSrc->count * pBSrc->byteSize;
    const cosaUSize destArea = pBDest->count * pBDest->byteSize;
    if ((size > srcArea) || (size > destArea)) {
        //The selected area of [size] is beyond either [srcArea] or [destArea].
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((srcOffset > (srcArea - size)) || (destOffset > (destArea - size))) {
        //The offseted area of size by either offset's is beyond the respective area of offet..
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPCPYArea(
        pContext,
        ((cosaU8*)pBSrc->addr) + srcOffset,
        ((cosaU8*)pBDest->addr) + destOffset,
        size
    );
}

cosaCompilifics(INLINE, void linuxCosaBlockGetMD(cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr)) {
    cosaPage memPage_Blocks = {0};
    cosaPageGetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);

    register cosaBlock *pBlock = memPage_Blocks.pData;
    while (pBlock != &((cosaBlock*)memPage_Blocks.pData)[memPage_Blocks.dataTop]) {
        if (pBlock->addr == pAddr) {
            (*ppBAddr) = pBlock;
            break;
        }
        ++pBlock;
    }
}

cosaCompilifics(INLINE, void linuxCosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr)) {
    if (((*ppBAddr)->flags & COSA_MEM_FLAGS_FREED) == COSA_MEM_FLAGS_FREED) { return; }
    //TO BE REIMPLEMENTED.
}

cosaCompilifics(INLINE, void linuxCosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr)) {
    if ((*ppBAddr) == NULL) { return; }
    if ((*ppBAddr)->addr == NULL) { return; }
    cosaPage memPage_Blocks = {0};
    cosaPageGetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);
    if (memPage_Blocks.dataTop == 0) { return; }
    cosaBlock *pBlock = *ppBAddr;
    //if (pBlock->flags & COSA_MEM_FLAGS_FREED)  { _LinuxCosaRemove_BlockFreed(pContext, 0); }
    //if (pBlock->flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_UnlinkMD_LV3(pContext, ppBAddr); }
    free(pBlock->addr);
    pBlock->addr = NULL;
    (*ppBAddr) = NULL;

    --memPage_Blocks.dataTop;
    register cosaU64 tIndex = memPage_Blocks.dataTop;
    const cosaBlock *pMDBlocks = memPage_Blocks.pData;
    cosaU64 bIndex = pBlock - pMDBlocks;

    cosaPageSetMD(pContext, &memPage_Blocks, COSA_MEMPAGE_BLOCKS_ID);
    if (bIndex == tIndex) { return; }
    pBlock->flags    = pMDBlocks[tIndex].flags;
    pBlock->byteSize = pMDBlocks[tIndex].byteSize;
    pBlock->count    = pMDBlocks[tIndex].count;
    pBlock->addr     = pMDBlocks[tIndex].addr;

    //if (pMDBlocks[tIndex].flags & COSA_MEM_FLAGS_LINKED) { _BlockLink_ChangeBlockMD_LV3(pContext, tIndex, bIndex); }
}

//Stacks:
cosaCompilifics(INLINE, void linuxCosaCreateStackSS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaStackMD_SX *pStackMD = cosaCreateBlock(
        pContext, ppBAddr,
        (count * byteSize) + sizeof(cosaStackMD_SX),
        sizeof(cosaU8)
    );
    cosaOPSETArea(pContext, pStackMD, 0x00, sizeof(cosaStackMD_SX));
    pStackMD->type = COSA_STACK_TYPE_SS;
    pStackMD->bSize = byteSize;
}

cosaCompilifics(INLINE, void linuxCosaCreateStackSD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaStackMD_SX *pStackMD = cosaCreateBlock(
        pContext, ppBAddr,
        (count * byteSize) + sizeof(cosaStackMD_SX),
        sizeof(cosaU8)
    );
    cosaOPSETArea(pContext, pStackMD, 0x00, sizeof(cosaStackMD_SX));
    pStackMD->type = COSA_STACK_TYPE_SD;
    pStackMD->bSize = byteSize;
}

cosaCompilifics(INLINE, void linuxCosaCreateStackDS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size)) {
    cosaStackMD_DX *pStackMD = cosaCreateBlock(
        pContext, ppBAddr,
        size + sizeof(cosaStackMD_DX),
        sizeof(cosaU8)
    );
    cosaOPSETArea(pContext, pStackMD, 0x00, sizeof(cosaStackMD_DX));
    pStackMD->type = COSA_STACK_TYPE_DS;
}

cosaCompilifics(INLINE, void linuxCosaCreateStackDD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size)) {
    cosaStackMD_DX *pStackMD = cosaCreateBlock(
        pContext, ppBAddr,
        size + sizeof(cosaStackMD_DX),
        sizeof(cosaU8)
    );
    cosaOPSETArea(pContext, pStackMD, 0x00, sizeof(cosaStackMD_DX));
    pStackMD->type = COSA_STACK_TYPE_DD;
}

cosaCompilifics(INLINE, void linuxCosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem)) {
    cosaStackMD_SX *pStackMD = cosaStackMD(pStack, S);

    const cosaUSize offset = pStackMD->top * pStackMD->bSize;
    cosaUSize size = pStack->count - sizeof(cosaStackMD_SX);
    if (offset >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_SD: {
                size += (offset - size) + (COSA_STACK_SX_EXPAND * pStackMD->bSize);

                cosaBlockExpand(pContext, pStack, size + sizeof(cosaStackMD_SX), sizeof(cosaU8));
                pStackMD = cosaStackMD(pStack, S);
                break;
            }
            case COSA_STACK_TYPE_SS: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
        }
    }
    cosaOPCPYArea(pContext, pItem, cosaStackMD_Mem(pStack, S) + offset, pStackMD->bSize);

    ++pStackMD->top;
}

cosaCompilifics(INLINE, void linuxCosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem, cosaUSize itemSize)) {
    cosaStackMD_DX *pStackMD = cosaStackMD(pStack, D);

    const cosaU32 newTop = pStackMD->top + itemSize + sizeof(itemSize);
    cosaUSize size = pStack->count - sizeof(cosaStackMD_DX);
    if (newTop >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_DD: {
                size += newTop - size;
                size += COSA_STACK_DX_EXPAND * COSA_STACK_SX_EXPAND;

                cosaBlockExpand(pContext, pStack, size + sizeof(cosaStackMD_DX), sizeof(cosaU8));
                pStackMD = cosaStackMD(pStack, D);
                break;
            }
            case COSA_STACK_TYPE_DS: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
        }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, D) + pStackMD->top;
    cosaOPCPYArea(pContext, pItem, pMem, itemSize);
    cosaOPCPYArea(pContext, &itemSize, pMem + itemSize, sizeof(itemSize));

    pStackMD->top = newTop;
}

cosaCompilifics(INLINE, void *linuxCosaStackSXPop(cosaContext *pContext, const cosaBlock *pStack)) {
    cosaStackMD_SX *pStackMD = cosaStackMD(pStack, S);

    if (pStackMD->top == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
    --pStackMD->top;

    const cosaUSize offset = pStackMD->top * pStackMD->bSize;
    return cosaStackMD_Mem(pStack, S) + offset;
}

cosaCompilifics(INLINE, void *linuxCosaStackDXPop(cosaContext *pContext, const cosaBlock *pStack, cosaUSize *pItemSize)) {
    cosaStackMD_DX *pStackMD = cosaStackMD(pStack, D);

    if (pStackMD->top < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
    pStackMD->top -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, D);
    const cosaUSize itemSize = *((cosaUSize*)(pMem + pStackMD->top));

    if (pItemSize != NULL) { (*pItemSize) = itemSize; }
    pStackMD->top -= itemSize;

    return pMem + pStackMD->top;
}

//Queues:
cosaCompilifics(INLINE, void linuxCosaCreateQueue(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    const cosaUSize area = (count * byteSize) + sizeof(cosaQueueMD);
    cosaQueueMD *pQueueMD = cosaCreateBlock(pContext, ppBAddr, area, sizeof(cosaU8));
    cosaOPSETArea(pContext, pQueueMD, 0x00, area);
    pQueueMD->bSize = byteSize;
}

cosaCompilifics(INLINE, void linuxCosaQueueAdd(cosaContext *pContext, const cosaBlock *pQueue, const void *pItem)) {
    cosaQueueMD *pQueueMD = cosaQueueMD(pQueue);

    const cosaUSize size = pQueue->count - sizeof(cosaQueueMD);
    if ((size - (pQueueMD->count * pQueueMD->bSize)) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
    cosaOPCPYArea(pContext, pItem, cosaQueueMD_Mem(pQueue) + pQueueMD->back, pQueueMD->bSize);
    pQueueMD->back = (pQueueMD->back + pQueueMD->bSize) % size;

    ++pQueueMD->count;
}

cosaCompilifics(INLINE, void *linuxCosaQueueNext(cosaContext *pContext, const cosaBlock *pQueue)) {
    cosaQueueMD *pQueueMD = cosaQueueMD(pQueue);

    const cosaUSize size = pQueue->count - sizeof(cosaQueueMD);
    if (pQueueMD->count == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
    cosaU8 *pMem = cosaQueueMD_Mem(pQueue) + pQueueMD->front;
    pQueueMD->front = (pQueueMD->front + pQueueMD->bSize) % size;

    --pQueueMD->count;
    return pMem;
}

//Strings:
cosaCompilifics(INLINE, void linuxCosaCreateDictionary(cosaContext *pContext, cosaU64 *pDictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaStringLoad(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaStringUnload(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaStringAddEntry(cosaContext *pContext, cosaString *pString, const cosaChar *pText, cosaU64 dictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaStringRemoveEntry(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaStringGet(cosaContext *pContext, cosaBlock **ppBAddr, const cosaString *pString, cosaU64 dictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaDestroyDictionary(cosaContext *pContext, cosaU64 dictionaryID)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

//Files:
cosaCompilifics(INLINE, void linuxCosaFileOpen(cosaContext *pContext, cosaFile **ppFile, const cosaChar *pFilePath, cosaU16 flags)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
    /*
    #if ((COSA_FILE_FLAG_PERM_RD == 0x0001) && (COSA_FILE_FLAG_PERM_WE == 0x0002) && (COSA_FILE_FLAG_PERM_RW == 0x0003))
        cosaS32 fileFlags = cosaBit2R(flags) - 1;
    #else
        cosaS32 fileFlags = 0x00000000;
        switch (cosaBit2R(flags)) {
            case COSA_FILE_FLAG_PERM_RD: {
                fileFlags = O_RDONLY;
                break;
            }
            case COSA_FILE_FLAG_PERM_WE: {
                fileFlags = O_WRONLY;
                break;
            }
            case COSA_FILE_FLAG_PERM_RW: {
                fileFlags = O_RDWR;
                break;
            }
        }
    #endif
        cosaS32 fd = open(pFilePath, fileFlags, 0);
        if (fd == -1) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }

        _CosaLinux_STAT fileStat;
        if (fstat(fd, &fileStat) == -1) {
            cosaErrno(pContext, __FILE__, __LINE__);
            (void)close(fd);
            return;
        }

        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.filePage, _FileMD_GetNew, pContext, ppFile);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            (void)close(fd);
            return;
        }
        cosaFile *pFile = *ppFile;
        pFile->key |= fd;
        pFile->flags |= cosaBit2R(flags);
        pFile->size = fileStat.st_size;
        cosaStringAddEntry(pContext, &pFile->sPath, pFilePath, 0);

        if ((flags & COSA_FILE_FLAG_LOAD_FINFO) == COSA_FILE_FLAG_LOAD_FINFO) {
            cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.filePage, _FileMD_GetFINFO, pContext, pFile);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
            _LinuxCosaFInfoParse(pFile, &fileStat);
        }
    */
}

cosaCompilifics(INLINE, void linuxCosaFileLoadInfo(cosaContext *pContext, cosaFile *pFile)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
    /*
        _CosaLinux_STAT fileStat;
        cosaS32 fd = (cosaS32)(pFile->key & 0x0000FFFF);
        if (fstat(fd, &fileStat) == -1) {
            cosaErrno(pContext, __FILE__, __LINE__);
            return;
        }

        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.filePage, _FileMD_GetFINFO, pContext, pFile);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        _LinuxCosaFInfoParse(pFile, &fileStat);
    */
}

cosaCompilifics(INLINE, void linuxCosaFileUnloadInfo(cosaContext *pContext, cosaFile *pFile)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaFileCreate(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaFileWrite(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaFileRead(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

//CosaContext:
cosaCompilifics(INLINE, void linuxCosaInitContext(cosaContext *pContext)) {
    cosaU64 pageIDs[COSA_PAGE_STATIC_ID_COUNT] = {0};
    cosaCreatePage(pContext, &pageIDs[COSA_SYSPAGE_INFO_ID],         0);
    cosaCreatePage(pContext, &pageIDs[COSA_MEMPAGE_BLOCKS_ID],       0);
    cosaCreatePage(pContext, &pageIDs[COSA_MEMPAGE_FREED_ID],        0);
    cosaCreatePage(pContext, &pageIDs[COSA_STRPAGE_DICTIONARIES_ID], 0);
    cosaCreatePage(pContext, &pageIDs[COSA_STRPAGE_FREED_ID],        0);
    cosaCreatePage(pContext, &pageIDs[COSA_FILEPAGE_FINFOS_ID],      0);
    cosaCreatePage(pContext, &pageIDs[COSA_FILEPAGE_FILES_ID],       0);

    cosaU64 pageError = 0;
    pageError += (pageIDs[COSA_SYSPAGE_INFO_ID]         ^ COSA_SYSPAGE_INFO_ID);
    pageError += (pageIDs[COSA_MEMPAGE_BLOCKS_ID]       ^ COSA_MEMPAGE_BLOCKS_ID);
    pageError += (pageIDs[COSA_MEMPAGE_FREED_ID]        ^ COSA_MEMPAGE_FREED_ID);
    pageError += (pageIDs[COSA_STRPAGE_DICTIONARIES_ID] ^ COSA_STRPAGE_DICTIONARIES_ID);
    pageError += (pageIDs[COSA_STRPAGE_FREED_ID]        ^ COSA_STRPAGE_FREED_ID);
    pageError += (pageIDs[COSA_FILEPAGE_FINFOS_ID]      ^ COSA_FILEPAGE_FINFOS_ID);
    pageError += (pageIDs[COSA_FILEPAGE_FILES_ID]       ^ COSA_FILEPAGE_FILES_ID);
    if (pageError != 0) {
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }

    _LinuxCosaInitSysInfo(pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaU8 destroyLevel = 0;
    _LinuxCosaInitMemPage(pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { goto labelDestroy; }

    destroyLevel = 1;
    _LinuxCosaInitStrPage(pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { goto labelDestroy; }

    destroyLevel = 2;
    _LinuxCosaInitFilePage(pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { goto labelDestroy; }
    return;

labelDestroy:
    switch (destroyLevel) {
        case 2: _LinuxCosaDestroyStrPage(pContext);
        case 1: _LinuxCosaDestroyMemPage(pContext);
        case 0: _LinuxCosaDestroySysInfo(pContext);
    }

/*
//Initialize FilePage:
    testVal = (cosaU64)linuxInfo_RLIMIT.rlim_cur;
    minLV = 0;

    minLV += !!(testVal & 0xFFFFFFFFFFFFFF00); //Is it above 8-Bit?
    minLV += !!(testVal & 0xFFFFFFFFFFFF0000); //Is it above 16-Bit?
    minLV += !!(testVal & 0xFFFFFFFF00000000); //Is it above 32-Bit?
    //If none above succeed, it's minimally a 8-Bit value and hence [minLV] will be 0.
#if (COSA_SYSTEM_IS_STATIC == 1)
    #if (COSA_FILEPAGE_EXPLICIT_RANGE_CHECK == 1)
        //The defined level is not allowed to be less than the maximum.

        //Is the defined level not enough for required level?
        if (definedLV < minLV) {
            cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _DestroyStrPage, pContext);
            cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _DestroyMemPage, pContext);
            cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.sysInfo, _DestroySysInfo, );

            free(pContext->systemMD.pStrPage);
            free(pContext->systemMD.pMemPage);
            free(pContext->systemMD.pSysInfo);
            pContext->systemMD.pStrPage = NULL;
            pContext->systemMD.pMemPage = NULL;
            pContext->systemMD.pSysInfo = NULL;

            pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
            cosaError(pContext, __FILE__, __LINE__);
            return;
        }
    #endif
    pContext->systemMD.dataLevels.levels.filePage = definedLV;
#else
    //This is the first check, so we can guarantee there's no possible overwrite.
    pContext->systemMD.dataLevels.levels.filePage = minLV;
#endif
    cosaSystemLVFunc(minLV, _InitFilePage, pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _DestroyStrPage, pContext);
        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _DestroyMemPage, pContext);
        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.sysInfo, _DestroySysInfo, );
        free(pContext->systemMD.pStrPage);
        free(pContext->systemMD.pMemPage);
        free(pContext->systemMD.pSysInfo);

        pContext->systemMD.pStrPage = NULL;
        pContext->systemMD.pMemPage = NULL;
        pContext->systemMD.pSysInfo = NULL;
        return;
    }
*/
}

cosaCompilifics(INLINE, void linuxCosaDestroyContext(cosaContext *pContext)) {
    _LinuxCosaDestroyFilePage(pContext);
    _LinuxCosaDestroyStrPage(pContext);
    _LinuxCosaDestroyMemPage(pContext);
    _LinuxCosaDestroySysInfo(pContext);
}

#endif