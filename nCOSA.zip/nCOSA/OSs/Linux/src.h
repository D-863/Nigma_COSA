#ifndef NIGMA_COSA_LINUX_SRC_H
#define NIGMA_COSA_LINUX_SRC_H

#include "headers/utilities.h"

//Operations:
cosaCompilifics(INLINE, void linuxCosaMemSet(const void *pAddr, cosaU8 value, cosaUSize size)) {
#if defined(COSA_OPERATIONS_USE_STANDARD)
    (void)memset((void*)pAddr, value, size);
#else
    if (size == 0) { return; }
    cosaU64 *pArr = (cosaU64*)pAddr;

    if (size >= sizeof(cosaU64)) {
        cosaU64 bValue = value;
        bValue |= bValue << 8;
        bValue |= bValue << 16;
        bValue |= bValue << 32;
        while (size >= sizeof(cosaU64)) {
            size -= sizeof(cosaU64);
            (*pArr) = bValue;
            ++pArr;
        }
    }

    cosaU8 *pNArr = (cosaU8*)pArr;
    while (size != 0) {
        (*pNArr) = value;
        ++pNArr;
        --size;
    }
#endif
}

cosaCompilifics(INLINE, void linuxCosaMemCopy(const void *pSrc, const void *pDest, cosaUSize size)) {
#if defined(COSA_OPERATIONS_USE_STANDARD)
    (void)memcpy((void*)pDest, pSrc, size);
#else
    if (size == 0) { return; }

    if (size < 9) {
        register cosaU8 *pA = (cosaU8*)pSrc;
        register cosaU8 *pB = (cosaU8*)pDest;
        const cosaU8 dBits = (8 - (size % 9)) * 8;
        (*pB) = ((*pA) << dBits) >> dBits;
    } else {
        register cosaU64 *pA = (cosaU64*)pSrc;
        register cosaU64 *pB = (cosaU64*)pDest;
        while (size >= sizeof(cosaU64)) {
            size -= sizeof(cosaU64);
            (*pB) = *pA;
            ++pB;
            ++pA;
        }

        register cosaU8 *pNA = (cosaU8*)pA;
        register cosaU8 *pNB = (cosaU8*)pB;
        while (size != 0) {
            (*pNB) = *pNA;
            ++pNB;
            ++pNA;
            --size;
        }
    }
#endif
}

cosaCompilifics(INLINE, void linuxCosaMemSwap(const void *pSrc, const void *pDest, cosaUSize size)) {
    if (size == 0) { return; }

    register cosaU8 *pA = (cosaU8*)pSrc;
    register cosaU8 *pB = (cosaU8*)pDest;
    register cosaU64 C;
    while (size >= sizeof(cosaU64)) {
        size -= sizeof(cosaU64);
        C = *((cosaU64*)pA);
        (*((cosaU64*)pA)) = *((cosaU64*)pB);
        (*((cosaU64*)pB)) = C;
        pA += sizeof(cosaU64);
        pB += sizeof(cosaU64);
    }

    register cosaU8 nC;
    while (size != 0) {
        nC = *pA;
        (*pA) = *pB;
        (*pB) = nC;
        ++pA;
        ++pB;
        --size;
    }
}

//RAM:
cosaCompilifics(INLINE, void *linuxCosaCreateBlock(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    if (ppBAddr != NULL) {
        if ((*ppBAddr) != NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
            cosaError(pContext, __FILE__, __LINE__);
            return NULL;
        }
    }
    const cosaUSize area = count * byteSize;

    // area > PTRDIFF_MAX
    if (cosaCUnlikely((area >> 63) & 0x1)) {
        /*
            Somehow, the program needs more than 8EB(PTRDIFF_MAX / (1024 ^ 6) = 8) of RAM.. <_<'
            And glibc doesn't like that, infact the Kernel itself doesn't like that.
        */
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;;
    }

    //Find a adequate freed block, otherwise get a fresh one.
    cosaBlock *pBlock = NULL;
    cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockFreed_Search, pContext, &pBlock, area);
    if (pBlock != NULL) {
        cosaUSize bArea = pBlock->count * pBlock->byteSize;
        if (bArea > area) {
            void *pNAddr = realloc(pBlock->addr, area);
            if (pNAddr == NULL) {
                cosaErrno(pContext, __FILE__, __LINE__);
                return NULL;;
            }
            pBlock->addr = pNAddr;
        }
    } else {
        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockMD_GetNew, pContext, &pBlock);
        if (pBlock == NULL) { return NULL; }

        //The block is fresh, allocate more ram.
        pBlock->addr = malloc(area);
        if (pBlock->addr == NULL) {
            cosaError(pContext, __FILE__, __LINE__);
            return NULL;;
        }
    }

    //Initialize acquired block for usage.
    pBlock->flags = COSA_MEM_FLAGS_DEFAULT;
    pBlock->byteSize = byteSize;
    pBlock->count = count;

    if (ppBAddr != NULL) { (*ppBAddr) = pBlock; }
    return pBlock->addr;
}

cosaCompilifics(INLINE, void linuxCosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaUSize oldArea = pBAddr->count * pBAddr->byteSize;
    cosaUSize newArea = count * byteSize;
    if (oldArea >= newArea) { return; }

    cosaU8 *pNAddr = realloc(pBAddr->addr, newArea);
    if (pNAddr == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    pBAddr->byteSize = byteSize;
    pBAddr->count = count;
    pBAddr->addr = pNAddr;
}

cosaCompilifics(INLINE, void linuxCosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaUSize oldArea = pBAddr->count * pBAddr->byteSize;
    cosaUSize newArea = count * byteSize;
    if (oldArea <= newArea) { return; }

    cosaU8 *pNAddr = realloc(pBAddr->addr, newArea);
    if (pNAddr == NULL) {
        cosaErrno(pContext, __FILE__, __LINE__);
        return;
    }
    pBAddr->byteSize = byteSize;
    pBAddr->count = count;
    pBAddr->addr = pNAddr;
}

cosaCompilifics(INLINE, void linuxCosaBlockSegment(cosaContext *pContext, cosaBlock *pBSrc, cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size)) {
    cosaUSize srcArea = pBSrc->count * pBSrc->byteSize;
    cosaUSize destArea = pBDest->count * pBDest->byteSize;
    if ((size > srcArea) || (size > destArea)) {
        //The selected area of [size] is beyond either [srcArea] or [destArea].
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((srcOffset > (srcArea - size)) || (destOffset > (destArea - size))) {
        //The offseted area of size by either offset's is beyond the respective area of offet..
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
    linuxCosaMemCopy(
        ((cosaU8*)pBSrc->addr) + srcOffset,
        ((cosaU8*)pBDest->addr) + destOffset,
        size
    );
}

cosaCompilifics(INLINE, void linuxCosaBlockGetMD(cosaContext *pContext, cosaBlock **ppBAddr, void *pAddr)) {
    cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockMD_FindByAddr, pContext, ppBAddr, pAddr);
}

cosaCompilifics(INLINE, void linuxCosaBlockLinkMD(cosaContext *pContext, cosaBlock **ppBAddr)) {
    if (((*ppBAddr)->flags & COSA_MEM_FLAGS_LINKED) == COSA_MEM_FLAGS_LINKED) { return; }
    cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockLink_LinkMD, pContext, ppBAddr);
}

cosaCompilifics(INLINE, void linuxCosaBlockUnlinkMD(cosaContext *pContext, cosaBlock **ppBAddr)) {
    if (((*ppBAddr)->flags & COSA_MEM_FLAGS_LINKED) == 0x00) { return; }
    cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockLink_UnlinkMD, pContext, ppBAddr);
}

cosaCompilifics(INLINE, void linuxCosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr)) {
    if (((*ppBAddr)->flags & COSA_MEM_FLAGS_FREED) == COSA_MEM_FLAGS_FREED) { return; }
    cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockFreed_Add, pContext, ppBAddr);
}

cosaCompilifics(INLINE, void linuxCosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr)) {
    if ((*ppBAddr)->addr == NULL) { return; }
    cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _BlockMD_Destroy, pContext, ppBAddr);
}

//Stacks:
cosaCompilifics(INLINE, void linuxCosaCreateStackSS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaStackMD_SX *pStackMD = linuxCosaCreateBlock(
        pContext, ppBAddr,
        (count * byteSize) + sizeof(cosaStackMD_SX),
        sizeof(cosaU8)
    );
    linuxCosaMemSet(pStackMD, 0x00, sizeof(cosaStackMD_SX));
    pStackMD->type = COSA_STACK_TYPE_SS;
    pStackMD->bSize = byteSize;
}

cosaCompilifics(INLINE, void linuxCosaCreateStackSD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaStackMD_SX *pStackMD = linuxCosaCreateBlock(
        pContext, ppBAddr,
        (count * byteSize) + sizeof(cosaStackMD_SX),
        sizeof(cosaU8)
    );
    linuxCosaMemSet(pStackMD, 0x00, sizeof(cosaStackMD_SX));
    pStackMD->type = COSA_STACK_TYPE_SD;
    pStackMD->bSize = byteSize;
}

cosaCompilifics(INLINE, void linuxCosaCreateStackDS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size)) {
    cosaStackMD_DX *pStackMD = linuxCosaCreateBlock(
        pContext, ppBAddr,
        size + sizeof(cosaStackMD_DX),
        sizeof(cosaU8)
    );
    linuxCosaMemSet(pStackMD, 0x00, sizeof(cosaStackMD_DX));
    pStackMD->type = COSA_STACK_TYPE_DS;
}

cosaCompilifics(INLINE, void linuxCosaCreateStackDD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size)) {
    cosaStackMD_DX *pStackMD = linuxCosaCreateBlock(
        pContext, ppBAddr,
        size + sizeof(cosaStackMD_DX),
        sizeof(cosaU8)
    );
    linuxCosaMemSet(pStackMD, 0x00, sizeof(cosaStackMD_DX));
    pStackMD->type = COSA_STACK_TYPE_DD;
}

cosaCompilifics(INLINE, void linuxCosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, void *pItem)) {
    cosaStackMD_SX *pStackMD = cosaStackMD(pStack, S);

    cosaUSize offset = pStackMD->top * pStackMD->bSize;
    cosaUSize size = pStack->count - sizeof(cosaStackMD_SX);
    if (offset >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_SD: {
                size += (offset - size) + (COSA_STACK_SX_EXPAND * pStackMD->bSize);

                linuxCosaBlockExpand(pContext, pStack, size + sizeof(cosaStackMD_SX), sizeof(cosaU8));
                pStackMD = cosaStackMD(pStack, S);
                break;
            }
            case COSA_STACK_TYPE_SS: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
        }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, S);
    linuxCosaMemCopy(pItem, pMem + offset, pStackMD->bSize);

    ++pStackMD->top;
}

cosaCompilifics(INLINE, void linuxCosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, void *pItem, cosaUSize itemSize)) {
    cosaStackMD_DX *pStackMD = cosaStackMD(pStack, D);

    cosaU32 newTop = pStackMD->top + itemSize + sizeof(itemSize);
    cosaUSize size = pStack->count - sizeof(cosaStackMD_DX);
    if (newTop >= size) {
        switch (pStackMD->type) {
            case COSA_STACK_TYPE_DD: {
                size += newTop - size;
                size += COSA_STACK_DX_EXPAND * COSA_STACK_SX_EXPAND;

                linuxCosaBlockExpand(pContext, pStack, size + sizeof(cosaStackMD_DX), sizeof(cosaU8));
                pStackMD = cosaStackMD(pStack, D);
                break;
            }
            case COSA_STACK_TYPE_DS: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            default: {
                pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
                pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
        }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, D);
    linuxCosaMemCopy(pItem, pMem + pStackMD->top, itemSize);
    linuxCosaMemCopy(&itemSize, pMem + pStackMD->top + itemSize, sizeof(itemSize));

    pStackMD->top = newTop;
}

cosaCompilifics(INLINE, void *linuxCosaStackSXPop(cosaContext *pContext, cosaBlock *pStack)) {
    cosaStackMD_SX *pStackMD = cosaStackMD(pStack, S);

    if (pStackMD->top == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
    --pStackMD->top;

    cosaUSize offset = pStackMD->top * pStackMD->bSize;
    return cosaStackMD_Mem(pStack, S) + offset;
}

cosaCompilifics(INLINE, void *linuxCosaStackDXPop(cosaContext *pContext, cosaBlock *pStack, cosaUSize *pItemSize)) {
    cosaStackMD_DX *pStackMD = cosaStackMD(pStack, D);

    if (pStackMD->top < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
    pStackMD->top -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, D);
    cosaUSize itemSize = *((cosaUSize*)(pMem + pStackMD->top));

    if (pItemSize != NULL) { (*pItemSize) = itemSize; }
    pStackMD->top -= itemSize;

    return pMem + pStackMD->top;
}

//Queues:
cosaCompilifics(INLINE, void linuxCosaCreateQueue(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize)) {
    cosaUSize area = (count * byteSize) + sizeof(cosaQueueMD);
    cosaQueueMD *pQueueMD = linuxCosaCreateBlock(pContext, ppBAddr, area, sizeof(cosaU8));
    linuxCosaMemSet(pQueueMD, 0x00, area);
    pQueueMD->bSize = byteSize;
}

cosaCompilifics(INLINE, void linuxCosaQueueAdd(cosaContext *pContext, cosaBlock *pQueue, void *pItem)) {
    cosaQueueMD *pQueueMD = cosaQueueMD(pQueue);

    cosaUSize size = pQueue->count - sizeof(cosaQueueMD);
    if ((size - (pQueueMD->count * pQueueMD->bSize)) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }

    cosaU8 *pMem = cosaQueueMD_Mem(pQueue);
    linuxCosaMemCopy(pItem, pMem + pQueueMD->back, pQueueMD->bSize);
    pQueueMD->back = (pQueueMD->back + pQueueMD->bSize) % size;

    ++pQueueMD->count;
}

cosaCompilifics(INLINE, void *linuxCosaQueueNext(cosaContext *pContext, cosaBlock *pQueue)) {
    cosaQueueMD *pQueueMD = cosaQueueMD(pQueue);

    cosaUSize size = pQueue->count - sizeof(cosaQueueMD);
    if (pQueueMD->count == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
    cosaU8 *pMem = cosaQueueMD_Mem(pQueue) + pQueueMD->front;
    pQueueMD->front = (pQueueMD->front + pQueueMD->bSize) % size;

    --pQueueMD->count;
    return pMem;
}

//Files:
cosaCompilifics(INLINE, void linuxCosaCreateFile(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaFileOpen(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaFileWrite(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

cosaCompilifics(INLINE, void linuxCosaFileRead(cosaContext *pContext)) {
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    cosaError(pContext, __FILE__, __LINE__);
}

//CosaContext:
cosaCompilifics(INLINE, void linuxCosaInitContext(cosaContext *pContext)) {
    _InitSysInfo(pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    _InitMemPage(pContext);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        free(pContext->systemMD.pSysInfo);

        pContext->systemMD.pSysInfo = NULL;
        return;
    }
}

cosaCompilifics(INLINE, void linuxCosaDestroyContext(cosaContext *pContext)) {
    if (pContext->systemMD.pSysInfo != NULL) {
        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.sysInfo, _DestroySysInfo, );

        free(pContext->systemMD.pSysInfo);
        pContext->systemMD.pSysInfo = NULL;
    }

    if (pContext->systemMD.pMemPage != NULL) {
        cosaSystemLVFunc(pContext->systemMD.dataLevels.levels.memPage, _DestroyMemPage, pContext);

        free(pContext->systemMD.pMemPage);
        pContext->systemMD.pMemPage = NULL;
    }
}

#endif