#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

#include "../headers/utilities.h"

void linuxInitializeCosaMD(cosaContext *pContext, _CosaMD *pCosaMD);
cosaMemBlock *linuxCosaMemoryAlloc(cosaContext *pContext, cosaUSize count, cosaUSize byteSize);
void linuxCosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void *linuxCosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);
cosaMemBlock *linuxCosaCreateStack(cosaContext *pContext);
void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *linuxCosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue);
cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize);
cosaFile *linuxCosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]);
void linuxCosaFileClose(cosaContext *pContext, cosaFile *pFile);
cosaPanel *linuxCosaCreatePanel(
    cosaContext *pContext,
    cosaU8 type,
    cosaI32 posX,
    cosaI32 posY,
    cosaU32 sizeX,
    cosaU32 sizeY,
    cosaU8 borderWidth,
    cosaU32 panelColor,
    cosaU32 borderColor,
    cosaChar *pTitle);
void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);

#endif