#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

#include "../headers/utilities.h"

void linuxInitializeCosaMD(cosaContext *pContext, _CosaMD *pCosaMD);
cosaMemBlock *linuxCosaMemoryAlloc(cosaContext *pContext, cosaUSize count, cosaUSize byteSize);
void linuxCosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void *linuxCosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);
cosaMemBlock *linuxCosaCreateStack(cosaContext *pContext);
void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *linuxCosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue);
cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize);
cosaFile *linuxCosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]);
void linuxCosaFileClose(cosaContext *pContext, cosaFile *pFile);
//void linuxCosaOpenQOI(cosaContext *pContext, cosaChar filePath[]);
void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]);
void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage);

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);
#endif

#endif