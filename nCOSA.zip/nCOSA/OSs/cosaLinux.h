#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

#include "../headers/utilities.h"

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize);
void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize);
void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock);

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem);
void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem);
void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);

void *linuxCosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);
void *linuxCosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);
void *linuxCosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);
void *linuxCosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);

cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize);
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize);
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size);
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size);

void linuxCosaStackSSRemove(cosaContext *pContext, cosaMemBlock *pStack, cosaU32 itemIndex);

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue);

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaU32 count, cosaU32 byteSize);

cosaFile *linuxCosaOpenFile(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]);
void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]);

void linuxCosaCloseFile(cosaContext *pContext, cosaFile *pFile);
void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage);

void linuxCosaInitContext(cosaContext *pContext);
void linuxCosaDestroyContext(cosaContext *pContext);

#if defined(COSA_ENABLE_EXTENSIONS)
    void linuxCosaInitExtensions(cosaContext *pContext);
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    void linuxCosaPanelUpdateMousePosInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_POS);
    void linuxCosaPanelUpdateMouseKeyInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_KEY);
    void linuxCosaPanelUpdateKeyboardInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_KEYBOARD);
    void linuxCosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);
#endif

#endif