#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

#include "../headers/utilities.h"

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize);
void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize);
void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock);

void linuxCosaStackXSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem);
void linuxCosaStackXDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void linuxCosaStackXBPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemCount);

void *linuxCosaStackXSPop(cosaContext *pContext, cosaMemBlock *pStack);
void *linuxCosaStackXDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);
void *linuxCosaStackXBPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);

void linuxCosaCreateStackSS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize);
void linuxCosaCreateStackDS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize);
void linuxCosaCreateStackSD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size);
void linuxCosaCreateStackDD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size);
void linuxCosaCreateStackSB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes);
void linuxCosaCreateStackDB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes);

void linuxCosaStackSSRemove(cosaContext *pContext, cosaMemBlock *pStack, cosaU32 itemIndex);

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue);

void linuxCosaCreateQueue(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize);

cosaFile *linuxCosaOpenFile(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]);
void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]);

void linuxCosaCloseFile(cosaContext *pContext, cosaFile *pFile);
void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage);

void linuxCosaInitContext(cosaContext *pContext);
void linuxCosaDestroyContext(cosaContext *pContext);

#if defined(COSA_ENABLE_EXTENSIONS)
    void linuxCosaInitExtensions(cosaContext *pContext);
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    void linuxCosaPanelUpdateMousePosInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_POS);
    void linuxCosaPanelUpdateMouseKeyInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_KEY);
    void linuxCosaPanelUpdateKeyboardInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_KEYBOARD);
    void linuxCosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel);
    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);
#endif

#endif