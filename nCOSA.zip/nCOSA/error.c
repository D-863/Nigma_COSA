#include "headers/error.h"

/*COSA: {
        File<__FILE__>
        Line<__LINE__>
        ERROR: {
            num<COSA_CONTEXT_ERRN_*>
            str<COSA_CONTEXT_ERRS_*>
        }
}*/

/*
static void _FindErrorMSG(cosaContext *pContext, cosaChar **ppErrorMSG) {
    switch (pContext->errorNUM) {
        case COSA_CONTEXT_SUCCESS_NUM: {
            (*ppErrorMSG) = COSA_CONTEXT_SUCCESS_MSG;
            break;
        }
        case COSA_CONTEXT_ERRN_OPNP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_OPNP;
            break;
        }
        case COSA_CONTEXT_ERRN_INVPATH: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVPATH;
            break;
        }
        case COSA_CONTEXT_ERRN_NOPR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOPR;
            break;
        }
        case COSA_CONTEXT_ERRN_IO: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_IO;
            break;
        }
        case COSA_CONTEXT_ERRN_NOADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_TOMARGS: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_TOMARGS;
            break;
        }
        case COSA_CONTEXT_ERRN_OOM: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_OOM;
            break;
        }
        case COSA_CONTEXT_ERRN_DEALLOC: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_DEALLOC;
            break;
        }
        case COSA_CONTEXT_ERRN_OOP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_OOP;
            break;
        }
        case COSA_CONTEXT_ERRN_PUNMAP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_PUNMAP;
            break;
        }
        case COSA_CONTEXT_ERRN_DPERM: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_DPERM;
            break;
        }
        case COSA_CONTEXT_ERRN_BUSYDEV: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BUSYDEV;
            break;
        }
        case COSA_CONTEXT_ERRN_NODEV: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NODEV;
            break;
        }
        case COSA_CONTEXT_ERRN_INVDIR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVDIR;
            break;
        }
        case COSA_CONTEXT_ERRN_INVARG: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVARG;
            break;
        }
        case COSA_CONTEXT_ERRN_INPCIOFDEV: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INPCIOFDEV;
            break;
        }
        case COSA_CONTEXT_ERRN_BUSYFILE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BUSYFILE;
            break;
        }
        case COSA_CONTEXT_ERRN_TOLFILE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_TOLFILE;
            break;
        }
        case COSA_CONTEXT_ERRN_TOMFILE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_TOMFILE;
            break;
        }
        case COSA_CONTEXT_ERRN_NODEVSP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NODEVSP;
            break;
        }
        case COSA_CONTEXT_ERRN_ROADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_ROADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_WOADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_WOADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_BPIPE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BPIPE;
            break;
        }
        case COSA_CONTEXT_ERRN_ARGOORNE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_ARGOORNE;
            break;
        }
        case COSA_CONTEXT_ERRN_RESOORNE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_RESOORNE;
            break;
        }
        case COSA_CONTEXT_ERRN_TOLFILEN: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_TOLFILEN;
            break;
        }
        case COSA_CONTEXT_ERRN_INVFUNC: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVFUNC;
            break;
        }
        case COSA_CONTEXT_ERRN_PTCDVNTATTCH: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_PTCDVNTATTCH;
            break;
        }
        case COSA_CONTEXT_ERRN_INVSLT: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVSLT;
            break;
        }
        case COSA_CONTEXT_ERRN_BFONTF: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BFONTF;
            break;
        }
        case COSA_CONTEXT_ERRN_INVDEV: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVDEV;
            break;
        }
        case COSA_CONTEXT_ERRN_NONET: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NONET;
            break;
        }
        case COSA_CONTEXT_ERRN_NOPKG: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOPKG;
            break;
        }
        case COSA_CONTEXT_ERRN_SCOM: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_SCOM;
            break;
        }
        case COSA_CONTEXT_ERRN_PTC: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_PTC;
            break;
        }
        case COSA_CONTEXT_ERRN_BMSG: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BMSG;
            break;
        }
        case COSA_CONTEXT_ERRN_VALOVFLW: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_VALOVFLW;
            break;
        }
        case COSA_CONTEXT_ERRN_NOUQNETNM: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOUQNETNM;
            break;
        }
        case COSA_CONTEXT_ERRN_BFDS: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BFDS;
            break;
        }
        case COSA_CONTEXT_ERRN_CRTEADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_CRTEADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_LIBACC: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_LIBACC;
            break;
        }
        case COSA_CONTEXT_ERRN_LIBBAD: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_LIBBAD;
            break;
        }
        case COSA_CONTEXT_ERRN_LIBSCN: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_LIBSCN;
            break;
        }
        case COSA_CONTEXT_ERRN_LIBMAX: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_LIBMAX;
            break;
        }
        case COSA_CONTEXT_ERRN_LIBEXE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_LIBEXE;
            break;
        }
        case COSA_CONTEXT_ERRN_INVWCHR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVWCHR;
            break;
        }
        case COSA_CONTEXT_ERRN_INTRRST: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INTRRST;
            break;
        }
        case COSA_CONTEXT_ERRN_STRPIP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_STRPIP;
            break;
        }
        case COSA_CONTEXT_ERRN_INVSOCK: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVSOCK;
            break;
        }
        case COSA_CONTEXT_ERRN_RQDSTADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_RQDSTADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_TOLMSG: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_TOLMSG;
            break;
        }
        case COSA_CONTEXT_ERRN_INVPTCTSOCK: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVPTCTSOCK;
            break;
        }
        case COSA_CONTEXT_ERRN_NOPTCAVL: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOPTCAVL;
            break;
        }
        case COSA_CONTEXT_ERRN_NOPTCSUP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOPTCSUP;
            break;
        }
        case COSA_CONTEXT_ERRN_NOSOCKTSUP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOSOCKTSUP;
            break;
        }
        case COSA_CONTEXT_ERRN_NOOPSUP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOOPSUP;
            break;
        }
        case COSA_CONTEXT_ERRN_NOPTCFSUP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOPTCFSUP;
            break;
        }
        case COSA_CONTEXT_ERRN_PTCNOADDRFSUP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_PTCNOADDRFSUP;
            break;
        }
        case COSA_CONTEXT_ERRN_BUSYADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BUSYADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_RQADDR: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_RQADDR;
            break;
        }
        case COSA_CONTEXT_ERRN_NETDWN: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NETDWN;
            break;
        }
        case COSA_CONTEXT_ERRN_NETURCH: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NETURCH;
            break;
        }
        case COSA_CONTEXT_ERRN_NETDCONRST: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NETDCONRST;
            break;
        }
        case COSA_CONTEXT_ERRN_CONABT: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_CONABT;
            break;
        }
        case COSA_CONTEXT_ERRN_CONRST: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_CONRST;
            break;
        }
        case COSA_CONTEXT_ERRN_OOBSP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_OOBSP;
            break;
        }
        case COSA_CONTEXT_ERRN_CONTMO: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_CONTMO;
            break;
        }
        case COSA_CONTEXT_ERRN_CONREF: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_CONREF;
            break;
        }
        case COSA_CONTEXT_ERRN_HSTDWN: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_HSTDWN;
            break;
        }
        case COSA_CONTEXT_ERRN_NORTHST: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NORTHST;
            break;
        }
        case COSA_CONTEXT_ERRN_BUSYOP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_BUSYOP;
            break;
        }
        case COSA_CONTEXT_ERRN_OPINPROG: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_OPINPROG;
            break;
        }
        case COSA_CONTEXT_ERRN_SLFILE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_SLFILE;
            break;
        }
        case COSA_CONTEXT_ERRN_STCTCL: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_STCTCL;
            break;
        }
        case COSA_CONTEXT_ERRN_RTEIO: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_RTEIO;
            break;
        }
        case COSA_CONTEXT_ERRN_DSKQA: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_DSKQA;
            break;
        }
        case COSA_CONTEXT_ERRN_NOMDIM: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NOMDIM;
            break;
        }
        case COSA_CONTEXT_ERRN_INVMDIMT: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_INVMDIMT;
            break;
        }
        case COSA_CONTEXT_ERRN_OPCLC: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_OPCLC;
            break;
        }
        case COSA_CONTEXT_ERRN_NORQKEY: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NORQKEY;
            break;
        }
        case COSA_CONTEXT_ERRN_KEYEXP: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_KEYEXP;
            break;
        }
        case COSA_CONTEXT_ERRN_KEYRVK: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_KEYRVK;
            break;
        }
        case COSA_CONTEXT_ERRN_KEYRJC: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_KEYRJC;
            break;
        }
        case COSA_CONTEXT_ERRN_NORECVRBLESTE: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NORECVRBLESTE;
            break;
        }
        case COSA_CONTEXT_ERRN_MEMPGHW: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_MEMPGHW;
            break;
        }
        case COSA_CONTEXT_ERRN_NODATA: {
            (*ppErrorMSG) = COSA_CONTEXT_ERRS_NODATA;
            break;
        }
    }
}
*/

static void _CreateErrorData(cosaContext *pContext, const cosaChar filePath[], const cosaS32 codeLine) {
    //Recipe:
    cosaUSize msgLength = strlen(COSA_ERROR_MSG);
    cosaUSize pathLength = strlen(filePath);
    msgLength += pathLength;

    /*
        11 = numPosCount((2 ^ 32) - 1) + 1(For the "\0").
             [----10----]
             "4294967295"
    */
    cosaChar lineNumStr[11] = {0};
    (void)snprintf(lineNumStr,  11 * sizeof(cosaChar), "%u", ((cosaU32)cosaStoU(codeLine)));
    cosaUSize lineNumLength = strlen(lineNumStr);
    msgLength += lineNumLength;

    //The same as [11], but (2 ^ 8) - 1.
    cosaChar errNumStr[4] = {0};
    (void)snprintf(errNumStr,  4 * sizeof(cosaChar), "%u", pContext->errorNUM);
    cosaUSize errNumLength = strlen(errNumStr);
    cosaUSize errMsgLength = strlen(pContext->errorMSG);
    msgLength += errNumLength + errMsgLength;


    //Baking:
    /*
        n = \n
        t = \t
        [------14------]
         COSA: {ntFile<
        [----8---]
         >ntLine<
        [--------18--------]
         >ntERROR: {nttnum<
        [----8---]
         >nttstr<
        [----7--]
         >nt}n}n
    */
    ++msgLength; //A extra for the "\0".
    cosaChar *pMSG = malloc(msgLength * sizeof(cosaChar));

    (void)memcpy(pMSG, ((cosaChar*)COSA_ERROR_MSG), 14 * sizeof(cosaChar));
    cosaUSize offset = 14;

    (void)memcpy(pMSG + offset, filePath, pathLength * sizeof(cosaChar));
    offset += pathLength;

    (void)memcpy(pMSG + offset, &((cosaChar*)COSA_ERROR_MSG)[14], 8 * sizeof(cosaChar));
    offset += 8;

    (void)memcpy(pMSG + offset, lineNumStr, lineNumLength * sizeof(cosaChar));
    offset += lineNumLength;

    (void)memcpy(pMSG + offset, &((cosaChar*)COSA_ERROR_MSG)[22], 18 * sizeof(cosaChar));
    offset += 18;

    (void)memcpy(pMSG + offset, errNumStr, errNumLength * sizeof(cosaChar));
    offset += errNumLength;

    (void)memcpy(pMSG + offset, &((cosaChar*)COSA_ERROR_MSG)[40], 8 * sizeof(cosaChar));
    offset += 8;

    (void)memcpy(pMSG + offset, pContext->errorMSG, errMsgLength * sizeof(cosaChar));
    offset += errMsgLength;

    //7 + 1(For the "\0", allocated from above).
    (void)memcpy(pMSG + offset, &((cosaChar*)COSA_ERROR_MSG)[48], 8 * sizeof(cosaChar));

    pContext->errorMSG = pMSG;
}

void cosaError(cosaContext *pContext, const cosaChar filePath[], const cosaS32 codeLine) {
    _CreateErrorData(pContext, filePath, codeLine);
    if (pContext->errorFUNC != NULL) { (*pContext->errorFUNC)(pContext->errorMSG, &pContext->systemMD, pContext->errorNUM, filePath, codeLine); }
    if (pContext->errorMSG != NULL) {
        free(pContext->errorMSG);
        pContext->errorMSG = NULL;
    }
}

void cosaErrno(cosaContext *pContext, const cosaChar filePath[], const cosaS32 codeLine) {
    cosaError(pContext, filePath, codeLine);
}
