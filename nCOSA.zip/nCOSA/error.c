#include "headers/error.h"

void _SetContextERRResult(cosaContext *pContext, const cosaChar filePath[], cosaI32 line) {
    cosaI32 errorNum = errno;
    pContext->errorNUM = COSA_MACRO_SIGNED_TO_UNSIGNED(errorNum);
    cosaU32 lineNum = COSA_MACRO_SIGNED_TO_UNSIGNED(line);

    cosaChar *errorStr = strerror(pContext->errorNUM);
    cosaChar resultStrTemp[] = "COSA: {\n\tFile<>\n\tLine<>\n\tERROR: {\n\t\tnum<>\n\t\tstr<>\n\t}\n}\n";
    cosaChar errorNumStr[11] = {0};
    cosaChar lineNumStr[11]  = {0};
    (void)snprintf(errorNumStr, 11 * sizeof(cosaChar), "%u", pContext->errorNUM);
    (void)snprintf(lineNumStr,  11 * sizeof(cosaChar), "%u", lineNum);

    cosaUSize lengthResultStrTemp = strlen(resultStrTemp);
    cosaUSize lengthFilePath      = strlen(filePath);
    cosaUSize lengthErrorStr      = strlen(errorStr);
    cosaUSize lengthErrorNumStr   = strlen(errorNumStr);
    cosaUSize lengthLineNumStr    = strlen(lineNumStr);
    #if defined(COSA_OS_LINUX)
        pContext->errorMSG = mmap(
            NULL,
            lengthResultStrTemp + lengthFilePath + lengthErrorStr,
            COSA_MEM_PROT_RD | COSA_MEM_PROT_WE,
            COSA_MEM_FLAG_PVE | COSA_MEM_FLAG_ANON,
            -1, 0);
    #endif
    if (pContext->errorMSG == COSA_MEM_FAILURE) {
        pContext->errorMSG = "COSA: Could not generate errorMSG!\n";
        cosaPrint(pContext->errorMSG);
        return;
    }
    (void)memset(pContext->errorMSG, '\0', lengthResultStrTemp + lengthFilePath + lengthErrorStr);

    cosaUSize offsetDest = 0;
    cosaUSize offsetSrc = 0;
    (void)memcpy(pContext->errorMSG, resultStrTemp, 14 * sizeof(cosaChar));
    offsetSrc  += 14;
    offsetDest += 14;
    (void)memcpy(pContext->errorMSG + offsetDest, filePath, lengthFilePath * sizeof(cosaChar));
    offsetDest += lengthFilePath;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    offsetSrc  += 8;
    offsetDest += 8;
    (void)memcpy(pContext->errorMSG + offsetDest, lineNumStr, lengthLineNumStr * sizeof(cosaChar));
    offsetDest += lengthLineNumStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 18 * sizeof(cosaChar));
    offsetSrc  += 18;
    offsetDest += 18;
    (void)memcpy(pContext->errorMSG + offsetDest, errorNumStr, lengthErrorNumStr * sizeof(cosaChar));
    offsetDest += lengthErrorNumStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    offsetSrc  += 8;
    offsetDest += 8;
    (void)memcpy(pContext->errorMSG + offsetDest, errorStr, lengthErrorStr * sizeof(cosaChar));
    offsetDest += lengthErrorStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    /*COSA: {
          File<__FILE__>
          Line<__LINE__>
          ERROR: {
              num<errno>
              str<strerror(errno)>
          }
      }*/
}

void _RunContextDiagnosis(cosaContext *pContext, const cosaChar filePath[], cosaBool showAddrs) {
    FILE *pFile = fopen(filePath, "w");
    if (pFile == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        cosaPrintF("pContext->errorNUM<%u>\n", pContext->errorNUM);
        cosaPrint(pContext->errorMSG);
        assert(pContext == COSA_CONTEXT_SUCCESS_NUM);
    }

    if (showAddrs == cosaBTrue) {
        fprintf(pFile, "pContext->blockPage: {\n");
        fprintf(pFile, "\t<%p>.count<%lu>\n", (void*)&pContext->blockPage.count, pContext->blockPage.count);
        fprintf(pFile, "\t<%p>.top<%lu>\n", (void*)&pContext->blockPage.top, pContext->blockPage.top);
        fprintf(pFile, "\t<%p>.pBlocks<%p> {\n", (void*)&pContext->blockPage.pBlocks, (void*)pContext->blockPage.pBlocks);
        if (pContext->blockPage.pBlocks != NULL) {
            for (cosaUSize i = 0; i < pContext->blockPage.count; i++) {
                fprintf(pFile, "\t\t.pBlocks[%lu]<%p>{\n", i, (void*)&pContext->blockPage.pBlocks[i]);
                fprintf(pFile,
                    "\t\t\t<%p>.flags<%u%u%u%u%u%u%u%u><%s>\n", (void*)&pContext->blockPage.pBlocks[i].flags,
                    (pContext->blockPage.pBlocks[i].flags >> 7) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 6) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 5) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 4) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 3) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 2) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 1) & 0x01,
                    pContext->blockPage.pBlocks[i].flags & 0x01,
                    (cosaRB(pContext->blockPage.pBlocks[i].flags) == COSA_MEM_FLAG_IS_FREE) ? "FREE" : "INUSE"
                );
                fprintf(pFile, "\t\t\t<%p>.byteSize<%lu>\n", (void*)&pContext->blockPage.pBlocks[i].byteSize, pContext->blockPage.pBlocks[i].byteSize);
                fprintf(pFile, "\t\t\t<%p>.count<%lu>\n", (void*)&pContext->blockPage.pBlocks[i].count, pContext->blockPage.pBlocks[i].count);
                fprintf(pFile, "\t\t\t<%p>.addr<%p>\n", (void*)&pContext->blockPage.pBlocks[i].addr, (void*)pContext->blockPage.pBlocks[i].addr);
                fprintf(pFile, "\t\t}\n");
            }
        }
        fprintf(pFile, "\t}\n");
        fprintf(pFile, "}\n");

        fprintf(pFile, "pContext->memPage: {\n");
        fprintf(pFile, "\t<%p>.size<%lu>\n", (void*)&pContext->memPage.size, pContext->memPage.size);
        fprintf(pFile, "\t<%p>.top<%lu>\n", (void*)&pContext->memPage.top, pContext->memPage.top);
        fprintf(pFile, "\t<%p>.pMem<%p> {\n", (void*)&pContext->memPage.pMem, (void*)pContext->memPage.pMem);
        if (pContext->blockPage.pBlocks != NULL) {
            for (cosaUSize i = 0; i < pContext->memPage.size; i++) {
                fprintf(pFile, "\t\t[%lu]<%p>|", i, (void*)&pContext->memPage.pMem[i]);
                fprintf(pFile, 
                    "%u%u%u%u%u%u%u%u|\n",
                    (pContext->memPage.pMem[i] >> 7) & 0x01,
                    (pContext->memPage.pMem[i] >> 6) & 0x01,
                    (pContext->memPage.pMem[i] >> 5) & 0x01,
                    (pContext->memPage.pMem[i] >> 4) & 0x01,
                    (pContext->memPage.pMem[i] >> 3) & 0x01,
                    (pContext->memPage.pMem[i] >> 2) & 0x01,
                    (pContext->memPage.pMem[i] >> 1) & 0x01,
                    pContext->memPage.pMem[i] & 0x01
                );
            }
        }
    } else {
        fprintf(pFile, "pContext->blockPage: {\n");
        fprintf(pFile, "\t<None>.count<%lu>\n", pContext->blockPage.count);
        fprintf(pFile, "\t<None>.top<%lu>\n", pContext->blockPage.top);
        fprintf(pFile, "\t<None>.pBlocks<None> {\n");
        if (pContext->blockPage.pBlocks != NULL) {
            for (cosaUSize i = 0; i < pContext->blockPage.count; i++) {
                fprintf(pFile, "\t\t.pBlocks[%lu]<None>{\n", i);
                fprintf(pFile,
                    "\t\t\t<None>.flags<%u%u%u%u%u%u%u%u><%s>\n",
                    (pContext->blockPage.pBlocks[i].flags >> 7) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 6) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 5) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 4) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 3) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 2) & 0x01,
                    (pContext->blockPage.pBlocks[i].flags >> 1) & 0x01,
                    pContext->blockPage.pBlocks[i].flags & 0x01,
                    (cosaRB(pContext->blockPage.pBlocks[i].flags) == COSA_MEM_FLAG_IS_FREE) ? "FREE" : "INUSE"
                );
                fprintf(pFile, "\t\t\t<None>.byteSize<%lu>\n", pContext->blockPage.pBlocks[i].byteSize);
                fprintf(pFile, "\t\t\t<None>.count<%lu>\n", pContext->blockPage.pBlocks[i].count);
                fprintf(pFile, "\t\t\t<None>.addr<None>\n");
                fprintf(pFile, "\t\t}\n");
            }
        }
        fprintf(pFile, "\t}\n");
        fprintf(pFile, "}\n");

        fprintf(pFile, "pContext->memPage: {\n");
        fprintf(pFile, "\t<None>.size<%lu>\n", pContext->memPage.size);
        fprintf(pFile, "\t<None>.top<%lu>\n", pContext->memPage.top);
        fprintf(pFile, "\t<None>.pMem<None> {\n");
        if (pContext->blockPage.pBlocks != NULL) {
            for (cosaUSize i = 0; i < pContext->memPage.size; i++) {
                fprintf(pFile, "\t\t[%lu]<None>|", i);
                fprintf(pFile, 
                    "%u%u%u%u%u%u%u%u|\n",
                    (pContext->memPage.pMem[i] >> 7) & 0x01,
                    (pContext->memPage.pMem[i] >> 6) & 0x01,
                    (pContext->memPage.pMem[i] >> 5) & 0x01,
                    (pContext->memPage.pMem[i] >> 4) & 0x01,
                    (pContext->memPage.pMem[i] >> 3) & 0x01,
                    (pContext->memPage.pMem[i] >> 2) & 0x01,
                    (pContext->memPage.pMem[i] >> 1) & 0x01,
                    pContext->memPage.pMem[i] & 0x01
                );
            }
        }
    }
    fprintf(pFile, "\t}\n");
    fprintf(pFile, "}\n");
    fclose(pFile);
}
