#include "headers/error.h"

void _SetContextERRResult(cosaContext *pContext, const cosaChar filePath[], cosaI32 line) {
    cosaI32 errorNum = errno;
    pContext->errorNUM = COSA_MACRO_SIGNED_TO_UNSIGNED(errorNum);
    cosaU32 lineNum = COSA_MACRO_SIGNED_TO_UNSIGNED(line);

    cosaChar *errorStr = strerror(pContext->errorNUM);
    cosaChar resultStrTemp[] = "COSA: {\n\tFile<>\n\tLine<>\n\tERROR: {\n\t\tnum<>\n\t\tstr<>\n\t}\n}\n";
    cosaChar errorNumStr[11] = {0};
    cosaChar lineNumStr[11]  = {0};
    (void)snprintf(errorNumStr, 11 * sizeof(cosaChar), "%u", pContext->errorNUM);
    (void)snprintf(lineNumStr,  11 * sizeof(cosaChar), "%u", lineNum);

    cosaUSize lengthResultStrTemp = strlen(resultStrTemp);
    cosaUSize lengthFilePath      = strlen(filePath);
    cosaUSize lengthErrorStr      = strlen(errorStr);
    cosaUSize lengthErrorNumStr   = strlen(errorNumStr);
    cosaUSize lengthLineNumStr    = strlen(lineNumStr);
    pContext->errorMSG = malloc(lengthResultStrTemp + lengthFilePath + lengthErrorStr);
    if (pContext->errorMSG == NULL) {
        pContext->errorMSG = "COSA: Could not allocate heap memory for errorMSG!\n";
        cosaPrint(pContext->errorMSG);
        return;
    }
    (void)memset(pContext->errorMSG, '\0', lengthResultStrTemp + lengthFilePath + lengthErrorStr);

    cosaUSize offsetDest = 0;
    cosaUSize offsetSrc = 0;
    (void)memcpy(pContext->errorMSG, resultStrTemp, 14 * sizeof(cosaChar));
    offsetSrc  += 14;
    offsetDest += 14;
    (void)memcpy(pContext->errorMSG + offsetDest, filePath, lengthFilePath * sizeof(cosaChar));
    offsetDest += lengthFilePath;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    offsetSrc  += 8;
    offsetDest += 8;
    (void)memcpy(pContext->errorMSG + offsetDest, lineNumStr, lengthLineNumStr * sizeof(cosaChar));
    offsetDest += lengthLineNumStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 18 * sizeof(cosaChar));
    offsetSrc  += 18;
    offsetDest += 18;
    (void)memcpy(pContext->errorMSG + offsetDest, errorNumStr, lengthErrorNumStr * sizeof(cosaChar));
    offsetDest += lengthErrorNumStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    offsetSrc  += 8;
    offsetDest += 8;
    (void)memcpy(pContext->errorMSG + offsetDest, errorStr, lengthErrorStr * sizeof(cosaChar));
    offsetDest += lengthErrorStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    /*COSA: {
          File<__FILE__>
          Line<__LINE__>
          ERROR: {
              num<errno>
              str<strerror(errno)>
          }
      }*/
}

void _TakeAContextSnapshot(cosaContext *pContext, FILE *pFile) {
    fprintf(pFile, "pContext->errorNUM<%u>\n", pContext->errorNUM);
    fprintf(pFile, "pContext->errorMSG<%s>\n", pContext->errorMSG);
    fprintf(pFile, "pContext->blockPage {\n");
    fprintf(pFile, "pContext->blockPage.freedCount<%lu>\n", pContext->blockPage.freedCount);
    fprintf(pFile, "pContext->blockPage.blockCount<%lu>\n", pContext->blockPage.blockCount);
    fprintf(pFile, "pContext->blockPage.linkCount<%lu>\n", pContext->blockPage.linkCount);
    fprintf(pFile, "pContext->blockPage.freedTop<%lu>\n", pContext->blockPage.freedTop);
    fprintf(pFile, "pContext->blockPage.blockTop<%lu>\n", pContext->blockPage.blockTop);
    fprintf(pFile, "pContext->blockPage.linkTop<%lu>\n", pContext->blockPage.linkTop);

    fprintf(pFile, "pContext->blockPage.pFreed<%p> {\n", (void*)pContext->blockPage.pFreed);
    for (cosaUSize i = 0; i < pContext->blockPage.freedCount; ++i) {
        fprintf(pFile, "\t[%lu]<%lu>\n", i, pContext->blockPage.pFreed[i]);
    }
    fprintf(pFile, "}\n");

    fprintf(pFile, "pContext->blockPage.pLinks<%p> {\n", (void*)pContext->blockPage.pLinks);
    for (cosaUSize i = 0; i < pContext->blockPage.linkCount; ++i) {
        fprintf(pFile, "\t[%lu] {\n", i);
        fprintf(pFile, "\t\t.blockSlot<%lu>\n", pContext->blockPage.pLinks[i].blockSlot);
        fprintf(pFile, "\t\t.ppBlockLink<%p> -> <", (void*)pContext->blockPage.pLinks[i].ppBlockLink);
        if (pContext->blockPage.pLinks[i].ppBlockLink == NULL) {
            fprintf(pFile, "NULL>\n");
        } else {
            fprintf(pFile, "%p>\n", (void*)(*pContext->blockPage.pLinks[i].ppBlockLink));
        }
        fprintf(pFile, "\t}\n");
    }
    fprintf(pFile, "}\n");

    fprintf(pFile, "pContext->blockPage.pBlocks<%p> {\n", (void*)pContext->blockPage.pBlocks);
    for (cosaUSize i = 0; i < pContext->blockPage.blockCount; ++i) {
        fprintf(pFile, "\t[%lu] {\n", i);
        fprintf(pFile, "\t\t.flags<%u>\n", pContext->blockPage.pBlocks[i].flags);
        fprintf(pFile, "\t\t.byteSize<%lu>\n", pContext->blockPage.pBlocks[i].byteSize);
        fprintf(pFile, "\t\t.count<%lu>\n", pContext->blockPage.pBlocks[i].count);
        fprintf(pFile, "\t\t.addr<%p> {\n", (void*)pContext->blockPage.pBlocks[i].addr);

        for (cosaUSize j = 0; j < pContext->blockPage.pBlocks[i].count * pContext->blockPage.pBlocks[i].byteSize; ++j) {
            fprintf(pFile, "\t\t\t[%lu]<%u%u%u%u%u%u%u%u>\n", j,
                (pContext->blockPage.pBlocks[i].addr[j] >> 7) & 0x01,
                (pContext->blockPage.pBlocks[i].addr[j] >> 6) & 0x01,
                (pContext->blockPage.pBlocks[i].addr[j] >> 5) & 0x01,
                (pContext->blockPage.pBlocks[i].addr[j] >> 4) & 0x01,
                (pContext->blockPage.pBlocks[i].addr[j] >> 3) & 0x01,
                (pContext->blockPage.pBlocks[i].addr[j] >> 2) & 0x01,
                (pContext->blockPage.pBlocks[i].addr[j] >> 1) & 0x01,
                pContext->blockPage.pBlocks[i].addr[j] & 0x01
            );
        }
        fprintf(pFile, "\t\t}\n\t}\n");
    }
    fprintf(pFile, "}\n");
    fprintf(pFile, "}\n");

    fprintf(pFile, "pContext->filePage {\n");
    fprintf(pFile, "pContext->filePage.count<%u>", pContext->filePage.count);
    fprintf(pFile, "pContext->filePage.pFiles<%p> {", (void*)pContext->filePage.pFiles);
    for (cosaUSize i = 0; i < pContext->filePage.count; ++i) {
        fprintf(pFile, "\t[%lu] {\n", i);
        fprintf(pFile, "\t\t.flags<%u>\n", pContext->filePage.pFiles[i].flags);
        fprintf(pFile, "\t\t.desc<%d>\n", pContext->filePage.pFiles[i].desc);
        fprintf(pFile, "\t\t.info<%p>\n", (void*)&pContext->filePage.pFiles[i].info);
        fprintf(pFile, "\t\t.pMData<%p>\n", (void*)pContext->filePage.pFiles[i].pMData);
        fprintf(pFile, "\t}\n");
    }
    fprintf(pFile, "}\n");
    fprintf(pFile, "}\n");

    fprintf(pFile, "pContext->pCosaMD<%p> {\n", (void*)pContext->pCosaMD);
    fprintf(pFile, "\t.systemInfo {\n");
    fprintf(pFile, "\t\t.isBigEndian<%u>\n", pContext->pCosaMD->systemInfo.isBigEndian);
    fprintf(pFile, "\t\t.maxFDs.rlim_max<%lu>\n", pContext->pCosaMD->systemInfo.maxFDs.rlim_max);
    fprintf(pFile, "\t\t.maxFDs.rlim_cur<%lu>\n", pContext->pCosaMD->systemInfo.maxFDs.rlim_cur);
    fprintf(pFile, "\t}\n");

    fprintf(pFile, "\t.inputMap {\n");
    fprintf(pFile, "\t\t.data<%p> {\n", (void*)pContext->pCosaMD->inputMap.data);
    for (cosaUSize i = 0; i < COSA_INPUTMAP_SIZE; ++i) {
        fprintf(pFile, "\t\t\t[%lu]<%u%u%u%u%u%u%u%u>\n", i,
            (pContext->pCosaMD->inputMap.data[i] >> 7) & 0x01,
            (pContext->pCosaMD->inputMap.data[i] >> 6) & 0x01,
            (pContext->pCosaMD->inputMap.data[i] >> 5) & 0x01,
            (pContext->pCosaMD->inputMap.data[i] >> 4) & 0x01,
            (pContext->pCosaMD->inputMap.data[i] >> 3) & 0x01,
            (pContext->pCosaMD->inputMap.data[i] >> 2) & 0x01,
            (pContext->pCosaMD->inputMap.data[i] >> 1) & 0x01,
            pContext->pCosaMD->inputMap.data[i] & 0x01
        );
    }
    fprintf(pFile, "\t\t}\n\t}\n");
    fprintf(pFile, "}\n");
}
