#include "../include/nCOSA/headers/COSA.h"


_StrPage_LV3 *pDictPage = NULL;

static void errorFUNC(COSA_ERROR_FUNC_ARGS) {
    cosaPrintF("%s", pErrorMSG);
}

static cosaS32 initDictPage(cosaContext *pContext) {
    pDictPage = malloc(sizeof(_StrPage_LV3));
    if (pDictPage == NULL) {
        cosaPrint("initDictPage: MallocA failed.");
        return -1;
    }
    cosaOPSETArea(pContext, pDictPage, 0x00, sizeof(_StrPage_LV3));
    pDictPage->freedCount = COSA_STRPAGE_FREED_COUNT_START;
    pDictPage->dictionariesCount = COSA_STRPAGE_DICTIONARIES_COUNT_START;

    pDictPage->pFreed = malloc(COSA_STRPAGE_FREED_COUNT_START * sizeof(cosaU64));
    if (pDictPage->pFreed == NULL) {
        free(pDictPage);
        pDictPage = NULL;
        cosaPrint("initDictPage: MallocB failed.");
        return -2;
    }

    pDictPage->pDictionaries = malloc(COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));
    if (pDictPage->pDictionaries == NULL) {
        free(pDictPage->pFreed);
        free(pDictPage);
        pDictPage->pFreed = NULL;
        pDictPage = NULL;
        cosaPrint("initDictPage: MallocC failed.");
        return -2;
    }
    cosaOPSETArea(pContext, pDictPage->pFreed, 0x00, COSA_STRPAGE_FREED_COUNT_START * sizeof(cosaU64));
    cosaOPSETArea(pContext, pDictPage->pDictionaries, 0x00, COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));

    return 0;
}

static cosaS32 destDictPage(void) {
    if (pDictPage != NULL) {
        if (pDictPage->pFreed) {
            free(pDictPage->pFreed);
            pDictPage->pFreed = NULL;
        }

        if (pDictPage->pDictionaries) {
            free(pDictPage->pDictionaries);
            pDictPage->pDictionaries = NULL;
        }

        free(pDictPage);
        pDictPage = NULL;
    }
    return 0;
}



static void _CreateDictionary(cosaContext *pContext, cosaU64 *pDictionaryID) {
    if (pDictPage->freedTop > 0) {
        --pDictPage->freedTop;
        (*pDictionaryID) = pDictPage->pFreed[pDictPage->freedTop];
        return;
    }
    (*pDictionaryID) = pDictPage->dictionariesTop;
    ++pDictPage->dictionariesTop;

    if (pDictPage->dictionariesTop >= pDictPage->dictionariesCount) {
        cosaUSize newCount = COSA_STRPAGE_DICTIONARIES_EXPAND(pDictPage->dictionariesCount);

        cosaDictionary *pNDictionarys = realloc(pDictPage->pDictionaries, newCount * sizeof(cosaDictionary));
        if (pNDictionarys == NULL) {
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            cosaError(pContext, __FILE__, __LINE__);
            return;
        }
        cosaOPSETArea(pContext, &pNDictionarys[pDictPage->dictionariesCount], 0x00, (newCount - pDictPage->dictionariesCount) * sizeof(cosaDictionary));
        pDictPage->dictionariesCount = newCount;
        pDictPage->pDictionaries = pNDictionarys;
    }
}

static void _DictionaryAddEntry(cosaContext *pContext, cosaString *pString, const cosaChar *pText, cosaUSize charCount, cosaU64 dictionaryID) {
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("_DestroyDictionary: dictionaryID is beyond pDictPage's allocated space.");
        return;
    }

    cosaDictionary *pDictionary = &pDictPage->pDictionaries[dictionaryID];
    if (pDictionary->pBSectors == NULL) {
        cosaU64 *pSectors = cosaCreateBlock(pContext, &pDictionary->pBSectors, 1, sizeof(cosaU64));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            cosaPrint("_DictionaryAddEntry: Failed to create pDictionary->pBSectors.");
            return;
        }
        pSectors[0] = charCount;
    } else {
        cosaBlockExpand(pContext, pDictionary->pBSectors, pDictionary->pBSectors->count + 1, sizeof(cosaU64));
        cosaU64 *pSectors = pDictionary->pBSectors->addr;
        pSectors[pDictionary->pBSectors->count - 1] = pSectors[pDictionary->pBSectors->count - 2] + charCount;
    }

    if (pDictionary->pBBitData == NULL) {
        (void)cosaCreateBlock(pContext, &pDictionary->pBBitData, charCount, sizeof(cosaChar));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            cosaPrint("_DictionaryAddEntry: Failed to create pDictionary->pBBitData.");

            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            cosaDestroyBlock(pContext, &pDictionary->pBSectors);
            return;
        }
    } else { cosaBlockExpand(pContext, pDictionary->pBBitData, pDictionary->pBBitData->count + charCount, sizeof(cosaChar)); }
    cosaChar *pBitData = pDictionary->pBBitData->addr;
    cosaOPCPYArea(pContext, pText, &pBitData[pDictionary->pBBitData->count - charCount], charCount * sizeof(cosaChar));
    pString->flags = COSA_STRINGS_FLAGS_DEFAULT;
    pString->id = pDictionary->pBSectors->count - 1;
    pString->length = charCount;
}

static void _DictionaryRemoveEntry(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID) {
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("_DictionaryRemoveEntry: dictionaryID is beyond pDictPage's allocated space.");
        return;
    }

    cosaDictionary *pDictionary = &pDictPage->pDictionaries[dictionaryID];
    if ((pDictionary->pBBitData == NULL) || (pDictionary->pBSectors == NULL)) {
        cosaPrint("_DictionaryGetString: The dictionaryID's respective Dictionary does not exist.");
        return;
    }
    //cosaU64 *pSectors = pDictionary->pBSectors->addr;
    //cosaChar *pBitData = pDictionary->pBBitData->addr;
}

static void _DictionaryGetString(cosaContext *pContext, cosaBlock **ppBAddr, const cosaString *pString, cosaU64 dictionaryID) {
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("_DictionaryGetString: dictionaryID is beyond pDictPage's allocated space.");
        return;
    }

    cosaDictionary *pDictionary = &pDictPage->pDictionaries[dictionaryID];
    if ((pDictionary->pBBitData == NULL) || (pDictionary->pBSectors == NULL)) {
        cosaPrint("_DictionaryGetString: The dictionaryID's respective Dictionary does not exist.");
        return;
    }

    cosaChar *pAddr = cosaCreateBlock(pContext, ppBAddr, pString->length, sizeof(cosaChar));
    if (pAddr == NULL) {
        cosaPrint("_DictionaryGetString: Failed to allocate space for text.");
        return;
    }
    cosaU64 *pSectors = pDictionary->pBSectors->addr;
    cosaChar *pBitData = pDictionary->pBBitData->addr;
    cosaOPCPYArea(pContext, &pBitData[pSectors[pString->id] - pString->length], pAddr, pString->length * sizeof(cosaChar));
}

static void _DestroyDictionary(cosaContext *pContext, cosaU64 dictionaryID) {
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("_DestroyDictionary: dictionaryID is beyond pDictPage's allocated space.");
        return;
    }
    cosaDictionary *pDictionary = &pDictPage->pDictionaries[dictionaryID];
    if (pDictionary->pBSectors != NULL) { cosaDestroyBlock(pContext, &pDictionary->pBSectors); }
    if (pDictionary->pBBitData != NULL) { cosaDestroyBlock(pContext, &pDictionary->pBBitData); }

    if (dictionaryID != (pDictPage->dictionariesTop - 1)) {
        pDictPage->pFreed[pDictPage->freedTop] = dictionaryID;
        ++pDictPage->freedTop;

        if (pDictPage->freedTop >= pDictPage->freedCount) {
            cosaUSize newCount = COSA_STRPAGE_FREED_EXPAND(pDictPage->freedCount);

            cosaU64 *pNFreeds = realloc(pDictPage->pFreed, newCount * sizeof(*pDictPage->pFreed));
            if (pNFreeds == NULL) {

                pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
                pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            cosaOPSETArea(pContext, &pNFreeds[pDictPage->freedCount], 0x00, (newCount - pDictPage->freedCount) * sizeof(*pDictPage->pFreed));
            pDictPage->freedCount = newCount;
            pDictPage->pFreed = pNFreeds;
        }
    } else { --pDictPage->dictionariesTop; }
}

int main(void) {
    cosaContext context = {0};
    context.errorFUNC = errorFUNC;
    puts("A");
    if (cosaInitContext(&context) == cosaBFalse) {
        cosaPrint("main: cosaInitContext failed.");
        return 1;
    }
    cosaPrint("main: Cosa success.");

    cosaS32 err = initDictPage(&context);
    if (err != 0) { return err; }
    cosaPrint("main: Success.");

    cosaU64 dictID = 0;
    _CreateDictionary(&context, &dictID);
    cosaPrintF("main: _CreateDictionary.return->dictID<%lu>\n", dictID);

    const cosaChar pText[] = "Hello, String!";
    cosaString s = {0};
    _DictionaryAddEntry(&context, &s, pText, strlen(pText), dictID);

    cosaBlock *pBStr = NULL;
    _DictionaryGetString(&context, &pBStr, &s, dictID);
    cosaPrintF("main: pBStr->addr<%s>\n", (cosaChar*)pBStr->addr);
    cosaDestroyBlock(&context, &pBStr);

    _DictionaryRemoveEntry(&context, &s, dictID);
    _DestroyDictionary(&context, dictID);

    err = destDictPage();
    if (err != 0) { return err; }
    cosaPrint("main: destStr success.");

    if (cosaDestroyContext(&context) == cosaBFalse) {
        cosaPrint("main: cosaDestroyContext failed.");
        return 1;
    }
    return err;
}