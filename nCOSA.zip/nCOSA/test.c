#include "../include/nCOSA/headers/COSA.h"


_StrPage_LV3 *pDictPage = NULL;

static void errorFUNC(COSA_ERROR_FUNC_ARGS) {
    cosaPrintF("%s", pErrorMSG);
}

static cosaS32 initDictPage(cosaContext *pContext) {
    pDictPage = malloc(sizeof(_StrPage_LV3));
    if (pDictPage == NULL) {
        cosaPrint("initDictPage: MallocA failed.");
        return -1;
    }
    cosaOPSETArea(pContext, pDictPage, 0x00, sizeof(_StrPage_LV3));
    pDictPage->freedCount = COSA_STRPAGE_FREED_COUNT_START;
    pDictPage->dictionariesCount = COSA_STRPAGE_DICTIONARIES_COUNT_START;

    pDictPage->pFreed = malloc(COSA_STRPAGE_FREED_COUNT_START * sizeof(cosaU64));
    if (pDictPage->pFreed == NULL) {
        free(pDictPage);
        pDictPage = NULL;
        cosaPrint("initDictPage: MallocB failed.");
        return -2;
    }

    pDictPage->pDictionaries = malloc(COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));
    if (pDictPage->pDictionaries == NULL) {
        free(pDictPage->pFreed);
        free(pDictPage);
        pDictPage->pFreed = NULL;
        pDictPage = NULL;
        cosaPrint("initDictPage: MallocC failed.");
        return -2;
    }
    cosaOPSETArea(pContext, pDictPage->pFreed, 0x00, COSA_STRPAGE_FREED_COUNT_START * sizeof(cosaU64));
    cosaOPSETArea(pContext, pDictPage->pDictionaries, 0x00, COSA_STRPAGE_DICTIONARIES_COUNT_START * sizeof(cosaDictionary));

    return 0;
}

static cosaS32 destDictPage(void) {
    if (pDictPage != NULL) {
        if (pDictPage->pFreed) {
            free(pDictPage->pFreed);
            pDictPage->pFreed = NULL;
        }

        if (pDictPage->pDictionaries) {
            free(pDictPage->pDictionaries);
            pDictPage->pDictionaries = NULL;
        }

        free(pDictPage);
        pDictPage = NULL;
    }
    return 0;
}



static void _CreateDictionary(cosaContext *pContext, cosaU64 *pDictionaryID) {
    //DEF:
    if ((pContext == NULL) || (pDictionaryID == NULL)) {
        cosaPrintF("ERROR _CreateDictionary: %s\n", COSA_CONTEXT_ERRS_NOADDR);
        return;
    }

    //SRC:
    if (pDictPage->freedTop == 0) {
        (*pDictionaryID) = pDictPage->dictionariesTop;
        ++pDictPage->dictionariesTop;

        if (pDictPage->dictionariesTop >= pDictPage->dictionariesCount) {
            cosaUSize newCount = COSA_STRPAGE_DICTIONARIES_EXPAND(pDictPage->dictionariesCount);

            cosaDictionary *pNDictionarys = realloc(pDictPage->pDictionaries, newCount * sizeof(cosaDictionary));
            if (pNDictionarys == NULL) {
                pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
                pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            cosaOPSETArea(pContext, &pNDictionarys[pDictPage->dictionariesCount], 0x00, (newCount - pDictPage->dictionariesCount) * sizeof(cosaDictionary));
            pDictPage->dictionariesCount = newCount;
            pDictPage->pDictionaries = pNDictionarys;
        }
    } else {
        --pDictPage->freedTop;
        (*pDictionaryID) = pDictPage->pFreed[pDictPage->freedTop];
    }
}

static void _DictionaryAddEntry(cosaContext *pContext, cosaString *pString, const cosaChar *pText, cosaUSize charCount, cosaU64 dictionaryID) {
    //DEF:
    if ((pContext == NULL) || (pString == NULL) || (pText == NULL)) {
        cosaPrintF("ERROR _DictionaryAddEntry: %s\n", COSA_CONTEXT_ERRS_NOADDR);
        return;
    } else if (charCount == 0) {
        cosaPrintF("ERROR _DictionaryAddEntry: %s\n", COSA_CONTEXT_ERRS_ARGOORNE);
        return;
    }

    //SRC:
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("ERROR _DictionaryAddEntry: dictionaryID is beyond pDictPage's allocated space.");
        return;
    }

    cosaDictionary *pDict = &pDictPage->pDictionaries[dictionaryID];
    cosaU64 *pSectors = NULL;
    cosaChar *pBitData = NULL;
    if (pDict->pBSectors == NULL) {
        pSectors = cosaCreateBlock(pContext, &pDict->pBSectors, 1, sizeof(cosaU64));
        if (pSectors == NULL) {
            cosaPrint("ERROR _DictionaryAddEntry: Failed to create space for Sectors.");
            return;
        }
        pSectors[0] = charCount;
    } else {
        cosaBlockExpand(pContext, pDict->pBSectors, pDict->pBSectors->count + 1, sizeof(cosaU64));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            cosaPrint("ERROR _DictionaryAddEntry: Failed to expand Sectors.");
            return;
        }
        pSectors = pDict->pBSectors->addr;
        pSectors[pDict->pBSectors->count - 1] = pSectors[pDict->pBSectors->count - 2] + charCount;
    }
    if (pDict->pBBitData == NULL) {
        pBitData = cosaCreateBlock(pContext, &pDict->pBBitData, charCount, sizeof(cosaChar));
        if (pBitData == NULL) {
            cosaPrint("ERROR _DictionaryAddEntry: Failed to create space for BitData.");
            return;
        }
    } else {
        cosaBlockExpand(pContext, pDict->pBBitData, pDict->pBBitData->count + charCount, sizeof(cosaChar));
        pBitData = pDict->pBBitData->addr;
    }
    cosaOPCPYArea(pContext, pText, &pBitData[pSectors[pDict->pBSectors->count - 2]], charCount);
}

static void _DictionaryRemoveEntry(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID) {
    //DEF:
    if ((pContext == NULL) || (pString == NULL)) {
        cosaPrintF("ERROR _DictionaryRemoveEntry: %s\n", COSA_CONTEXT_ERRS_NOADDR);
        return;
    }

    //SRC:
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("ERROR _DictionaryRemoveEntry: This dictionaryID is beyond pDictPage's allocated space.");
        return;
    }

    cosaDictionary *pDict = &pDictPage->pDictionaries[dictionaryID];
    if (pDict->pBSectors == NULL) {
        cosaPrint("ERROR: This dictionaryID has no entry.");
        return;
    } else if (pString->id >= pDict->pBSectors->count) {
        cosaPrint("ERROR: The provided entry of string does not exist.");
        return;
    }

    cosaU64 *pSectors = pDict->pBSectors->addr;
}

static void _DictionaryGetString(cosaContext *pContext, cosaBlock **ppBAddr, const cosaString *pString, cosaU64 dictionaryID) {
    //DEF:
    if ((pContext == NULL) || (ppBAddr == NULL) || (pString == NULL)) {
        cosaPrintF("ERROR _DictionaryGetString: %s\n", COSA_CONTEXT_ERRS_NOADDR);
        return;
    }

    //SRC:
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("ERROR _DictionaryGetString: This dictionaryID is beyond pDictPage's allocated space.");
        return;
    }
    cosaDictionary *pDict = &pDictPage->pDictionaries[dictionaryID];
}

static void _DestroyDictionary(cosaContext *pContext, cosaU64 dictionaryID) {
    //DEF:
    if (pContext == NULL) {
        cosaPrintF("ERROR _DestroyDictionary: %s\n", COSA_CONTEXT_ERRS_NOADDR);
        return;
    }

    //SRC:
    if (dictionaryID >= pDictPage->dictionariesTop) {
        cosaPrint("ERROR _DestroyDictionary: dictionaryID is beyond pDictPage's allocated space.");
        return;
    }
    cosaDictionary *pDict = &pDictPage->pDictionaries[dictionaryID];
    if (pDict->pBSectors != NULL) { cosaDestroyBlock(pContext, &pDict->pBSectors); }
    if (pDict->pBBitData != NULL) { cosaDestroyBlock(pContext, &pDict->pBBitData); }

    if (dictionaryID != (pDictPage->dictionariesTop - 1)) {
        pDictPage->pFreed[pDictPage->freedTop] = dictionaryID;
        ++pDictPage->freedTop;

        if (pDictPage->freedTop >= pDictPage->freedCount) {
            cosaUSize newCount = COSA_STRPAGE_FREED_EXPAND(pDictPage->freedCount);

            cosaU64 *pNFreeds = realloc(pDictPage->pFreed, newCount * sizeof(*pDictPage->pFreed));
            if (pNFreeds == NULL) {

                pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
                pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
                cosaError(pContext, __FILE__, __LINE__);
                return;
            }
            cosaOPSETArea(pContext, &pNFreeds[pDictPage->freedCount], 0x00, (newCount - pDictPage->freedCount) * sizeof(*pDictPage->pFreed));
            pDictPage->freedCount = newCount;
            pDictPage->pFreed = pNFreeds;
        }
    } else { --pDictPage->dictionariesTop; }
}

int main(void) {
    cosaContext context = {0};
    context.errorFUNC = errorFUNC;
    if (cosaInitContext(&context) == cosaBFalse) {
        cosaPrint("main: cosaInitContext failed.");
        return 1;
    }
    cosaPrint("main: Cosa success.");

    cosaS32 err = initDictPage(&context);
    if (err != 0) { return err; }
    cosaPrint("main: Success.");

    cosaU64 dictID = 0;
    _CreateDictionary(&context, &dictID);
    cosaPrintF("main: _CreateDictionary.return->dictID<%lu>\n", dictID);

    const cosaChar pText[] = "Hello, String!";
    cosaString s = {0};
    _DictionaryAddEntry(&context, &s, pText, strlen(pText), dictID);

    cosaBlock *pBStr = NULL;
    _DictionaryGetString(&context, &pBStr, &s, dictID);
    cosaPrintF("main: pBStr->addr<%s>\n", (cosaChar*)pBStr->addr);
    cosaDestroyBlock(&context, &pBStr);

    _DictionaryRemoveEntry(&context, &s, dictID);
    _DestroyDictionary(&context, dictID);

    err = destDictPage();
    if (err != 0) { return err; }
    cosaPrint("main: destStr success.");

    if (cosaDestroyContext(&context) == cosaBFalse) {
        cosaPrint("main: cosaDestroyContext failed.");
        return 1;
    }
    return err;
}