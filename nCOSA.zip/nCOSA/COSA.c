#include "headers/COSA.h"
#include "headers/error.h"

#if defined(COSA_OS_LINUX)
    #include "OSs/cosaLinux.h"
#endif

void cosaEndianSWP8B(cosaContext *pContext, cosaU8 *pA, cosaU8 *pB) {
    if (pContext == NULL) { return; }
    if ((pA == NULL) || (pB == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP8B(pA, pB);
}

void cosaEndianSWP16B(cosaContext *pContext, cosaU16 *pEndian) {
    if (pContext == NULL) { return; }
    if (pEndian == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP16B(pEndian);
}

void cosaEndianSWP32B(cosaContext *pContext, cosaU32 *pEndian) {
    if (pContext == NULL) { return; }
    if (pEndian == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP32B(pEndian);
}

void cosaEndianSWP64B(cosaContext *pContext, cosaU64 *pEndian) {
    if (pContext == NULL) { return; }
    if (pEndian == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP64B(pEndian);
}

void cosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateBlock(pContext, ppBlock, count, byteSize);
    #endif
}

void cosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaExpandBlock(pContext, pBlock, count, byteSize);
    #endif
}

void cosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaDestroyBlock(pContext, pBlock);
    #endif
}

void cosaStackXSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackXSPush(pContext, pStack, pItem);
    #endif
}

void cosaStackXDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((itemSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackXDPush(pContext, pStack, pItem, itemSize);
    #endif
}

void cosaStackXBPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemCount) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((itemCount < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackXBPush(pContext, pStack, pItem, itemCount);
    #endif
}

void *cosaStackXSPop(cosaContext *pContext, cosaMemBlock *pStack) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackXSPop(pContext, pStack);
    #endif
}

void *cosaStackXDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackXDPop(pContext, pStack, pItemSize);
    #endif
}

void *cosaStackXBPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackXBPop(pContext, pStack, pItemSize);
    #endif
}

void cosaCreateStackSS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateStackSS(pContext, ppBlock, count, byteSize);
    #endif
}

void cosaCreateStackDS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateStackDS(pContext, ppBlock, count, byteSize);
    #endif
}

void cosaCreateStackSD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if (size < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateStackSD(pContext, ppBlock, size);
    #endif
}

void cosaCreateStackDD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if (size < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateStackDD(pContext, ppBlock, size);
    #endif
}

void cosaCreateStackSB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL) || (pFlags == NULL) || (pBSizes == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((size < 1) || (flagCount < 1) || (bSizeCount < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateStackSB(pContext, ppBlock, size, flagCount, bSizeCount, pFlags, pBSizes);
    #endif
}

void cosaCreateStackDB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL) || (pFlags == NULL) || (pBSizes == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((size < 1) || (flagCount < 1) || (bSizeCount < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateStackDB(pContext, ppBlock, size, flagCount, bSizeCount, pFlags, pBSizes);
    #endif
}

void cosaStackSSRemove(cosaContext *pContext, cosaMemBlock *pStack, cosaU32 itemIndex) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackSSRemove(pContext, pStack, itemIndex);
    #endif
}

void cosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pQueue == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaQueueAdd(pContext, pQueue, pItem);
    #endif
}

void *cosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pQueue == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaQueueNext(pContext, pQueue);
    #endif
}

void cosaCreateQueue(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize) {
    if (pContext == NULL) { return; }
    if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateQueue(pContext, ppBlock, count, byteSize);
    #endif
}

cosaFile *cosaOpenFile(cosaContext *pContext, cosaU16 flags, cosaChar filePath[]) {
    if (pContext == NULL) { return NULL; }
    if ((filePath == NULL) || (cosaR2B(flags) == 0x00)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaOpenFile(pContext, flags, filePath);
    #endif
}

void cosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]) {
    if (pContext == NULL) { return; }
    if ((pImage == NULL) || (filePath == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaOpenImage(pContext, pImage, filePath);
    #endif
}

void cosaCloseFile(cosaContext *pContext, cosaFile *pFile) {
    if (pContext == NULL) { return; }
    if (pFile == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCloseFile(pContext, pFile);
    #endif
}

void cosaCloseImage(cosaContext *pContext, cosaImage *pImage) {
    if (pContext == NULL) { return; }
    if (pImage == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCloseImage(pContext, pImage);
    #endif
}

void cosaPanelUpdateMousePosInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_POS) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    #if defined(COSA_OS_LINUX)
        linuxCosaPanelUpdateMousePosInput(pContext, COSA_PANEL_LINK_CALL_ARGS_MOUSE_POS);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

void cosaPanelUpdateMouseKeyInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_KEY) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    #if defined(COSA_OS_LINUX)
        linuxCosaPanelUpdateMouseKeyInput(pContext, COSA_PANEL_LINK_CALL_ARGS_MOUSE_KEY);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

void cosaPanelUpdateKeyboardInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_KEYBOARD) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    #if defined(COSA_OS_LINUX)
        linuxCosaPanelUpdateKeyboardInput(pContext, COSA_PANEL_LINK_CALL_ARGS_KEYBOARD);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

void cosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    if (pPanel == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaPanelFrameStart(pContext, pPanel);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

void cosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    if (pPanel == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaPanelFrameEnd(pContext, pPanel);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

void cosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    if (pPanel == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->blockPage.pBlocks == NULL) || (pPanel->pTitle == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreatePanel(pContext, pPanel);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

void cosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    if (pPanel == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->blockPage.pBlocks == NULL) || (pPanel->pBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaDestroyPanel(pContext, pPanel);
    #endif
#else
    pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
    pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
#endif
}

cosaU8 cosaInitContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return COSA_RESULTS_FUNC_FAILURE;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (pContext->blockPage.pBlocks != NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (_TestArchitectureCompatibility() == COSA_RESULTS_FUNC_FAILURE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return COSA_RESULTS_FUNC_FAILURE;
    }
    _InitContext(pContext);

    #if defined(COSA_OS_LINUX)
        linuxCosaInitContext(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return COSA_RESULTS_FUNC_FAILURE; }

        #if defined(COSA_ENABLE_EXTENSIONS)
            linuxCosaInitExtensions(pContext);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                linuxCosaDestroyContext(pContext);
                return COSA_RESULTS_FUNC_FAILURE;
            }
        #endif
    #endif

    return COSA_RESULTS_FUNC_SUCCESS;
#endif
}

void cosaDestroyContext(cosaContext *pContext) {
    if (pContext != NULL) {
        #if defined(COSA_OS_LINUX)
            linuxCosaDestroyContext(pContext);
        #endif
    }
}
