#include "headers/COSA.h"
#include "OSs/cosaLinux.h"
#include "headers/error.h"

void cosaEndianSWP8B(cosaContext *pContext, cosaU8 *pA, cosaU8 *pB) {
    if (pContext == NULL) { return; }
    if ((pA == NULL) || (pB == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP8B(pA, pB);
}

void cosaEndianSWP16B(cosaContext *pContext, cosaU16 *pEndian) {
    if (pContext == NULL) { return; }
    if (pEndian == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP16B(pEndian);
}

void cosaEndianSWP32B(cosaContext *pContext, cosaU32 *pEndian) {
    if (pContext == NULL) { return; }
    if (pEndian == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP32B(pEndian);
}

void cosaEndianSWP64B(cosaContext *pContext, cosaU64 *pEndian) {
    if (pContext == NULL) { return; }
    if (pEndian == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    }
    _EndianSWP64B(pEndian);
}

cosaMemBlock *cosaMemoryAlloc(cosaContext *pContext, cosaU32 count, cosaUSize byteSize) {
    if (pContext == NULL) { return NULL; }
    if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    cosaMemBlock *pMemBlock = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pMemBlock = linuxCosaMemoryAlloc(pContext, count, byteSize);
            break;
        }
    }
    return pMemBlock;
}

cosaMemBlock *cosaMemoryAllocAA(cosaContext *pContext, cosaU32 count, cosaUSize byteSize) {
    if (pContext == NULL) { return NULL; }
    if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    cosaMemBlock *pMemBlock = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pMemBlock = linuxCosaMemoryAlloc(pContext, count, byteSize);
            break;
        }
    }
    cosaPrintF("<%p>\n", (void*)pMemBlock);
    _RunContextDiagnosis(pContext, "logAfter.txt", cosaBTrue);
    cosaPrintF("<%p>\n", (void*)pMemBlock->addr);
    return pMemBlock;
}

void cosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    if (pContext == NULL) { return; }
    if ((pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->memPage.pMem == NULL) || (pStack->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if (itemSize < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaStackPush(pContext, pStack, pItem, itemSize);
            break;
        }
    }
}

void *cosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    if (pContext == NULL) { return NULL; }
    if (pStack == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if ((pContext->memPage.pMem == NULL) || (pStack->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    void *pItem = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pItem = linuxCosaStackPop(pContext, pStack, pItemSize);
            break;
        }
    }
    return pItem;
}

cosaMemBlock *cosaCreateStack(cosaContext *pContext) {
    if (pContext == NULL) { return NULL; }
    if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    cosaMemBlock *pStack = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pStack = linuxCosaCreateStack(pContext);
            break;
        }
    }
    return pStack;
}

void cosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    if (pContext == NULL) { return; }
    if ((pQueue == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->memPage.pMem == NULL) || (pQueue->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaQueueAdd(pContext, pQueue, pItem);
            break;
        }
    }
}

void cosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue, cosaUSize elemID) {
    if (pContext == NULL) { return; }
    if (pQueue == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->memPage.pMem == NULL) || (pQueue->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaQueueRemove(pContext, pQueue, elemID);
            break;
        }
    }
}

void *cosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    if (pContext == NULL) { return NULL; }
    if (pQueue == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if ((pContext->memPage.pMem == NULL) || (pQueue->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    void *pItem = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pItem = linuxCosaQueueNext(pContext, pQueue);
            break;
        }
    }
    return pItem;
}

cosaMemBlock *cosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) { return NULL; }
    if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    cosaMemBlock *pQueue = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pQueue = linuxCosaCreateQueue(pContext, count, byteSize);
            break;
        }
    }
    return pQueue;
}

cosaFile *cosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]) {
    if (pContext == NULL) { return NULL; }
    if ((filePath == NULL) || (cosaR2B(flags, 0) == 0x00)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    cosaFile *pFile = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pFile = linuxCosaFileOpen(pContext, flags, filePath);
            break;
        }
    }
    return pFile;
}

void cosaFileClose(cosaContext *pContext, cosaFile *pFile) {
    if (pContext == NULL) { return; }
    if (pFile == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaFileClose(pContext, pFile);
            break;
        }
    }
}

/*void cosaOpenQOI(cosaContext *pContext, cosaChar filePath[]) {
    if (pContext == NULL) { return; }
    if (filePath == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaOpenQOI(pContext, filePath);
            break;
        }
    }
}*/

void cosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]) {
    if (pContext == NULL) { return; }
    if ((pImage == NULL) || (filePath == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaOpenImage(pContext, pImage, filePath);
            break;
        }
    }
}

void cosaCloseImage(cosaContext *pContext, cosaImage *pImage) {
    if (pContext == NULL) { return; }
    if (pImage == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaCloseImage(pContext, pImage);
            break;
        }
    }
}

void cosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }
    #if defined(COSA_EXTENSION_ENABLE_PANEL)
        if (pPanel == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
            return;
        } else if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        } else if ((pPanel->width < 1) || (pPanel->height < 1)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }
        switch (pContext->type) {
            case COSA_OS_LINUX: {
                linuxCosaPanelFrameStart(pContext, pPanel);
                break;
            }
        }
    #else
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    #endif
}

void cosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }
    #if defined(COSA_EXTENSION_ENABLE_PANEL)
        if (pPanel == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
            return;
        } else if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        } else if ((pPanel->width < 1) || (pPanel->height < 1)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }
        switch (pContext->type) {
            case COSA_OS_LINUX: {
                linuxCosaPanelFrameEnd(pContext, pPanel);
                break;
            }
        }
    #else
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    #endif
}

void cosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }
    #if defined(COSA_EXTENSION_ENABLE_PANEL)
        if (pPanel == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
            return;
        } else if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        } else if ((pPanel->width < 1) || (pPanel->height < 1)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }
        switch (pContext->type) {
            case COSA_OS_LINUX: {
                linuxCosaCreatePanel(pContext, pPanel);
                break;
            }
        }
    #else
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    #endif
}

void cosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
    if (pContext == NULL) { return; }
    #if defined(COSA_EXTENSION_ENABLE_PANEL)
        if (pPanel == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
            return;
        } else if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }
        switch (pContext->type) {
            case COSA_OS_LINUX: {
                linuxCosaDestroyPanel(pContext, pPanel);
                break;
            }
        }
    #else
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVFUNC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVFUNC;
    #endif
}

cosaU8 cosaInitContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return COSA_RESULTS_FUNC_FAILURE;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return COSA_RESULTS_FUNC_ARG_PTR_NULL;
    } else if (pContext->memPage.pMem != NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (pContext->type > 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (_TestArchitectureCompatibility() == COSA_RESULTS_FUNC_FAILURE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return COSA_RESULTS_FUNC_FAILURE;
    }
    _InitializeContext(pContext);


    pContext->memPage.top = 0;
    pContext->memPage.size = COSA_PAGE_MEM_START;
    #if defined(COSA_OS_LINUX)
        pContext->memPage.pMem = mmap(
            NULL,
            pContext->memPage.size,
            COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
            COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
            -1, 0);
    #endif
    if (pContext->memPage.pMem == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->memPage.pMem, 0, pContext->memPage.size);


    pContext->blockPage.top = 0;
    pContext->blockPage.count = COSA_PAGE_BLOCK_START;
    #if defined(COSA_OS_LINUX)
        pContext->blockPage.pBlocks = mmap(
            NULL,
            pContext->blockPage.count * sizeof(cosaMemBlock),
            COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
            COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
            -1, 0);
        if (pContext->blockPage.pBlocks == COSA_MEM_FAILURE) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        }
    #endif
    (void)memset(pContext->blockPage.pBlocks, 0, pContext->blockPage.count * sizeof(cosaMemBlock));


    cosaMemBlock *pCosaBlock = cosaMemoryAlloc(pContext, 1, sizeof(_CosaMD));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
        (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    _CosaMD *pCosaMD = (_CosaMD*)pCosaBlock->addr;
    pCosaMD->pCosaMDBlock = pCosaBlock;

    #if defined(COSA_OS_LINUX)
        linuxInitializeCosaMD(pContext, pCosaMD);
    #endif
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
        (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
        return COSA_RESULTS_FUNC_FAILURE;
    }


    pContext->filePage.count = COSA_FILE_DESCS_MIN;
    if ((pContext->filePage.count == 0) || (pCosaMD->systemInfo.maxFileDescs.rlim_cur < pContext->filePage.count)) {
        pContext->filePage.count = pCosaMD->systemInfo.maxFileDescs.rlim_cur;
    }
    #if defined(COSA_OS_LINUX)
        pContext->filePage.pFiles = mmap(
            NULL,
            pContext->filePage.count * sizeof(cosaFile),
            COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
            COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
            -1, 0);
        if (pContext->filePage.pFiles == COSA_MEM_FAILURE) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        }
    #endif
    (void)memset(pContext->filePage.pFiles, 0, pContext->filePage.count * sizeof(cosaFile));
    for (cosaU32 i = 0; i < pContext->filePage.count; ++i) {
        pContext->filePage.pFiles[i].desc = -1;
    }


    #if defined(COSA_ENABLE_EXTENSIONS)
        if (COSA_EXTENSION_COUNT == 0) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
            (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        } else if (COSA_EXTENSION_COUNT > 255) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
            (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        }
        pCosaMD->pExtensionStack = linuxCosaMemoryAlloc(pContext, (sizeof(_CosaExtension) * COSA_EXTENSION_COUNT) + sizeof(cosaU8), sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        }
        (void)memset(pCosaMD->pExtensionStack->addr, 0, pCosaMD->pExtensionStack->count * pCosaMD->pExtensionStack->byteSize);
    #endif

    return COSA_RESULTS_FUNC_SUCCESS;
#endif
}

#if defined(COSA_ENABLE_EXTENSIONS)
    void _CosaExtensionStackFlush(cosaContext *pContext, _CosaMD *pCosaMD) {
        cosaU8 top = (cosaU8)pCosaMD->pExtensionStack->addr[0];
        _CosaExtension *pExtStack = (_CosaExtension*)(pCosaMD->pExtensionStack->addr + sizeof(cosaU8));
        for (cosaU8 i = 0; i < top; ++i) {
            if (pExtStack[i].pBlock == NULL) { continue; }

            (*pExtStack[i].pCleanup)(pContext, pExtStack[i].ID, pExtStack[i].pBlock);
            pExtStack[i].ID = 0x00;
            pExtStack[i].pCleanup = NULL;
            pExtStack[i].pBlock = NULL;
        }
    }
#endif

void cosaDestroyContext(cosaContext *pContext) {
    if (pContext != NULL) {
        if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }
        //_RunContextDiagnosis(pContext, "logBefore.txt", cosaBTrue);


        #if defined(COSA_ENABLE_EXTENSIONS)
            _CosaMD *pCosaMD = (_CosaMD*)pContext->blockPage.pBlocks[0].addr;
            if (pCosaMD->pExtensionStack != NULL) {
                _CosaExtensionStackFlush(pContext, pCosaMD);
            }
        #endif


        #if defined(COSA_OS_LINUX)
            cosaI32 errBlock = munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            cosaI32 errMem   = munmap(pContext->memPage.pMem, pContext->memPage.size);

            cosaU8 flg = 0x00;
            (errBlock < 0) ? cosaSB(flg) : cosaCB(flg);
            (errMem < 0) ? cosaS1B(flg, 1) : cosaC1B(flg, 1);

            switch (cosaR2B(flg, 0)) {
                case 0x03: {
                    _SetContextERRResult(pContext, __FILE__, __LINE__);
                    break;
                }
                case 0x02: {
                    _SetContextERRResult(pContext, __FILE__, __LINE__);
                    pContext->blockPage.pBlocks = NULL;
                    break;
                }
                case 0x01: {
                    _SetContextERRResult(pContext, __FILE__, __LINE__);
                    pContext->memPage.pMem = NULL;
                    break;
                }
                default: {
                    pContext->blockPage.pBlocks = NULL;
                    pContext->memPage.pMem = NULL;
                    break;
                }
            }
        #endif

        //_RunContextDiagnosis(pContext, "logAfter.txt", cosaBTrue);
    }
}
