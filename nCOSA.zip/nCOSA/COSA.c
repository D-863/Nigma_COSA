#include "headers/COSA.h"
#include "headers/inlines.h"

#include "OSs/OS.h"

#if !defined(COSA_OPERATIONS_SKIP_CONTEXT_CHECK)
    #define CONTEXT_CHECK(ret) if (pContext == NULL) { ret }
#else
    #define CONTEXT_CHECK(ret)
#endif


//Operations:
void cosaOPZEROArea(cosaContext *pContext, void *pAddr, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osOPZEROArea(pAddr, size);
}

void cosaOPSETArea(cosaContext *pContext, void *pAddr, cosaU8 value, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osOPSETArea(pAddr, value, size);
}

void cosaOPMOVLArea(cosaContext *pContext, void *pAddr, cosaUSize offset, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osOPMOVLArea(pAddr, offset, size);
}

void cosaOPMOVRArea(cosaContext *pContext, void *pAddr, cosaUSize offset, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osOPMOVRArea(pAddr, offset, size);
}

void cosaOPCPYArea(cosaContext *pContext, const void *pSrc, void *pDest, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pSrc == NULL) || (pDest == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osOPCPYArea(pSrc, pDest, size);
}

void cosaOPSWPArea(cosaContext *pContext, void *pAddrA, void *pAddrB, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pAddrA == NULL) || (pAddrB == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osOPSWPArea(pAddrA, pAddrB, size);
}

//Pages:
void cosaCreatePage(cosaContext *pContext, cosaU64 *pPageID, cosaU8 startLV) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pPageID == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if (startLV > 3) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreatePage(pContext, pPageID, startLV);
}

void cosaPageGetMD(cosaContext *pContext, cosaPage *pPage, cosaU64 pageID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pPage == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osPageGetMD(pContext, pPage, pageID);
}

void cosaPageSetMD(cosaContext *pContext, cosaPage *pPage, cosaU64 pageID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pPage == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osPageSetMD(pContext, pPage, pageID);
}

void cosaPageExpand(cosaContext *pContext, cosaPage *pPage, cosaU64 byteSize, cosaU64 pageID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pPage == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if (byteSize == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osPageExpand(pContext, pPage, byteSize, pageID);
}

//System:
void cosaSystemGetInfo(cosaContext *pContext, cosaSysInfo *pSysInfo) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pSysInfo == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osSystemGetInfo(pContext, pSysInfo);
}

//RAM:
void *cosaCreateBlock(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return NULL;)
    if ((count == 0) || (byteSize == 0)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
#endif

    return osCreateBlock(pContext, ppBAddr, count, byteSize);
}

void cosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((count == 0) || (byteSize == 0)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osBlockExpand(pContext, pBAddr, count, byteSize);
}

void cosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((count == 0) || (byteSize == 0)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osBlockShrink(pContext, pBAddr, count, byteSize);
}

void cosaBlockSegment(cosaContext *pContext, const cosaBlock *pBSrc, cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pBSrc == NULL) || (pBDest == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if (size == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osBlockSegment(pContext, pBSrc, pBDest, srcOffset, destOffset, size);
}

void cosaBlockGetMD(cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pAddr == NULL) || (ppBAddr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osBlockGetMD(pContext, ppBAddr, pAddr);
}

void cosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osFreeBlock(pContext, ppBAddr);
}

void cosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osDestroyBlock(pContext, ppBAddr);
}

//Stacks:
void cosaCreateStackSS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((count == 0) || (byteSize == 0)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreateStackSS(pContext, ppBAddr, count, byteSize);
}

void cosaCreateStackSD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((count == 0) || (byteSize == 0)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreateStackSD(pContext, ppBAddr, count, byteSize);
}

void cosaCreateStackDS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if (size == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreateStackDS(pContext, ppBAddr, size);
}

void cosaCreateStackDD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if (size == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreateStackDD(pContext, ppBAddr, size);
}

void cosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osStackSXPush(pContext, pStack, pItem);
}

void cosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem, cosaUSize itemSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if (itemSize == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osStackDXPush(pContext, pStack, pItem, itemSize);
}

void *cosaStackSXPop(cosaContext *pContext, const cosaBlock *pStack) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return NULL;)
    if (pStack == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
#endif

    return osStackSXPop(pContext, pStack);
}

void *cosaStackDXPop(cosaContext *pContext, const cosaBlock *pStack, cosaUSize *pItemSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return NULL;)
    if ((pStack == NULL) || (pItemSize == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
#endif

    return osStackDXPop(pContext, pStack, pItemSize);
}

//Queues:
void cosaCreateQueue(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (ppBAddr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    } else if ((count == 0) || (byteSize == 0)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreateQueue(pContext, ppBAddr, count, byteSize);
}

void cosaQueueAdd(cosaContext *pContext, const cosaBlock *pQueue, const void *pItem) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if ((pQueue == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osQueueAdd(pContext, pQueue, pItem);
}

void *cosaQueueNext(cosaContext *pContext, const cosaBlock *pQueue) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return NULL;)
    if (pQueue == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return NULL;
    }
#endif

    return osQueueNext(pContext, pQueue);
}

//Strings:
void cosaCreateDictionary(cosaContext *pContext, cosaU64 *pDictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
    if (pDictionaryID == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return;
    }
#endif

    osCreateDictionary(pContext, pDictionaryID);
}

void cosaStringLoad(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osStringLoad(pContext, pString, dictionaryID);
}

void cosaStringUnload(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osStringUnload(pContext, pString, dictionaryID);
}

void cosaStringAddEntry(cosaContext *pContext, cosaString *pString, const cosaChar *pText, cosaU64 dictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osStringAddEntry(pContext, pString, pText, dictionaryID);
}

void cosaStringRemoveEntry(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osStringRemoveEntry(pContext, pString, dictionaryID);
}

void cosaStringGet(cosaContext *pContext, cosaBlock **ppBAddr, const cosaString *pString, cosaU64 dictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osStringGet(pContext, ppBAddr, pString, dictionaryID);
}

void cosaDestroyDictionary(cosaContext *pContext, cosaU64 dictionaryID) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osDestroyDictionary(pContext, dictionaryID);
}

//Files:
void cosaFileOpen(cosaContext *pContext, cosaFile **ppFile, const cosaChar *pFilePath, cosaU16 flags) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osFileOpen(pContext, ppFile, pFilePath, flags);
}

void cosaFileLoadInfo(cosaContext *pContext, cosaFile *pFile) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osFileLoadInfo(pContext, pFile);
}

void cosaFileUnloadInfo(cosaContext *pContext, cosaFile *pFile) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osFileUnloadInfo(pContext, pFile);
}

void cosaFileCreate(cosaContext *pContext) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osFileCreate(pContext);
}

void cosaFileWrite(cosaContext *pContext) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osFileWrite(pContext);
}

void cosaFileRead(cosaContext *pContext) {
#if !defined(COSA_OPERATIONS_SKIP_ALL_CHECK)
    CONTEXT_CHECK(return;)
#endif

    osFileRead(pContext);
}

//CosaContext:
cosaBool cosaInitContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return cosaBFalse;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return cosaBFalse;
    }

    cosaBool archCompatibility = cosaBFalse;
    _TestArchitectureCompatibility(&archCompatibility);
    if (archCompatibility == cosaBFalse) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return cosaBFalse;
    } else if (pContext->systemMD.buffers.pPages != NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
        cosaError(pContext, __FILE__, __LINE__);
        return cosaBFalse;
    }
    const void (*contextErrorFUNC)(COSA_ERROR_FUNC_ARGS) = pContext->errorFUNC;
    _InitContext(pContext);
    pContext->errorFUNC = contextErrorFUNC;
    pContext->systemMD.buffers.pageCount = 0;
    pContext->systemMD.buffers.pDataLevels = malloc(sizeof(cosaU8));
    pContext->systemMD.buffers.pPages = malloc(sizeof(void*));

    osInitContext(pContext);

    return (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) ? cosaBFalse : cosaBTrue;
#endif
}

cosaBool cosaDestroyContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return cosaBFalse;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return cosaBFalse;
    } else if (pContext->systemMD.buffers.pPages == NULL) { return cosaBTrue; }

    cosaBool archCompatibility = cosaBFalse;
    _TestArchitectureCompatibility(&archCompatibility);
    if (archCompatibility == cosaBFalse) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return cosaBFalse;
    }
    
    osDestroyContext(pContext);

    _InitContext(pContext);
    return cosaBTrue;
#endif
}
