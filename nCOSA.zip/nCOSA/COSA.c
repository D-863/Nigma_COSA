#include "headers/COSA.h"
#include "OSs/cosaLinux.h"
#include "headers/error.h"

cosaMemBlock *cosaMemoryAlloc(cosaContext *pContext, cosaU32 count, cosaUSize byteSize) {
    if (pContext == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    cosaMemBlock *pMemBlock = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pMemBlock = linuxCosaMemoryAlloc(pContext, count, byteSize);
            break;
        }
    }
    return pMemBlock;
}

void cosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    if ((pContext == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->memPage.pMem == NULL) || (pStack->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if (itemSize < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaStackPush(pContext, pStack, pItem, itemSize);
            break;
        }
    }
}

void *cosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize) {
    if ((pContext == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if ((pContext->memPage.pMem == NULL) || (pStack->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    void *pItem = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pItem = linuxCosaStackPop(pContext, pStack, pItemSize);
            break;
        }
    }
    return pItem;
}

cosaMemBlock *cosaCreateStack(cosaContext *pContext) {
    if (pContext == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    cosaMemBlock *pStack = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pStack = linuxCosaCreateStack(pContext);
            break;
        }
    }
    return pStack;
}

void cosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    if ((pContext == NULL) || (pQueue == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if ((pContext->memPage.pMem == NULL) || (pQueue->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaQueueAdd(pContext, pQueue, pItem);
            break;
        }
    }
}

void *cosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue) {
    if ((pContext == NULL) || (pQueue == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if ((pContext->memPage.pMem == NULL) || (pQueue->addr == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    void *pItem = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pItem = linuxCosaQueueRemove(pContext, pQueue);
            break;
        }
    }
    return pItem;
}

cosaMemBlock *cosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    cosaMemBlock *pQueue = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pQueue = linuxCosaCreateQueue(pContext, count, byteSize);
            break;
        }
    }
    return pQueue;
}

cosaFile *cosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]) {
    if ((pContext == NULL) || (filePath == NULL) || (cosaR2B(flags, 0) == 0x00)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return NULL;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    cosaFile *pFile = NULL;
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            pFile = linuxCosaFileOpen(pContext, flags, filePath);
            break;
        }
    }
    return pFile;
}

void cosaFileClose(cosaContext *pContext, cosaFile *pFile) {
    if ((pContext == NULL) || (pFile == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaFileClose(pContext, pFile);
            break;
        }
    }
}

cosaPanel *cosaCreatePanel(
    cosaContext *pContext,
    cosaU8 type,
    cosaI32 posX,
    cosaI32 posY,
    cosaU32 sizeX,
    cosaU32 sizeY,
    cosaU8 borderWidth,
    cosaU32 panelColor,
    cosaU32 borderColor,
    cosaChar *pTitle) {
        if (pContext == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
            return NULL;
        } else if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return NULL;
        }
        cosaPanel *pPanel = NULL;
        switch (pContext->type) {
            case COSA_OS_LINUX: {
                pPanel = linuxCosaCreatePanel(pContext, type, posX, posY, sizeX, sizeY, borderWidth, panelColor, borderColor, pTitle);
                break;
            }
        }
        return pPanel;
}

void cosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
    if ((pContext == NULL) || (pPanel == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;
        return;
    } else if (pContext->memPage.pMem == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    switch (pContext->type) {
        case COSA_OS_LINUX: {
            linuxCosaDestroyPanel(pContext, pPanel);
            break;
        }
    }
}

cosaU8 cosaInitContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return COSA_RESULTS_FUNC_FAILURE;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return COSA_RESULTS_FUNC_ARG_PTR_NULL;
    } else if (pContext->memPage.pMem != NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (pContext->type > 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (_TestArchitectureCompatibility() == COSA_RESULTS_FUNC_FAILURE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return COSA_RESULTS_FUNC_FAILURE;
    }
    _InitializeContext(pContext);


    pContext->memPage.top = 0;
    pContext->memPage.size = COSA_PAGE_MEM_START;
    #if defined(COSA_OS_LINUX)
        pContext->memPage.pMem = mmap(
            NULL,
            pContext->memPage.size,
            COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
            COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
            -1, 0);
    #endif
    if (pContext->memPage.pMem == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->memPage.pMem, 0, pContext->memPage.size);


    pContext->blockPage.top = 0;
    pContext->blockPage.count = COSA_PAGE_BLOCK_START;
    #if defined(COSA_OS_LINUX)
        pContext->blockPage.pBlocks = mmap(
            NULL,
            pContext->blockPage.count * sizeof(cosaMemBlock),
            COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
            COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
            -1, 0);
        if (pContext->blockPage.pBlocks == COSA_MEM_FAILURE) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        }
    #endif
    (void)memset(pContext->blockPage.pBlocks, 0, pContext->blockPage.count * sizeof(cosaMemBlock));


    cosaMemBlock *pCosaBlock = cosaMemoryAlloc(pContext, 1, sizeof(_CosaMD));
    _CosaMD *pCosaMD = (_CosaMD*)pCosaBlock->addr;
    pCosaMD->pCosaMDBlock = pCosaBlock;

    #if defined(COSA_OS_LINUX)
        linuxInitializeCosaMD(pContext, pCosaMD);
    #endif
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
        (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
        return COSA_RESULTS_FUNC_FAILURE;
    }


    pContext->filePage.count = COSA_FILE_DESCS_MIN;
    if ((pContext->filePage.count == 0) || (pCosaMD->systemInfo.maxFileDescs.rlim_cur < pContext->filePage.count)) {
        pContext->filePage.count = pCosaMD->systemInfo.maxFileDescs.rlim_cur;
    }
    #if defined(COSA_OS_LINUX)
        pContext->filePage.pFiles = mmap(
            NULL,
            pContext->filePage.count * sizeof(cosaFile),
            COSA_MEM_PROT_WE | COSA_MEM_PROT_RD,
            COSA_MEM_FLAG_ANON | COSA_MEM_FLAG_PVE,
            -1, 0);
        if (pContext->filePage.pFiles == COSA_MEM_FAILURE) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            (void)munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            (void)munmap(pContext->memPage.pMem, pContext->memPage.size);
            return COSA_RESULTS_FUNC_FAILURE;
        }
    #endif
    (void)memset(pContext->filePage.pFiles, 0, pContext->filePage.count * sizeof(cosaFile));
    for (cosaU32 i = 0; i < pContext->filePage.count; ++i) {
        pContext->filePage.pFiles[i].desc = -1;
    }

    return COSA_RESULTS_FUNC_SUCCESS;
#endif
}

void cosaDestroyContext(cosaContext *pContext) {
    if (pContext != NULL) {
        if (pContext->memPage.pMem == NULL) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
            return;
        }
        //_RunContextDiagnosis(pContext, "logBefore.txt");

        #if defined(COSA_OS_LINUX)
            cosaI32 errBlock = munmap(pContext->blockPage.pBlocks, pContext->blockPage.count * sizeof(cosaMemBlock));
            cosaI32 errMem   = munmap(pContext->memPage.pMem, pContext->memPage.size);

            cosaU8 flg = 0x00;
            (errBlock < 0) ? cosaSB(flg) : cosaCB(flg);
            (errMem < 0) ? cosaS1B(flg, 1) : cosaC1B(flg, 1);

            switch (cosaR2B(flg, 0)) {
                case 0x03: {
                    _SetContextERRResult(pContext, __FILE__, __LINE__);
                    break;
                }
                case 0x02: {
                    _SetContextERRResult(pContext, __FILE__, __LINE__);
                    pContext->blockPage.pBlocks = NULL;
                    break;
                }
                case 0x01: {
                    _SetContextERRResult(pContext, __FILE__, __LINE__);
                    pContext->memPage.pMem = NULL;
                    break;
                }
                default: {
                    pContext->blockPage.pBlocks = NULL;
                    pContext->memPage.pMem = NULL;
                    break;
                }
            }
        #endif

        //_RunContextDiagnosis(pContext, "logAfter.txt");
    }
}
