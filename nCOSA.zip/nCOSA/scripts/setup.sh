#!/usr/bin/env bash

ARG_FILE="headers/cosaMath.h"

if [ -f "$ARG_FILE" ]; then
    rm -v "$ARG_FILE"
fi

func_create_mathHDRS() {
    echo -ne "#ifndef NIGMA_COSA_MATH_H\n#define NIGMA_COSA_MATH_H\n" > "$ARG_FILE"
}

func_create_mathHDRE() {
    echo -ne "#endif\n" >> "$ARG_FILE"
}

func_create_mathVectors() {
}

func_create_mathHDRS
func_create_mathHDRE