#include "../headers/COSA.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        cosaPrint("sMath: Invalid args.");
        cosaPrint("sMath: Usage { ./sMath [FILE_PATHS] }");
        return COSA_CONTEXT_ERRN_INVARG;
    }

    cosaContext context = { .type = 1 };
    if (cosaInitContext(&context) != COSA_RESULTS_FUNC_SUCCESS) { return context.errorNUM; };
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return context.errorNUM;
    }

    cosaDestroyContext(&context);
    return context.errorNUM;
}