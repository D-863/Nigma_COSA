#ifndef NIGMA_COSA_STRUCTS_H
#define NIGMA_COSA_STRUCTS_H

#include "utilities.h"

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaPanel {
    cosaU16 flags;
    cosaU32 width;
    cosaU32 height;
    cosaU32 color; //{cR:8, cG:8, cB:8, cA:8}
    cosaI32 posX;
    cosaI32 posY;
    cosaChar *pTitle;
    cosaChar *pIconPath;
    cosaMemBlock *pBlock;
} cosaPanel;

typedef struct cosaLinkBlock {
    cosaUSize blockSlot;
    cosaMemBlock **ppBlockLink;
} cosaLinkBlock;

typedef struct cosaBlockPage {
    cosaUSize freedCount;
    cosaUSize blockCount;
    cosaUSize linkCount;
    cosaUSize freedTop;
    cosaUSize blockTop;
    cosaUSize linkTop;
    cosaUSize *pFreed;
    cosaMemBlock *pBlocks;
    cosaLinkBlock *pLinks;
} cosaBlockPage;

typedef struct cosaFile {
    cosaU8 flags;
    cosaI32 desc;
    cosaFInfo info;
    cosaU8 *pMData;
} cosaFile;

typedef struct cosaImage {
    cosaU8 type;
    cosaU32 width;
    cosaU32 height;
    cosaU32 channels;
    cosaFile *pFile;
    cosaU8 *pData;
} cosaImage;

typedef struct cosaFilePage {
    cosaU32 count;
    cosaFile *pFiles;
} cosaFilePage;

typedef struct _SystemInfo {
    cosaBool isBigEndian;
    _CosaSI_LT maxFDs;
} _SystemInfo;

typedef union _InputMap {
    //20B = |mod:8|keys:128|mouse_keys:8,mouse_pos:16|
    cosaU8 data[20];
    struct {
        struct {
            cosaU8 mSHIFT:1;
            cosaU8 mCONTROL:1;
            cosaU8 mALT:1;
            cosaU8 mSUPER:1;
            cosaU8 mCAPS_LOCK:1;
            cosaU8 mNUM_LOCK:3;
        } mod;
        struct {
            cosaU8 kSPACE:1;
            cosaU8 kAPOSTROPHE:1;
            cosaU8 kCOMMA:1;
            cosaU8 kMINUS:1;
            cosaU8 kPERIOD:1;
            cosaU8 kSLASH:1;
            cosaU8 k0:1;
            cosaU8 k1:1;
            cosaU8 k2:1;
            cosaU8 k3:1;
            cosaU8 k4:1;
            cosaU8 k5:1;
            cosaU8 k6:1;
            cosaU8 k7:1;
            cosaU8 k8:1;
            cosaU8 k9:1;
            cosaU8 kSEMICOLON:1;
            cosaU8 kEQUAL:1;
            cosaU8 kA:1;
            cosaU8 kB:1;
            cosaU8 kC:1;
            cosaU8 kD:1;
            cosaU8 kE:1;
            cosaU8 kF:1;
            cosaU8 kG:1;
            cosaU8 kH:1;
            cosaU8 kI:1;
            cosaU8 kJ:1;
            cosaU8 kK:1;
            cosaU8 kL:1;
            cosaU8 kM:1;
            cosaU8 kN:1;
            cosaU8 kO:1;
            cosaU8 kP:1;
            cosaU8 kQ:1;
            cosaU8 kR:1;
            cosaU8 kS:1;
            cosaU8 kT:1;
            cosaU8 kU:1;
            cosaU8 kV:1;
            cosaU8 kW:1;
            cosaU8 kX:1;
            cosaU8 kY:1;
            cosaU8 kZ:1;
            cosaU8 kLEFT_BRACKET:1;
            cosaU8 kBACKSLASH:1;
            cosaU8 kRIGHT_BRACKET:1;
            cosaU8 kGRAVE_ACCENT:1;
            cosaU8 kWORLD_1:1;
            cosaU8 kWORLD_2:1;
            cosaU8 kESCAPE:1;
            cosaU8 kENTER:1;
            cosaU8 kTAB:1;
            cosaU8 kBACKSPACE:1;
            cosaU8 kINSERT:1;
            cosaU8 kDELETE:1;
            cosaU8 kRIGHT:1;
            cosaU8 kLEFT:1;
            cosaU8 kDOWN:1;
            cosaU8 kUP:1;
            cosaU8 kPAGE_UP:1;
            cosaU8 kPAGE_DOWN:1;
            cosaU8 kHOME:1;
            cosaU8 kEND:1;
            cosaU8 kCAPS_LOCK:1;
            cosaU8 kSCROLL_LOCK:1;
            cosaU8 kNUM_LOCK:1;
            cosaU8 kPRINT_SCREEN:1;
            cosaU8 kPAUSE:1;
            cosaU8 kF1:1;
            cosaU8 kF2:1;
            cosaU8 kF3:1;
            cosaU8 kF4:1;
            cosaU8 kF5:1;
            cosaU8 kF6:1;
            cosaU8 kF7:1;
            cosaU8 kF8:1;
            cosaU8 kF9:1;
            cosaU8 kF10:1;
            cosaU8 kF11:1;
            cosaU8 kF12:1;
            cosaU8 kF13:1;
            cosaU8 kF14:1;
            cosaU8 kF15:1;
            cosaU8 kF16:1;
            cosaU8 kF17:1;
            cosaU8 kF18:1;
            cosaU8 kF19:1;
            cosaU8 kF20:1;
            cosaU8 kF21:1;
            cosaU8 kF22:1;
            cosaU8 kF23:1;
            cosaU8 kF24:1;
            cosaU8 kF25:1;
            cosaU8 kKP_0:1;
            cosaU8 kKP_1:1;
            cosaU8 kKP_2:1;
            cosaU8 kKP_3:1;
            cosaU8 kKP_4:1;
            cosaU8 kKP_5:1;
            cosaU8 kKP_6:1;
            cosaU8 kKP_7:1;
            cosaU8 kKP_8:1;
            cosaU8 kKP_9:1;
            cosaU8 kKP_DECIMAL:1;
            cosaU8 kKP_DIVIDE:1;
            cosaU8 kKP_MULTIPLY:1;
            cosaU8 kKP_SUBTRACT:1;
            cosaU8 kKP_ADD:1;
            cosaU8 kKP_ENTER:1;
            cosaU8 kKP_EQUAL:1;
            cosaU8 kLEFT_SHIFT:1;
            cosaU8 kLEFT_CONTROL:1;
            cosaU8 kLEFT_ALT:1;
            cosaU8 kLEFT_SUPER:1;
            cosaU8 kRIGHT_SHIFT:1;
            cosaU8 kRIGHT_CONTROL:1;
            cosaU8 kRIGHT_ALT:1;
            cosaU8 kRIGHT_SUPER:1;
            cosaU8 kMENU:8;
        } keys;
        struct {
            cosaU8 mK0:1;
            cosaU8 mK1:1;
            cosaU8 mK2:1;
            cosaU8 mK3:1;
            cosaU8 mK4:1;
            cosaU8 mK5:1;
            cosaU8 mK6:1;
            cosaU8 mK7:1;
            cosaU8 mPosX:8;
            cosaU8 mPosY:8;
        } mouse;
    } mapping;
} _InputMap;

typedef struct _CosaMD {
    _SystemInfo systemInfo;
    _InputMap inputMap;

#if defined(COSA_ENABLE_EXTENSIONS)
    cosaMemBlock *pSExtensions;
#endif
} _CosaMD;

typedef struct cosaContext {
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaFilePage filePage;
    _CosaMD *pCosaMD;
    cosaChar *errorMSG;
} cosaContext;

#if defined(COSA_ENABLE_EXTENSIONS)
typedef struct _CosaExtension {
    cosaU8 ID;
    cosaMemBlock *pBlock;
    void (*pCleanup)(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock);
} _CosaExtension;
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    typedef struct _cosaGLFW_EXT {
        cosaBool isInitialized;
        cosaU32 monitorCount;
        cosaU32 panelTop;
        GLFWmonitor **pBMonitors;
        cosaMemBlock *pBPanels;
    } _cosaGLFW_EXT;

    typedef struct cosaPanel_GLFW {
        GLFWimage icon;
        GLFWwindow *pWindow;
        GLFWmonitor *pMonitor;
    } cosaPanel_GLFW;
#endif

#endif