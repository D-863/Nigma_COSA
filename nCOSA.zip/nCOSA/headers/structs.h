#ifndef NIGMA_COSA_STRUCTS_H
#define NIGMA_COSA_STRUCTS_H

#include "utilities.h"

typedef struct cosaQueue_MD {
    cosaUSize byteSize;
    cosaUSize count;
    cosaUSize index;
    cosaUSize top;
} cosaQueue_MD;

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaPanel {
    cosaU8 type;
    cosaU32 sizeX;
    cosaU32 sizeY;
    cosaU32 color;
    cosaU32 border;
    cosaI32 posX;
    cosaI32 posY;
    cosaMemBlock *pBlock;
} cosaPanel;

typedef struct cosaFile {
    cosaU8 flags;
    cosaI32 desc;
    cosaFStat info;
    cosaU8 *pMData;
} cosaFile;

typedef struct cosaFilePage {
    cosaU32 count;
    cosaFile *pFiles;
} cosaFilePage;

typedef struct cosaBlockPage {
    cosaUSize count;
    cosaUSize top;
    cosaMemBlock *pBlocks;
} cosaBlockPage;

typedef struct cosaMemPage {
    cosaUSize size;
    cosaUSize top;
    cosaU8 *pMem;
} cosaMemPage;

typedef struct _SystemInfo {
    struct rlimit maxFileDescs;
} _SystemInfo;

typedef struct _CosaMD {
    cosaMemBlock *pCosaMDBlock;
    _SystemInfo systemInfo;
} _CosaMD;

typedef struct cosaContext {
    const cosaU8 type;
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaFilePage filePage;
    cosaMemPage memPage;
    cosaChar *errorMSG;
} cosaContext;

#endif