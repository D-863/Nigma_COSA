#ifndef NIGMA_COSA_STRUCTS_H
#define NIGMA_COSA_STRUCTS_H

#include "utilities.h"

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaPanel {
    cosaU16 flags;
    cosaU32 width;
    cosaU32 height;
    cosaU32 color; //{cR:8, cG:8, cB:8, cA:8}
    cosaI32 posX;
    cosaI32 posY;
    cosaChar *pTitle;
    cosaChar *pIconPath;
    cosaMemBlock *pBlock;
} cosaPanel;

typedef struct cosaLinkBlock {
    cosaUSize blockSlot;
    cosaMemBlock **ppBlockLink;
} cosaLinkBlock;

typedef struct cosaBlockPage {
    cosaUSize freedCount;
    cosaUSize blockCount;
    cosaUSize linkCount;
    cosaUSize freedTop;
    cosaUSize blockTop;
    cosaUSize linkTop;
    cosaUSize *pFreed;
    cosaMemBlock *pBlocks;
    cosaLinkBlock *pLinks;
} cosaBlockPage;

typedef struct cosaFile {
    cosaU8 flags;
    cosaI32 desc;
    cosaFInfo info;
    cosaU8 *pMData;
} cosaFile;

typedef struct cosaImage {
    cosaU8 type;
    cosaU32 width;
    cosaU32 height;
    cosaU32 channels;
    cosaFile *pFile;
    cosaU8 *pData;
} cosaImage;

typedef struct cosaFilePage {
    cosaU32 count;
    cosaFile *pFiles;
} cosaFilePage;

typedef struct _SystemInfo {
    cosaBool isBigEndian;
    _CosaSI_LT maxFDs;
} _SystemInfo;

typedef union _InputMap {
    cosaU8 data[COSA_INPUTMAP_SIZE];
    struct COSA_INPUTMAP_MAPPING mapping;
} _InputMap;

typedef struct _CosaMD {
    _SystemInfo systemInfo;
    _InputMap inputMap;

#if defined(COSA_ENABLE_EXTENSIONS)
    cosaMemBlock *pSExtensions;
#endif
} _CosaMD;

typedef struct cosaContext {
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaFilePage filePage;
    _CosaMD *pCosaMD;
    cosaChar *errorMSG;
} cosaContext;

#if defined(COSA_ENABLE_EXTENSIONS)
typedef struct _CosaExtension {
    cosaU8 ID;
    cosaMemBlock *pBlock;
    void (*pCleanup)(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock);
} _CosaExtension;
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    typedef struct _cosaGLFW_EXT {
        cosaBool isInitialized;
        cosaU32 monitorCount;
        cosaU32 panelTop;
        GLFWmonitor **pBMonitors;
        cosaMemBlock *pBPanels;
    } _cosaGLFW_EXT;

    typedef struct cosaPanel_GLFW {
        GLFWimage icon;
        GLFWwindow *pWindow;
        GLFWmonitor *pMonitor;
    } cosaPanel_GLFW;
#endif

#endif