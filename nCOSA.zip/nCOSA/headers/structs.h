#ifndef NIGMA_COSA_STRUCTS_H
#define NIGMA_COSA_STRUCTS_H

#include "utilities.h"

typedef struct cosaQueue_MD {
    cosaUSize byteSize;
    cosaUSize count;
    cosaUSize index;
    cosaUSize top;
} cosaQueue_MD;

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaPanel {
    cosaU16 flags;
    cosaU32 width;
    cosaU32 height;
    cosaU32 color; //{cR:8, cG:8, cB:8, cA:8}
    cosaI32 posX;
    cosaI32 posY;
    cosaChar *pTitle;
    cosaChar *pIconPath;
    cosaMemBlock *pBlock;
} cosaPanel;

typedef struct cosaFile {
    cosaU8 flags;
    cosaI32 desc;
    cosaFStat info;
    cosaU8 *pMData;
} cosaFile;

typedef struct cosaImage {
    cosaU8 type;
    cosaU32 width;
    cosaU32 height;
    cosaU32 channels;
    cosaFile *pFile;
    cosaU8 *pData;
} cosaImage;

typedef struct cosaFilePage {
    cosaU32 count;
    cosaFile *pFiles;
} cosaFilePage;

typedef struct cosaBlockPage {
    cosaUSize count;
    cosaUSize top;
    cosaMemBlock *pBlocks;
} cosaBlockPage;

typedef struct cosaMemPage {
    cosaUSize size;
    cosaUSize top;
    cosaU8 *pMem;
} cosaMemPage;

typedef struct _SystemInfo {
    cosaBool isBigEndian;
    struct rlimit maxFileDescs;
} _SystemInfo;


typedef struct _CosaMD {
    _SystemInfo systemInfo;
    cosaMemBlock *pCosaMDBlock;

#if defined(COSA_ENABLE_EXTENSIONS)
    cosaMemBlock *pExtensionStack;
#endif
} _CosaMD;

typedef struct cosaContext {
    const cosaU8 type;
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaFilePage filePage;
    cosaMemPage memPage;
    cosaChar *errorMSG;
} cosaContext;

#if defined(COSA_ENABLE_EXTENSIONS)
typedef struct _CosaExtension {
    cosaU8 ID;
    cosaMemBlock *pBlock;
    void (*pCleanup)(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock);
} _CosaExtension;
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    typedef struct _cosaGLFW_EXT {
        cosaBool isInitialized;
        cosaU32 monitorCount;
        GLFWmonitor **pBMonitors;
    } _cosaGLFW_EXT;

    typedef struct cosaPanel_GLFW {
        GLFWimage icon;
        GLFWwindow *pWindow;
        GLFWmonitor *pMonitor;
    } cosaPanel_GLFW;
#endif

#endif