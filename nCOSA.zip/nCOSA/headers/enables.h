#ifndef NIGMA_COSA_ENABLES_H
#define NIGMA_COSA_ENABLES_H

//#include "lizard.h"
#define COSA_ENABLE_DEBUG
#define COSA_SYSTEM_IS_STATIC 1

#endif