#ifndef NIGMA_COSA_DEFINES_H
#define NIGMA_COSA_DEFINES_H

#if !defined(COSA_ENABLE_SECURE_FUNCTIONS) && !defined(_CRT_SECURE_NO_WARNINGS)
    #define _CRT_SECURE_NO_WARNINGS
#endif


#if defined(__linux__)
    #define COSA_OS_LINUX 1

    /*Linux Libaries*/
    #include <sys/mman.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <sys/resource.h>
    #include <fcntl.h>
    #include <unistd.h>
#else
    #define COSA_OS_NOSUPPORT
#endif

#if defined(COSA_ENABLE_DEBUG)
    #include <assert.h>
#else
    #define NDEBUG
#endif

#if defined(COSA_ENABLE_EXTENSIONS)
    #if !defined(COSA_EXTENSION_COUNT)
        #define COSA_EXTENSION_COUNT 0
    #endif
#endif

#if defined(COSA_ENABLE_PANEL) && defined(COSA_ENABLE_EXTENSIONS)
    #define COSA_EXTENSION_ENABLE_PANEL
    #define COSA_EXTENSION_PANEL_ID 0x00

    #if defined(COSA_OS_LINUX)
        #include "../../glad/glad.h"
        #include "../../stb_image/stb_image.h"
        #include <GLFW/glfw3.h>
    #endif
#endif


#if defined(COSA_CHANGE_ALL)
    #define COSA_CHANGE_PRIMITIVE_DATA_TYPES
    #define COSA_CHANGE_RESULTS
    #define COSA_CHANGE_BIT_MANIPULATION
    #define COSA_CHANGE_PRINT
#endif

#if defined(COSA_CHANGE_PRIMITIVE_DATA_TYPES)
    #define COSA_CHANGE_BOOL
    #define COSA_CHANGE_CHAR
    #define COSA_CHANGE_UINTS
    #define COSA_CHANGE_INTS
    #define COSA_CHANGE_SIZE
    #define COSA_CHANGE_FLOATS
#endif

#if !defined(COSA_CHANGE_BOOL)
    #define cosaBool   bool
    #define cosaBTrue  1
    #define cosaBFalse 0
#endif

#if !defined(COSA_CHANGE_CHAR)
    typedef char cosaChar;
#endif

#if !defined(COSA_CHANGE_UINTS)
    typedef uint8_t  cosaU8;
    typedef uint16_t cosaU16;
    typedef uint32_t cosaU32;
    typedef uint64_t cosaU64;
#endif

#if !defined(COSA_CHANGE_INTS)
    typedef int8_t  cosaI8;
    typedef int16_t cosaI16;
    typedef int32_t cosaI32;
    typedef int64_t cosaI64;
#endif

#if !defined(COSA_CHANGE_SIZE)
    typedef size_t cosaUSize;

    #if defined(COSA_OS_LINUX)
        typedef ssize_t cosaISize;
    #endif
#endif

#if !defined(COSA_CHANGE_FLOATS)
    typedef float cosaFloat;
    typedef double cosaDouble;
    typedef long double cosaLDouble;
#endif

#if !defined(NIGMA_COSA_CHANGE_FILE)
    typedef struct stat cosaFStat;

    #define COSA_FILE_FLAG_PERM_RD 0x01
    #define COSA_FILE_FLAG_PERM_WE 0x02
    #define COSA_FILE_FLAG_IS_LINK 0x04

    #define COSA_FILE_DESCS_EXPAND 2
    #define COSA_FILE_DESCS_MIN    32
    #define COSA_FILE_DESCS_MAX    512
#endif

#if !defined(COSA_CHANGE_RESULTS)
    #define COSA_RESULTS_FUNC_SUCCESS 0
    #define COSA_RESULTS_FUNC_FAILURE 1
    #define COSA_RESULTS_FUNC_ARG_PTR_NULL 2

    #define COSA_CONTEXT_SUCCESS_NUM        0
    #define COSA_CONTEXT_SUCCESS_STR        "COSA: No failure."
    #define COSA_CONTEXT_ERRN_OPNP          EPERM
    #define COSA_CONTEXT_ERRS_OPNP          "COSA: Operation not permitted."
    #define COSA_CONTEXT_ERRN_INVPATH       ENOENT
    #define COSA_CONTEXT_ERRS_INVPATH       "COSA: No such file or directory."
    #define COSA_CONTEXT_ERRN_NOPR          ESRCH
    #define COSA_CONTEXT_ERRS_NOPR          "COSA: No such process."
    #define COSA_CONTEXT_ERRN_IO            EIO
    #define COSA_CONTEXT_ERRS_IO            "COSA: Input/output error."
    #define COSA_CONTEXT_ERRN_NOADDR        ENXIO
    #define COSA_CONTEXT_ERRS_NOADDR        "COSA: No such address."
    #define COSA_CONTEXT_ERRN_TOMARGS       E2BIG
    #define COSA_CONTEXT_ERRS_TOMARGS       "COSA: Argument list too long."
    #define COSA_CONTEXT_ERRN_OOM           ENOMEM
    #define COSA_CONTEXT_ERRS_OOM           "COSA: Failed to allocate heap memory, out of memory."
    #define COSA_CONTEXT_ERRN_DEALLOC       ENOMEM
    #define COSA_CONTEXT_ERRS_DEALLOC       "COSA: Failed to deallocate heap memory."
    #define COSA_CONTEXT_ERRN_OOP           ENOMEM
    #define COSA_CONTEXT_ERRS_OOP           "COSA: Failed to map heap memory to page, out of pages."
    #define COSA_CONTEXT_ERRN_PUNMAP        ENOMEM
    #define COSA_CONTEXT_ERRS_PUNMAP        "COSA: Failed to unmap heap memory from page."
    #define COSA_CONTEXT_ERRN_DPERM         EACCES
    #define COSA_CONTEXT_ERRS_DPERM         "COSA: Permission denied."
    #define COSA_CONTEXT_ERRN_BUSYDEV       EBUSY
    #define COSA_CONTEXT_ERRS_BUSYDEV       "COSA: Device or resource busy."
    #define COSA_CONTEXT_ERRN_NODEV         ENODEV
    #define COSA_CONTEXT_ERRS_NODEV         "COSA: No such device."
    #define COSA_CONTEXT_ERRN_INVDIR        ENOTDIR
    #define COSA_CONTEXT_ERRS_INVDIR        "COSA: Not a directory."
    #define COSA_CONTEXT_ERRN_INVARG        EINVAL
    #define COSA_CONTEXT_ERRS_INVARG        "COSA: Invalid argument."
    #define COSA_CONTEXT_ERRN_INPCIOFDEV    ENOTTY
    #define COSA_CONTEXT_ERRS_INPCIOFDEV    "COSA: Inappropriate ioctl for device."
    #define COSA_CONTEXT_ERRN_BUSYFILE      ETXTBSY
    #define COSA_CONTEXT_ERRS_BUSYFILE      "COSA: File busy."
    #define COSA_CONTEXT_ERRN_TOLFILE       EFBIG
    #define COSA_CONTEXT_ERRS_TOLFILE       "COSA: File too large."
    #define COSA_CONTEXT_ERRN_TOMFILE       EMFILE
    #define COSA_CONTEXT_ERRS_TOMFILE       "COSA: Too many open files."
    #define COSA_CONTEXT_ERRN_NODEVSP       ENOSPC
    #define COSA_CONTEXT_ERRS_NODEVSP       "COSA: No space left on device."
    #define COSA_CONTEXT_ERRN_ROADDR        EROFS
    #define COSA_CONTEXT_ERRS_ROADDR        "COSA: Read-only address."
    #define COSA_CONTEXT_ERRN_WOADDR        EROFS
    #define COSA_CONTEXT_ERRS_WOADDR        "COSA: Write-only address."
    #define COSA_CONTEXT_ERRN_BPIPE         EPIPE
    #define COSA_CONTEXT_ERRS_BPIPE         "COSA: Broken pipe."
    #define COSA_CONTEXT_ERRN_ARGOORNE      EDOM
    #define COSA_CONTEXT_ERRS_ARGOORNE      "COSA: Numerical argument out of range."
    #define COSA_CONTEXT_ERRN_RESOORNE      ERANGE
    #define COSA_CONTEXT_ERRS_RESOORNE      "COSA: Numerical result out of range."
    #define COSA_CONTEXT_ERRN_TOLFILEN      ENAMETOOLONG
    #define COSA_CONTEXT_ERRS_TOLFILEN      "COSA: File name too long."
    #define COSA_CONTEXT_ERRN_INVFUNC       ENOSYS
    #define COSA_CONTEXT_ERRS_INVFUNC       "COSA: Function not implemented."
    #define COSA_CONTEXT_ERRN_PTCDVNTATTCH  EUNATCH
    #define COSA_CONTEXT_ERRS_PTCDVNTATTCH  "COSA: Protocol driver not attached."
    #define COSA_CONTEXT_ERRN_INVSLT        EBADSLT
    #define COSA_CONTEXT_ERRS_INVSLT        "COSA: Invalid slot."
    #define COSA_CONTEXT_ERRN_BFONTF        EBFONT
    #define COSA_CONTEXT_ERRS_BFONTF        "COSA: Bad font file format."
    #define COSA_CONTEXT_ERRN_INVDEV        ENOSTR
    #define COSA_CONTEXT_ERRS_INVDEV        "COSA: Device not a stream."
    #define COSA_CONTEXT_ERRN_NONET         ENONET
    #define COSA_CONTEXT_ERRS_NONET         "COSA: Machine is not on the network."
    #define COSA_CONTEXT_ERRN_NOPKG         ENOPKG
    #define COSA_CONTEXT_ERRS_NOPKG         "COSA: Package not installed."
    #define COSA_CONTEXT_ERRN_SCOM          ECOMM
    #define COSA_CONTEXT_ERRS_SCOM          "COSA: Communication error on send."
    #define COSA_CONTEXT_ERRN_PTC           EPROTO
    #define COSA_CONTEXT_ERRS_PTC           "COSA: Protocol error."
    #define COSA_CONTEXT_ERRN_BMSG          EBADMSG
    #define COSA_CONTEXT_ERRS_BMSG          "COSA: Bad message."
    #define COSA_CONTEXT_ERRN_VALOVFLW      EOVERFLOW
    #define COSA_CONTEXT_ERRS_VALOVFLW      "COSA: Value too large for defined data type."
    #define COSA_CONTEXT_ERRN_NOUQNETNM     ENOTUNIQ
    #define COSA_CONTEXT_ERRS_NOUQNETNM     "COSA: Name not unique on network."
    #define COSA_CONTEXT_ERRN_BFDS          EBADFD
    #define COSA_CONTEXT_ERRS_BFDS          "COSA: File descriptor in bad state."
    #define COSA_CONTEXT_ERRN_CRTEADDR      EREMCHG
    #define COSA_CONTEXT_ERRS_CRTEADDR      "COSA: Remote address changed."
    #define COSA_CONTEXT_ERRN_LIBACC        ELIBACC
    #define COSA_CONTEXT_ERRS_LIBACC        "COSA: Can not access a needed shared library."
    #define COSA_CONTEXT_ERRN_LIBBAD        ELIBBAD
    #define COSA_CONTEXT_ERRS_LIBBAD        "COSA: Accessing a corrupted shared library."
    #define COSA_CONTEXT_ERRN_LIBSCN        ELIBSCN
    #define COSA_CONTEXT_ERRS_LIBSCN        "COSA: .lib section in a.out corrupted."
    #define COSA_CONTEXT_ERRN_LIBMAX        ELIBMAX
    #define COSA_CONTEXT_ERRS_LIBMAX        "COSA: Attempting to link in too many shared libraries."
    #define COSA_CONTEXT_ERRN_LIBEXE        ELIBEXEC
    #define COSA_CONTEXT_ERRS_LIBEXE        "COSA: Cannot exec a shared library directly."
    #define COSA_CONTEXT_ERRN_INVWCHR       EILSEQ
    #define COSA_CONTEXT_ERRS_INVWCHR       "COSA: Invalid or incomplete multibyte or wide character."
    #define COSA_CONTEXT_ERRN_INTRRST       ERESTART
    #define COSA_CONTEXT_ERRS_INTRRST       "COSA: Interrupted system call should be restarted."
    #define COSA_CONTEXT_ERRN_STRPIP        ESTRPIPE
    #define COSA_CONTEXT_ERRS_STRPIP        "COSA: Streams pipe error."
    #define COSA_CONTEXT_ERRN_INVSOCK       ENOTSOCK
    #define COSA_CONTEXT_ERRS_INVSOCK       "COSA: Socket operation on non-socket."
    #define COSA_CONTEXT_ERRN_RQDSTADDR     EDESTADDRREQ
    #define COSA_CONTEXT_ERRS_RQDSTADDR     "COSA: Destination address required."
    #define COSA_CONTEXT_ERRN_TOLMSG        EMSGSIZE
    #define COSA_CONTEXT_ERRS_TOLMSG        "COSA: Message too long."
    #define COSA_CONTEXT_ERRN_INVPTCTSOCK   EPROTOTYPE
    #define COSA_CONTEXT_ERRS_INVPTCTSOCK   "COSA: Protocol wrong type for socket."
    #define COSA_CONTEXT_ERRN_NOPTCAVL      ENOPROTOOPT
    #define COSA_CONTEXT_ERRS_NOPTCAVL      "COSA: Protocol not available."
    #define COSA_CONTEXT_ERRN_NOPTCSUP      EPROTONOSUPPORT
    #define COSA_CONTEXT_ERRS_NOPTCSUP      "COSA: Protocol not supported."
    #define COSA_CONTEXT_ERRN_NOSOCKTSUP    ESOCKTNOSUPPORT
    #define COSA_CONTEXT_ERRS_NOSOCKTSUP    "COSA: Socket type not supported."
    #define COSA_CONTEXT_ERRN_NOOPSUP       EOPNOTSUPP
    #define COSA_CONTEXT_ERRS_NOOPSUP       "COSA: Operation not supported."
    #define COSA_CONTEXT_ERRN_NOPTCFSUP     EPFNOSUPPORT
    #define COSA_CONTEXT_ERRS_NOPTCFSUP     "COSA: Protocol family not supported."
    #define COSA_CONTEXT_ERRN_PTCNOADDRFSUP EAFNOSUPPORT
    #define COSA_CONTEXT_ERRS_PTCNOADDRFSUP "COSA: Address family not supported by protocol."
    #define COSA_CONTEXT_ERRN_BUSYADDR      EADDRINUSE
    #define COSA_CONTEXT_ERRS_BUSYADDR      "COSA: Address already in use."
    #define COSA_CONTEXT_ERRN_RQADDR        EADDRNOTAVAIL
    #define COSA_CONTEXT_ERRS_RQADDR        "COSA: Cannot assign requested address."
    #define COSA_CONTEXT_ERRN_NETDWN        ENETDOWN
    #define COSA_CONTEXT_ERRS_NETDWN        "COSA: Network is down."
    #define COSA_CONTEXT_ERRN_NETURCH       ENETUNREACH
    #define COSA_CONTEXT_ERRS_NETURCH       "COSA: Network is unreachable."
    #define COSA_CONTEXT_ERRN_NETDCONRST    ENETRESET
    #define COSA_CONTEXT_ERRS_NETDCONRST    "COSA: Network dropped connection on reset."
    #define COSA_CONTEXT_ERRN_CONABT        ECONNABORTED
    #define COSA_CONTEXT_ERRS_CONABT        "COSA: Software caused connection abort."
    #define COSA_CONTEXT_ERRN_CONRST        ECONNRESET
    #define COSA_CONTEXT_ERRS_CONRST        "COSA: Connection reset by peer."
    #define COSA_CONTEXT_ERRN_OOBSP         ENOBUFS
    #define COSA_CONTEXT_ERRS_OOBSP         "COSA: No buffer space available."
    #define COSA_CONTEXT_ERRN_CONTMO        ETIMEDOUT
    #define COSA_CONTEXT_ERRS_CONTMO        "COSA: Connection timed out."
    #define COSA_CONTEXT_ERRN_CONREF        ECONNREFUSED
    #define COSA_CONTEXT_ERRS_CONREF        "COSA: Connection refused."
    #define COSA_CONTEXT_ERRN_HSTDWN        EHOSTDOWN
    #define COSA_CONTEXT_ERRS_HSTDWN        "COSA: Host is down."
    #define COSA_CONTEXT_ERRN_NORTHST       EHOSTUNREACH
    #define COSA_CONTEXT_ERRS_NORTHST       "COSA: No route to host."
    #define COSA_CONTEXT_ERRN_BUSYOP        EALREADY
    #define COSA_CONTEXT_ERRS_BUSYOP        "COSA: Operation already in progress."
    #define COSA_CONTEXT_ERRN_OPINPROG      EINPROGRESS
    #define COSA_CONTEXT_ERRS_OPINPROG      "COSA: Operation now in progress."
    #define COSA_CONTEXT_ERRN_SLFILE        ESTALE
    #define COSA_CONTEXT_ERRS_SLFILE        "COSA: Stale file handle."
    #define COSA_CONTEXT_ERRN_STCTCL        EUCLEAN
    #define COSA_CONTEXT_ERRS_STCTCL        "COSA: Structure needs cleaning."
    #define COSA_CONTEXT_ERRN_RTEIO         EREMOTEIO
    #define COSA_CONTEXT_ERRS_RTEIO         "COSA: Remote I/O error."
    #define COSA_CONTEXT_ERRN_DSKQA         EDQUOT
    #define COSA_CONTEXT_ERRS_DSKQA         "COSA: Disk quota exceeded."
    #define COSA_CONTEXT_ERRN_NOMDIM        ENOMEDIUM
    #define COSA_CONTEXT_ERRS_NOMDIM        "COSA: No medium found."
    #define COSA_CONTEXT_ERRN_INVMDIMT      EMEDIUMTYPE
    #define COSA_CONTEXT_ERRS_INVMDIMT      "COSA: Wrong medium type."
    #define COSA_CONTEXT_ERRN_OPCLC         ECANCELED
    #define COSA_CONTEXT_ERRS_OPCLC         "COSA: Operation canceled."
    #define COSA_CONTEXT_ERRN_NORQKEY       ENOKEY
    #define COSA_CONTEXT_ERRS_NORQKEY       "COSA: Required key not available."
    #define COSA_CONTEXT_ERRN_KEYEXP        EKEYEXPIRED
    #define COSA_CONTEXT_ERRS_KEYEXP        "COSA: Key has expired."
    #define COSA_CONTEXT_ERRN_KEYRVK        EKEYREVOKED
    #define COSA_CONTEXT_ERRS_KEYRVK        "COSA: Key has been revoked."
    #define COSA_CONTEXT_ERRN_KEYRJC        EKEYREJECTED
    #define COSA_CONTEXT_ERRS_KEYRJC        "COSA: Key was rejected by service."
    #define COSA_CONTEXT_ERRN_NORECVRBLESTE ENOTRECOVERABLE
    #define COSA_CONTEXT_ERRS_NORECVRBLESTE "COSA: State not recoverable."
    #define COSA_CONTEXT_ERRN_MEMPGHW       EHWPOISON
    #define COSA_CONTEXT_ERRS_MEMPGHW       "COSA: Memory page has hardware error."
    #define COSA_CONTEXT_ERRN_NODATA       ENODATA
    #define COSA_CONTEXT_ERRS_NODATA       "COSA: No data available."
#endif

#if !defined(COSA_CHANGE_BIT_MANIPULATION)
    #define cosaIsEndianBig(cosaU16_value) (*(cosaU8 *)&cosaU16_value == 0) ? cosaBTrue : cosaBFalse

    #define cosaSB(flag) (flag |= 0x01)
    #define cosaS1B(flag, offset) (flag |= (0x01 << offset))
    #define cosaS2B(flag, offset) (flag |= (0x03 << offset))
    #define cosaS3B(flag, offset) (flag |= (0x07 << offset))
    #define cosaS4B(flag, offset) (flag |= (0x0F << offset))
    #define cosaS5B(flag, offset) (flag |= (0x1F << offset))
    #define cosaS6B(flag, offset) (flag |= (0x3F << offset))
    #define cosaS7B(flag, offset) (flag |= (0x7F << offset))
    #define cosaS8B(flag, offset) (flag |= (0xFF << offset))

    #define cosaCB(flag) (flag &= (~0x01))
    #define cosaC1B(flag, offset) (flag &= ~(0x01 << offset))
    #define cosaC2B(flag, offset) (flag &= ~(0x03 << offset))
    #define cosaC3B(flag, offset) (flag &= ~(0x07 << offset))
    #define cosaC4B(flag, offset) (flag &= ~(0x0F << offset))
    #define cosaC5B(flag, offset) (flag &= ~(0x1F << offset))
    #define cosaC6B(flag, offset) (flag &= ~(0x3F << offset))
    #define cosaC7B(flag, offset) (flag &= ~(0x7F << offset))
    #define cosaC8B(flag, offset) (flag &= ~(0xFF << offset))

    #define cosaTB(flag) (flag ^= (~0x01))
    #define cosaT1B(flag, offset) (flag ^= ~(0x01 << offset))
    #define cosaT2B(flag, offset) (flag ^= ~(0x03 << offset))
    #define cosaT3B(flag, offset) (flag ^= ~(0x07 << offset))
    #define cosaT4B(flag, offset) (flag ^= ~(0x0F << offset))
    #define cosaT5B(flag, offset) (flag ^= ~(0x1F << offset))
    #define cosaT6B(flag, offset) (flag ^= ~(0x3F << offset))
    #define cosaT7B(flag, offset) (flag ^= ~(0x7F << offset))
    #define cosaT8B(flag, offset) (flag ^= ~(0xFF << offset))

    #define cosaRB(flag) (flag & 0x01)
    #define cosaR1B(flag, offset) (flag & (0x01 << offset))
    #define cosaR2B(flag, offset) (flag & (0x03 << offset))
    #define cosaR3B(flag, offset) (flag & (0x07 << offset))
    #define cosaR4B(flag, offset) (flag & (0x0F << offset))
    #define cosaR5B(flag, offset) (flag & (0x1F << offset))
    #define cosaR6B(flag, offset) (flag & (0x3F << offset))
    #define cosaR7B(flag, offset) (flag & (0x7F << offset))
    #define cosaR8B(flag, offset) (flag & (0xFF << offset))

    #define cosaWB(flag, pattern) (flag |= pattern)
    #define cosaW1B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW2B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW3B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW4B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW5B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW6B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW7B(flag, offset, pattern) (flag |= (pattern << offset))
    #define cosaW8B(flag, offset, pattern) (flag |= (pattern << offset))
#endif

#if !defined(COSA_CHANGE_PRINT)
    #define cosaPrint(str) (void)puts(str)
    #define cosaPrintF (void)printf
#endif

#if !defined(COSA_CHANGE_MEMORY)
    #define cosaBTKB(count) (count/1024)
    #define cosaBTMB(count) (count/1048576)
    #define cosaBTGB(count) (count/1073741824)
    #define cosaBTTB(count) (count/1099511627776)

    #define cosaKBTMB(count) (count/1024)
    #define cosaKBTGB(count) (count/1048576)
    #define cosaKBTTB(count) (count/1073741824)
    #define cosaKBTPB(count) (count/1099511627776)

    #define cosaMBTGB(count) (count/1024)
    #define cosaMBTTB(count) (count/1048576)
    #define cosaMBTPB(count) (count/1073741824)
    #define cosaMBTEB(count) (count/1099511627776)

    #define cosaGBTTB(count) (count/1024)
    #define cosaGBTPB(count) (count/1048576)
    #define cosaGBTEB(count) (count/1073741824)
    #define cosaGBTZB(count) (count/1099511627776)

    #define cosaTBTPB(count) (count/1024)
    #define cosaTBTEB(count) (count/1048576)
    #define cosaTBTZB(count) (count/1073741824)
    #define cosaTBTYB(count) (count/1099511627776)

    #define cosaPBTEB(count) (count/1024)
    #define cosaPBTZB(count) (count/1048576)
    #define cosaPBTYB(count) (count/1073741824)

    #define cosaEBTZB(count) (count/1024)
    #define cosaEBTYB(count) (count/1048576)

    #define cosaZBTYB(count) (count/1024)


    #define cosaKBTB(count) (count*1024)
    #define cosaMBTB(count) (count*1048576)
    #define cosaGBTB(count) (count*1073741824)
    #define cosaTBTB(count) (count*1099511627776)

    #define cosaMBTKB(count) (count*1024)
    #define cosaGBTKB(count) (count*1048576)
    #define cosaTBTKB(count) (count*1073741824)
    #define cosaPBTKB(count) (count*1099511627776)

    #define cosaGBTMB(count) (count*1024)
    #define cosaTBTMB(count) (count*1048576)
    #define cosaPBTMB(count) (count*1073741824)
    #define cosaEBTMB(count) (count*1099511627776)

    #define cosaTBTGB(count) (count*1024)
    #define cosaPBTGB(count) (count*1048576)
    #define cosaEBTGB(count) (count*1073741824)
    #define cosaZBTGB(count) (count*1099511627776)

    #define cosaPBTTB(count) (count*1024)
    #define cosaEBTTB(count) (count*1048576)
    #define cosaZBTTB(count) (count*1073741824)
    #define cosaYBTTB(count) (count*1099511627776)

    #define cosaEBTPB(count) (count*1024)
    #define cosaZBTPB(count) (count*1048576)
    #define cosaYBTPB(count) (count*1073741824)

    #define cosaZBTEB(count) (count*1024)
    #define cosaYBTEB(count) (count*1048576)

    #define cosaYBTZB(count) (count*1024)


    #if defined(COSA_OS_LINUX)
        #define COSA_MEM_PROT_EX PROT_EXEC
        #define COSA_MEM_PROT_RD PROT_READ
        #define COSA_MEM_PROT_WE PROT_WRITE
        #define COSA_MEM_PROT_NN PROT_NONE

        #define COSA_MEM_FLAG_SH   MAP_SHARED
        #define COSA_MEM_FLAG_SH_V MAP_SHARED_VALIDATE
        #define COSA_MEM_FLAG_PVE  MAP_PRIVATE

        #define COSA_MEM_FLAG_ANON MAP_ANONYMOUS
        #define COSA_MEM_FLAG_FED  MAP_FIXED
        #define COSA_MEM_FLAG_FED_NEPE MAP_FIXED_NOREPLACE
        #define COSA_MEM_FLAG_GD     MAP_GROWSDOWN
        #define COSA_MEM_FLAG_HTLB   MAP_HUGETLB
        #define COSA_MEM_FLAG_HSHT   MAP_HUGE_SHIFT
        #define COSA_MEM_FLAG_HMSK   MAP_HUGE_MASK
        #define COSA_MEM_FLAG_H16KB  MAP_HUGE_16KB
        #define COSA_MEM_FLAG_H64KB  MAP_HUGE_64KB
        #define COSA_MEM_FLAG_H512KB MAP_HUGE_512KB
        #define COSA_MEM_FLAG_H1MB   MAP_HUGE_1MB
        #define COSA_MEM_FLAG_H2MB   MAP_HUGE_2MB
        #define COSA_MEM_FLAG_H8MB   MAP_HUGE_8MB
        #define COSA_MEM_FLAG_H16MB  MAP_HUGE_16MB
        #define COSA_MEM_FLAG_H32MB  MAP_HUGE_32MB
        #define COSA_MEM_FLAG_H256MB MAP_HUGE_256MB
        #define COSA_MEM_FLAG_H512MB MAP_HUGE_512MB
        #define COSA_MEM_FLAG_H1GB   MAP_HUGE_1GB
        #define COSA_MEM_FLAG_H2GB   MAP_HUGE_2GB
        #define COSA_MEM_FLAG_H16GB  MAP_HUGE_16GB
        #define COSA_MEM_FLAG_LCK    MAP_LOCKED
        #define COSA_MEM_FLAG_NBLK   MAP_NONBLOCK
        #define COSA_MEM_FLAG_NRSV   MAP_NORESERVE
        #define COSA_MEM_FLAG_POP    MAP_POPULATE
        #define COSA_MEM_FLAG_SNC    MAP_SYNC

        #define COSA_MEM_FAILURE MAP_FAILED
    #endif

    #define COSA_MEM_FLAG_IS_FREE 0x00
    #define COSA_MEM_FLAG_IS_USED 0x01

    #define COSA_PAGE_BLOCK_START 8
    #define COSA_PAGE_BLOCK_EXPAND(count) (count <<= 1) // (count *= 2) -> (count <<= 1)
    #define COSA_PAGE_MEM_START 512
    #define COSA_PAGE_MEM_EXPAND(size) (size <<= 1) // (size *= 2) -> (size <<= 1)
    #define COSA_PAGE_MEM_MAX_CONTIGUOUS_EXPANSION 8

    #define COSA_STACK_SIZE cosaKBTB(1)
#endif

#if !defined(COSA_CHANGE_IMAGE)
    #define COSA_IMAGE_TYPES {[0] = ".jpg", [1] = ".png", [2] = ".tga", [3] = ".bmp", [4] = ".psd", [5] = ".gif", [6] = ".hdr", [7] = ".pic"}
    #define COSA_IMAGE_TYPE_LENGTH 4
    #define COSA_IMAGE_TYPE_COUNT 8
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    #if !defined(COSA_CHANGE_PANEL)
        #define COSA_PANEL_CONTEXT_MAJOR 3
        #define COSA_PANEL_CONTEXT_MINOR 3

        #define COSA_PANEL_WINDOWED           0x0000
        #define COSA_PANEL_FULL               0x0001
        #define COSA_PANEL_TRANSPARENT        0x0002 //COSA_PANEL_WINDOWED | COSA_PANEL_FULL
        #define COSA_PANEL_AUTO_FOCUS         0x0004 //COSA_PANEL_WINDOWED | COSA_PANEL_FULL
        #define COSA_PANEL_AUTO_SCALE_GRAPHIC 0x0008 //(COSA_PANEL_WINDOWED | COSA_PANEL_FULL) -> GLFW_SCALE_TO_MONITOR | GLFW_SCALE_FRAMEBUFFER
        #define COSA_PANEL_MOUSE_PASSTHROUGH  0x0010 //(COSA_PANEL_WINDOWED & !COSA_PANEL_DECORATED) | COSA_PANEL_FULL
        #define COSA_PANEL_RESIZABLE          0x0020 //COSA_PANEL_WINDOWED & COSA_PANEL_DECORATED
        #define COSA_PANEL_AUTO_ICONIFY       0x0020 //COSA_PANEL_FULL
        #define COSA_PANEL_MAXIMIZED          0x0040 //COSA_PANEL_WINDOWED
        #define COSA_PANEL_CENTER_CURSOR      0x0040 //COSA_PANEL_FULL
        #define COSA_PANEL_VISIBLE            0x0080 //COSA_PANEL_WINDOWED
        #define COSA_PANEL_DECORATED          0x0100 //COSA_PANEL_WINDOWED
        #define COSA_PANEL_FOCUSED            0x0200 //COSA_PANEL_WINDOWED & COSA_PANEL_VISIBLE
        #define COSA_PANEL_CONTEXT_DEBUG      0x0400 //COSA_PANEL_WINDOWED | COSA_PANEL_FULL

        //COSA_PANEL_WINDOWED | COSA_PANEL_AUTO_SCALE_GRAPHIC | COSA_PANEL_VISIBLE | COSA_PANEL_DECORATED
        #define COSA_PANEL_DEFAULT_WINDOWED_FLAGS 0x0188
        //COSA_PANEL_FULL | COSA_PANEL_AUTO_FOCUS | COSA_PANEL_AUTO_SCALE_GRAPHIC
        #define COSA_PANEL_DEFAULT_FULL_FLAGS 0x000D
    #endif
#endif

#endif