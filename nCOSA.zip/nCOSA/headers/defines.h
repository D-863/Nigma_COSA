#ifndef NIGMA_COSA_DEFINES_H
#define NIGMA_COSA_DEFINES_H

#include "utilities.h"

//Disable Windows stupid warnings for 'Secure functions'.
#if !defined(COSA_ENABLE_SECURE_FUNCTIONS) && !defined(_CRT_SECURE_NO_WARNINGS)
    #define _CRT_SECURE_NO_WARNINGS
#endif


#if defined(__linux__)
    #define COSA_OS_LINUX

    /*Linux Libaries*/
    #include <sys/mman.h>
    #include <sys/types.h>
    #include <sys/resource.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <unistd.h>

    typedef struct stat _CosaLinux_STAT;
    typedef struct rlimit _CosaLinux_RLIMIT;
    typedef __rlim_t _CosaLinux_RLIMIT_FD_T;
#else
    #define COSA_OS_NOSUPPORT
#endif

#if defined(COSA_ENABLE_DEBUG)
    #include <assert.h>
#else
    #define NDEBUG
#endif

//Types:
#if defined(COSA_CHANGE_ALL)
    #define COSA_CHANGE_PRIMITIVE_DATA_TYPES
    #define COSA_CHANGE_ERRORS
    #define COSA_CHANGE_BIT_MANIPULATION
    #define COSA_CHANGE_LOGIC
    #define COSA_CHANGE_PRINT
    #define COSA_CHANGE_OPERATIONS
    #define COSA_CHANGE_MEMORY
    #define COSA_CHANGE_MEMORY_SIZES
    #define COSA_CHANGE_STACK
    #define COSA_CHANGE_QUEUE
    #define COSA_CHANGE_FILE
    #define COSA_CHANGE_IMAGE
#endif

#if defined(COSA_CHANGE_PRIMITIVE_DATA_TYPES)
    #define COSA_CHANGE_BOOL
    #define COSA_CHANGE_CHAR
    #define COSA_CHANGE_UINTS
    #define COSA_CHANGE_SINTS
    #define COSA_CHANGE_SIZE
    #define COSA_CHANGE_FLOATS
#endif

#if !defined(COSA_CHANGE_BOOL)
    #define cosaBool   bool
    #define cosaBTrue  1
    #define cosaBFalse 0
#endif

#if !defined(COSA_CHANGE_CHAR)
    typedef char cosaChar;
    typedef unsigned char cosaUChar;
    typedef signed char cosaSChar;
#endif

#if !defined(COSA_CHANGE_UINTS)
    typedef uint8_t  cosaU8;
    typedef uint16_t cosaU16;
    typedef uint32_t cosaU32;
    typedef uint64_t cosaU64;
#endif

#if !defined(COSA_CHANGE_SINTS)
    typedef int8_t  cosaS8;
    typedef int16_t cosaS16;
    typedef int32_t cosaS32;
    typedef int64_t cosaS64;
#endif

#if !defined(COSA_CHANGE_SIZE)
    typedef size_t cosaUSize;
#endif

#if !defined(COSA_CHANGE_FLOATS)
    typedef float cosaFloat;
    typedef double cosaDouble;
    typedef long double cosaLong;
#endif

//Macros and Values:
#if !defined(COSA_CHANGE_SYSTEM_MD)
    //Checks if the current architecture is big endian, cosaU16_value must be set to 0x0001.
    #define cosaSysEndianIsBig(cosaU16_value) (*((cosaU8*)&cosaU16_value) == 0) ? cosaBTrue : cosaBFalse

    #define COSA_MEMPAGE_BLOCK_START 8
    #define COSA_MEMPAGE_FREED_START 8
    #define COSA_MEMPAGE_LINK_START 8
    #define COSA_MEMPAGE_BLOCK_EXPAND(count) (count << 1) // (count * 2) -> (count << 1)
    #define COSA_MEMPAGE_FREED_EXPAND(count) (count << 1) // (count * 2) -> (count << 1)
    #define COSA_MEMPAGE_LINK_EXPAND(count) (count << 1) // (count * 2) -> (count << 1)

    #define COSA_SYSTEM_LV0 0 //The LV0 unit for [SYSTEM_LV].
    #define COSA_SYSTEM_LV1 1 //The LV1 unit for [SYSTEM_LV].
    #define COSA_SYSTEM_LV2 2 //The LV2 unit for [SYSTEM_LV].
    #define COSA_SYSTEM_LV3 3 //The LV3 unit for [SYSTEM_LV].

    /*
        The 'LVX' unit for [SYSTEM_LV],
        this is just for neat pre-processor usage/cases and should not be used when system state is static.
    */
    #define COSA_SYSTEM_LVX 255
    #define COSA_SYSTEM_LV_COUNT 4 //The count of possible LV's for [SYSTEM_LV], discluding 'LVX'.
    #define COSA_SYSTEM_LV_TCOUNT 4 //The total count of possible LV's for [SYSTEM_LV], including 'LVX'.

    #if !defined(COSA_FILEPAGE_CHECK_EXPLICIT_RANGE)
        /*
            If this is defined as 1 and the system state is static,
            the initilazation of filePage will fail when the defined adequate [FILEPAGE] type,
            cannot support the complete count of [SYSINFO]'s minFDs.
        */
        #define COSA_FILEPAGE_CHECK_EXPLICIT_RANGE 0
    #endif

    #define COSA_FILEPAGE_FINFO_COUNT_START 8
    #define COSA_FILEPAGE_FILE_COUNT_START 8
    #define COSA_FILEPAGE_FINFO_EXPAND(count) (count << 1) // (count * 2) -> (count << 1)
    #define COSA_FILEPAGE_FILE_EXPAND(count) (count << 1) // (count * 2) -> (count << 1)
#endif

#if !defined(COSA_CHANGE_SYSTEM_STATE)
    #if !defined(COSA_SYSTEM_IS_STATIC)
        #define COSA_SYSTEM_IS_STATIC 0
    #endif

    #if (COSA_SYSTEM_IS_STATIC == 1)
        /*
            The different possible adequate values for different LV's of [SYSTEM_LV]:
                SYSINFO_TYPE:  ([SYSTEM_LV] < 4) ? _SysInfo_LV[SYSTEM_LV] : void;
                MEMPAGE_TYPE:  ([SYSTEM_LV] < 4) ? _MemPage_LV[SYSTEM_LV] : void;
                STRPAGE_TYPE:  ([SYSTEM_LV] < 4) ? _MemPage_LV[SYSTEM_LV] : void;
                FILEPAGE_TYPE: ([SYSTEM_LV] < 4) ? _MemPage_LV[SYSTEM_LV] : void;

                SYSTEM_LV_TYPE: {
                    [SYSTEM_LV] = 0: cosaU8
                    [SYSTEM_LV] = 1: cosaU16
                    [SYSTEM_LV] = 2: cosaU32
                    [SYSTEM_LV] = 3: cosaU64
                    [SYSTEM_LV] > 3: cosaU64
                }

                SYSTEM_LV_MAX: (2 ^ (sizeof([SYSTEM_LV_TYPE]) * 8)) - 1
                SYSTEM_LV: COSA_SYSTEM_LV[SYSTEM_LV]

                cosaSystemLVFunc(x, level): ([SYSTEM_LV] < 4) ? (x##_LV[SYSTEM_LV]) : (x##_LV3); //[level] argument is excluded for static system state.
                cosaSystemLVFuncBit(x): {
                    [SYSTEM_LV] = 0: (x##_8B)
                    [SYSTEM_LV] = 1: (x##_16B)
                    [SYSTEM_LV] = 2: (x##_32B)
                    [SYSTEM_LV] = 3: (x##_64B)
                    [SYSTEM_LV] > 3: (x##_64B)
                }
        */
        #define COSA_SYSINFO_TYPE _SysInfo_LV2   //The adequate [SYSINFO] type for the current [SYSTEM_LV].
        #define COSA_MEMPAGE_TYPE _MemPage_LV2   //The adequate [MEMPAGE] type for the current [SYSTEM_LV].
        #define COSA_STRPAGE_TYPE _StrPage_LV2   //The adequate [STRPAGE] type for the current [SYSTEM_LV].
        #define COSA_FILEPAGE_TYPE _FilePage_LV2 //The adequate [FILEPAGE] type for the current [SYSTEM_LV].
        #define COSA_SYSTEM_LV_TYPE cosaU32      //The adequate type for the current [SYSTEM_LV].
        #define COSA_SYSTEM_LV_MAX 0xFFFFFFFF    //The maximum unit the [SYSTEM_LV_TYPE] can hold.
        #define COSA_SYSTEM_LV COSA_SYSTEM_LV2   //The current system LV.

        /*
            Will call a specific shade of func<x, level>, depending on [SYSTEM_LV].
            So that if [SYSTEM_LV] is LV0: <foo> -> foo_LV0.

            (NOTE: [level] is dynamic specific, just put put 'pContext->systemMD.dataLevels.levels.*' here,
            [*] being the dominator for [x], example: "[*] will be 'memPage' because [x] is a function that does something with the memPage.")
        */
        #define cosaSystemLVFunc(level, x, ...) x##_LV2(__VA_ARGS__)

        /*
            Will call a specific shade of func<x>, depending on [SYSTEM_LV] by Bits.
            So that if [SYSTEM_LV] is LV0: <foo> -> foo_8B.

            (NOTE: [level] is dynamic specific, just put put 'pContext->systemMD.dataLevels.levels.*' here,
            [*] being the dominator for [x], example: "[*] will be 'memPage' because [x] is a function that does something with the memPage.")
        */
        #define cosaSystemLVFuncBit(level, x, ...) x##_32B(__VA_ARGS__)
    #else
        /*
            The range is dynamic over runtime at the cost of greater code size and potential decreased in performance.
            If a reasonable range is known, I highly recommend to keep the range Static. After all for [MEMPAGE],
            do you Really need more than 64KB(LV1) or 4GB(LV2) of possible allocations? <_<'
        */
        #define COSA_SYSINFO_TYPE void                //The adequate [SYSINFO] type for the current [SYSTEM_LV].
        #define COSA_MEMPAGE_TYPE void                //The adequate [MEMPAGE] type for the current [SYSTEM_LV].
        #define COSA_STRPAGE_TYPE void                //The adequate [STRPAGE] type for the current [SYSTEM_LV].
        #define COSA_FILEPAGE_TYPE void               //The adequate [FILEPAGE] type for the current [SYSTEM_LV].
        #define COSA_SYSTEM_LV_TYPE cosaU64           //The adequate type for the current [SYSTEM_LV].
        #define COSA_SYSTEM_LV_MAX 0xFFFFFFFFFFFFFFFF //The maximum unit the [SYSTEM_LV_TYPE] can hold.
        #define COSA_SYSTEM_LV COSA_SYSTEM_LVX        //The current system LV.

        //Same as above static state of system, except that [level] is now utilized.
        #define cosaSystemLVFunc(level, x, ...) switch (level) {\
            case 0: {\
                x##_LV0(__VA_ARGS__);\
                break;\
            }\
            case 1: {\
                x##_LV1(__VA_ARGS__);\
                break;\
            }\
            case 2: {\
                x##_LV2(__VA_ARGS__);\
                break;\
            }\
            default:
            case 3: {\
                x##_LV3(__VA_ARGS__);\
                break;\
            }\
        }

        //Same as above static state of system, except that [level] is now utilized.
        #define cosaSystemLVFuncBit(level, x, ...) switch (level) {\
            case 0: {\
                x##_8B(__VA_ARGS__);\
                break;\
            }\
            case 1: {\
                x##_16B(__VA_ARGS__);\
                break;\
            }\
            case 2: {\
                x##_32B(__VA_ARGS__);\
                break;\
            }\
            default:
            case 3: {\
                x##_64B(__VA_ARGS__);\
                break;\
            }\
        }
    #endif
#endif

#if !defined(COSA_CHANGE_INPUTMAP)
    //When a key's state is neither 0(Released) or 1(Pressed), what action should be executed?
    #if !defined(COSA_INPUTMAP_KEYSTATE_OVERFLOW)
        #define COSA_INPUTMAP_KEYSTATE_OVERFLOW(state) if (state > 1) { state = 1; }
    #endif

    //19B = |mod:8|keys:120|mouse_keys:8,mouse_pos:16|
    #define COSA_INPUTMAP_SIZE 19
    #define COSA_INPUTMAP_START_MOD 0
    #define COSA_INPUTMAP_START_KEYBOARD 1
    #define COSA_INPUTMAP_START_MOUSE_KEY 16
    #define COSA_INPUTMAP_START_MOUSE_POSX 17
    #define COSA_INPUTMAP_START_MOUSE_POSY 18
    #define COSA_INPUTMAP_MAP {\
        cosaU8 modSHIFT:1;\
        cosaU8 modCONTROL:1;\
        cosaU8 modALT:1;\
        cosaU8 modSUPER:1;\
        cosaU8 modCAPS_LOCK:1;\
        cosaU8 modNUM_LOCK:1;\
        cosaU8 _RSVD:2;\
        cosaU8 kSPACE:1;\
        cosaU8 kAPOSTROPHE:1;\
        cosaU8 kCOMMA:1;\
        cosaU8 kMINUS:1;\
        cosaU8 kPERIOD:1;\
        cosaU8 kSLASH:1;\
        cosaU8 k0:1;\
        cosaU8 k1:1;\
        cosaU8 k2:1;\
        cosaU8 k3:1;\
        cosaU8 k4:1;\
        cosaU8 k5:1;\
        cosaU8 k6:1;\
        cosaU8 k7:1;\
        cosaU8 k8:1;\
        cosaU8 k9:1;\
        cosaU8 kGRAVE_ACCENT:1;\
        cosaU8 kWORLD_1:1;\
        cosaU8 kWORLD_2:1;\
        cosaU8 kA:1;\
        cosaU8 kB:1;\
        cosaU8 kC:1;\
        cosaU8 kD:1;\
        cosaU8 kE:1;\
        cosaU8 kF:1;\
        cosaU8 kG:1;\
        cosaU8 kH:1;\
        cosaU8 kI:1;\
        cosaU8 kJ:1;\
        cosaU8 kK:1;\
        cosaU8 kL:1;\
        cosaU8 kM:1;\
        cosaU8 kN:1;\
        cosaU8 kO:1;\
        cosaU8 kP:1;\
        cosaU8 kQ:1;\
        cosaU8 kR:1;\
        cosaU8 kS:1;\
        cosaU8 kT:1;\
        cosaU8 kU:1;\
        cosaU8 kV:1;\
        cosaU8 kW:1;\
        cosaU8 kX:1;\
        cosaU8 kY:1;\
        cosaU8 kZ:1;\
        cosaU8 kLEFT_BRACKET:1;\
        cosaU8 kBACKSLASH:1;\
        cosaU8 kRIGHT_BRACKET:1;\
        cosaU8 kKP_0:1;\
        cosaU8 kKP_1:1;\
        cosaU8 kKP_2:1;\
        cosaU8 kKP_3:1;\
        cosaU8 kKP_4:1;\
        cosaU8 kKP_5:1;\
        cosaU8 kKP_6:1;\
        cosaU8 kKP_7:1;\
        cosaU8 kKP_8:1;\
        cosaU8 kKP_9:1;\
        cosaU8 kKP_DECIMAL:1;\
        cosaU8 kKP_DIVIDE:1;\
        cosaU8 kKP_MULTIPLY:1;\
        cosaU8 kKP_SUBTRACT:1;\
        cosaU8 kKP_ADD:1;\
        cosaU8 kKP_ENTER:1;\
        cosaU8 kKP_EQUAL:1;\
        cosaU8 kLEFT_SHIFT:1;\
        cosaU8 kESCAPE:1;\
        cosaU8 kENTER:1;\
        cosaU8 kTAB:1;\
        cosaU8 kBACKSPACE:1;\
        cosaU8 kINSERT:1;\
        cosaU8 kDELETE:1;\
        cosaU8 kRIGHT:1;\
        cosaU8 kLEFT:1;\
        cosaU8 kDOWN:1;\
        cosaU8 kUP:1;\
        cosaU8 kPAGE_UP:1;\
        cosaU8 kPAGE_DOWN:1;\
        cosaU8 kHOME:1;\
        cosaU8 kEND:1;\
        cosaU8 kCAPS_LOCK:1;\
        cosaU8 kSCROLL_LOCK:1;\
        cosaU8 kNUM_LOCK:1;\
        cosaU8 kPRINT_SCREEN:1;\
        cosaU8 kPAUSE:1;\
        cosaU8 kSEMICOLON:1;\
        cosaU8 kEQUAL:1;\
        cosaU8 kF1:1;\
        cosaU8 kF2:1;\
        cosaU8 kF3:1;\
        cosaU8 kF4:1;\
        cosaU8 kF5:1;\
        cosaU8 kF6:1;\
        cosaU8 kF7:1;\
        cosaU8 kF8:1;\
        cosaU8 kF9:1;\
        cosaU8 kF10:1;\
        cosaU8 kF11:1;\
        cosaU8 kF12:1;\
        cosaU8 kF13:1;\
        cosaU8 kF14:1;\
        cosaU8 kF15:1;\
        cosaU8 kF16:1;\
        cosaU8 kF17:1;\
        cosaU8 kF18:1;\
        cosaU8 kF19:1;\
        cosaU8 kF20:1;\
        cosaU8 kF21:1;\
        cosaU8 kF22:1;\
        cosaU8 kF23:1;\
        cosaU8 kF24:1;\
        cosaU8 kF25:1;\
        cosaU8 kLEFT_CONTROL:1;\
        cosaU8 kLEFT_ALT:1;\
        cosaU8 kLEFT_SUPER:1;\
        cosaU8 kRIGHT_SHIFT:1;\
        cosaU8 kRIGHT_CONTROL:1;\
        cosaU8 kRIGHT_ALT:1;\
        cosaU8 kRIGHT_SUPER:1;\
        cosaU8 kMENU:1;\
        cosaU8 mK0:1;\
        cosaU8 mK1:1;\
        cosaU8 mK2:1;\
        cosaU8 mK3:1;\
        cosaU8 mK4:1;\
        cosaU8 mK5:1;\
        cosaU8 mK6:1;\
        cosaU8 mK7:1;\
        cosaU8 mPosX:8;\
        cosaU8 mPosY:8;\
    }
#endif

#if !defined(COSA_CHANGE_ERRORS)
    #define COSA_ERROR_FUNC_ARGS cosaChar *pErrorMSG, cosaMDSystem *pSystemMD, cosaU8 errorNUM, const cosaChar filePath[], const cosaS32 codeLine
    #define COSA_ERROR_MSG "COSA: {\n\tFile<>\n\tLine<>\n\tERROR: {\n\t\tnum<>\n\t\tstr<>\n\t}\n}\n"

    #define COSA_CONTEXT_SUCCESS_NUM        0
    #define COSA_CONTEXT_SUCCESS_MSG        "No failure"
    #define COSA_CONTEXT_ERRN_OPNP          1
    #define COSA_CONTEXT_ERRS_OPNP          "Operation not permitted"
    #define COSA_CONTEXT_ERRN_INVPATH       2
    #define COSA_CONTEXT_ERRS_INVPATH       "No such file or directory"
    #define COSA_CONTEXT_ERRN_NOPR          3
    #define COSA_CONTEXT_ERRS_NOPR          "No such process"
    #define COSA_CONTEXT_ERRN_IO            4
    #define COSA_CONTEXT_ERRS_IO            "Input/output error"
    #define COSA_CONTEXT_ERRN_NOADDR        5
    #define COSA_CONTEXT_ERRS_NOADDR        "No such address"
    #define COSA_CONTEXT_ERRN_TOMARGS       6
    #define COSA_CONTEXT_ERRS_TOMARGS       "Argument list too long"
    #define COSA_CONTEXT_ERRN_OOM           7
    #define COSA_CONTEXT_ERRS_OOM           "Failed to allocate heap memory, out of memory"
    #define COSA_CONTEXT_ERRN_DEALLOC       8
    #define COSA_CONTEXT_ERRS_DEALLOC       "Failed to deallocate heap memory"
    #define COSA_CONTEXT_ERRN_OOP           9
    #define COSA_CONTEXT_ERRS_OOP           "Failed to map heap memory to page, out of pages"
    #define COSA_CONTEXT_ERRN_PUNMAP        10
    #define COSA_CONTEXT_ERRS_PUNMAP        "Failed to unmap heap memory from page"
    #define COSA_CONTEXT_ERRN_DPERM         11
    #define COSA_CONTEXT_ERRS_DPERM         "Permission denied"
    #define COSA_CONTEXT_ERRN_BUSYDEV       12
    #define COSA_CONTEXT_ERRS_BUSYDEV       "Device or resource busy"
    #define COSA_CONTEXT_ERRN_NODEV         13
    #define COSA_CONTEXT_ERRS_NODEV         "No such device"
    #define COSA_CONTEXT_ERRN_INVDIR        14
    #define COSA_CONTEXT_ERRS_INVDIR        "Not a directory"
    #define COSA_CONTEXT_ERRN_INVARG        15
    #define COSA_CONTEXT_ERRS_INVARG        "Invalid argument"
    #define COSA_CONTEXT_ERRN_INPCIOFDEV    16
    #define COSA_CONTEXT_ERRS_INPCIOFDEV    "Inappropriate ioctl for device"
    #define COSA_CONTEXT_ERRN_BUSYFILE      17
    #define COSA_CONTEXT_ERRS_BUSYFILE      "File busy"
    #define COSA_CONTEXT_ERRN_TOLFILE       18
    #define COSA_CONTEXT_ERRS_TOLFILE       "File too large"
    #define COSA_CONTEXT_ERRN_TOMFILE       19
    #define COSA_CONTEXT_ERRS_TOMFILE       "Too many open files"
    #define COSA_CONTEXT_ERRN_NODEVSP       20
    #define COSA_CONTEXT_ERRS_NODEVSP       "No space left on device"
    #define COSA_CONTEXT_ERRN_ROADDR        21
    #define COSA_CONTEXT_ERRS_ROADDR        "Read-only address"
    #define COSA_CONTEXT_ERRN_WOADDR        22
    #define COSA_CONTEXT_ERRS_WOADDR        "Write-only address"
    #define COSA_CONTEXT_ERRN_BPIPE         23
    #define COSA_CONTEXT_ERRS_BPIPE         "Broken pipe"
    #define COSA_CONTEXT_ERRN_ARGOORNE      24
    #define COSA_CONTEXT_ERRS_ARGOORNE      "Numerical argument out of range"
    #define COSA_CONTEXT_ERRN_RESOORNE      25
    #define COSA_CONTEXT_ERRS_RESOORNE      "Numerical result out of range"
    #define COSA_CONTEXT_ERRN_TOLFILEN      26
    #define COSA_CONTEXT_ERRS_TOLFILEN      "File name too long"
    #define COSA_CONTEXT_ERRN_INVFUNC       27
    #define COSA_CONTEXT_ERRS_INVFUNC       "Function not implemented"
    #define COSA_CONTEXT_ERRN_PTCDVNTATTCH  28
    #define COSA_CONTEXT_ERRS_PTCDVNTATTCH  "Protocol driver not attached"
    #define COSA_CONTEXT_ERRN_INVSLT        29
    #define COSA_CONTEXT_ERRS_INVSLT        "Invalid slot"
    #define COSA_CONTEXT_ERRN_BFONTF        30
    #define COSA_CONTEXT_ERRS_BFONTF        "Bad font file format"
    #define COSA_CONTEXT_ERRN_INVDEV        31
    #define COSA_CONTEXT_ERRS_INVDEV        "Device not a stream"
    #define COSA_CONTEXT_ERRN_NONET         32
    #define COSA_CONTEXT_ERRS_NONET         "Machine is not on the network"
    #define COSA_CONTEXT_ERRN_NOPKG         33
    #define COSA_CONTEXT_ERRS_NOPKG         "Package not installed"
    #define COSA_CONTEXT_ERRN_SCOM          34
    #define COSA_CONTEXT_ERRS_SCOM          "Communication error on send"
    #define COSA_CONTEXT_ERRN_PTC           35
    #define COSA_CONTEXT_ERRS_PTC           "Protocol error"
    #define COSA_CONTEXT_ERRN_BMSG          36
    #define COSA_CONTEXT_ERRS_BMSG          "Bad message"
    #define COSA_CONTEXT_ERRN_VALOVFLW      37
    #define COSA_CONTEXT_ERRS_VALOVFLW      "Value too large for defined data type"
    #define COSA_CONTEXT_ERRN_NOUQNETNM     38
    #define COSA_CONTEXT_ERRS_NOUQNETNM     "Name not unique on network"
    #define COSA_CONTEXT_ERRN_BFDS          39
    #define COSA_CONTEXT_ERRS_BFDS          "File descriptor in bad state"
    #define COSA_CONTEXT_ERRN_CRTEADDR      40
    #define COSA_CONTEXT_ERRS_CRTEADDR      "Remote address changed"
    #define COSA_CONTEXT_ERRN_LIBACC        41
    #define COSA_CONTEXT_ERRS_LIBACC        "Can not access a needed shared library"
    #define COSA_CONTEXT_ERRN_LIBBAD        42
    #define COSA_CONTEXT_ERRS_LIBBAD        "Accessing a corrupted shared library"
    #define COSA_CONTEXT_ERRN_LIBSCN        43
    #define COSA_CONTEXT_ERRS_LIBSCN        ".lib section in a.out corrupted"
    #define COSA_CONTEXT_ERRN_LIBMAX        44
    #define COSA_CONTEXT_ERRS_LIBMAX        "Attempting to link in too many shared libraries"
    #define COSA_CONTEXT_ERRN_LIBEXE        45
    #define COSA_CONTEXT_ERRS_LIBEXE        "Cannot exec a shared library directly"
    #define COSA_CONTEXT_ERRN_INVWCHR       46
    #define COSA_CONTEXT_ERRS_INVWCHR       "Invalid or incomplete multibyte or wide character"
    #define COSA_CONTEXT_ERRN_INTRRST       47
    #define COSA_CONTEXT_ERRS_INTRRST       "Interrupted system call should be restarted"
    #define COSA_CONTEXT_ERRN_STRPIP        48
    #define COSA_CONTEXT_ERRS_STRPIP        "Streams pipe error"
    #define COSA_CONTEXT_ERRN_INVSOCK       49
    #define COSA_CONTEXT_ERRS_INVSOCK       "Socket operation on non-socket"
    #define COSA_CONTEXT_ERRN_RQDSTADDR     50
    #define COSA_CONTEXT_ERRS_RQDSTADDR     "Destination address required"
    #define COSA_CONTEXT_ERRN_TOLMSG        51
    #define COSA_CONTEXT_ERRS_TOLMSG        "Message too long"
    #define COSA_CONTEXT_ERRN_INVPTCTSOCK   52
    #define COSA_CONTEXT_ERRS_INVPTCTSOCK   "Protocol wrong type for socket"
    #define COSA_CONTEXT_ERRN_NOPTCAVL      53
    #define COSA_CONTEXT_ERRS_NOPTCAVL      "Protocol not available"
    #define COSA_CONTEXT_ERRN_NOPTCSUP      54
    #define COSA_CONTEXT_ERRS_NOPTCSUP      "Protocol not supported"
    #define COSA_CONTEXT_ERRN_NOSOCKTSUP    55
    #define COSA_CONTEXT_ERRS_NOSOCKTSUP    "Socket type not supported"
    #define COSA_CONTEXT_ERRN_NOOPSUP       56
    #define COSA_CONTEXT_ERRS_NOOPSUP       "Operation not supported"
    #define COSA_CONTEXT_ERRN_NOPTCFSUP     57
    #define COSA_CONTEXT_ERRS_NOPTCFSUP     "Protocol family not supported"
    #define COSA_CONTEXT_ERRN_PTCNOADDRFSUP 58
    #define COSA_CONTEXT_ERRS_PTCNOADDRFSUP "Address family not supported by protocol"
    #define COSA_CONTEXT_ERRN_BUSYADDR      59
    #define COSA_CONTEXT_ERRS_BUSYADDR      "Address already in use"
    #define COSA_CONTEXT_ERRN_RQADDR        60
    #define COSA_CONTEXT_ERRS_RQADDR        "Cannot assign requested address"
    #define COSA_CONTEXT_ERRN_NETDWN        61
    #define COSA_CONTEXT_ERRS_NETDWN        "Network is down"
    #define COSA_CONTEXT_ERRN_NETURCH       62
    #define COSA_CONTEXT_ERRS_NETURCH       "Network is unreachable"
    #define COSA_CONTEXT_ERRN_NETDCONRST    63
    #define COSA_CONTEXT_ERRS_NETDCONRST    "Network dropped connection on reset"
    #define COSA_CONTEXT_ERRN_CONABT        64
    #define COSA_CONTEXT_ERRS_CONABT        "Software caused connection abort"
    #define COSA_CONTEXT_ERRN_CONRST        65
    #define COSA_CONTEXT_ERRS_CONRST        "Connection reset by peer"
    #define COSA_CONTEXT_ERRN_OOBSP         66
    #define COSA_CONTEXT_ERRS_OOBSP         "No buffer space available"
    #define COSA_CONTEXT_ERRN_CONTMO        67
    #define COSA_CONTEXT_ERRS_CONTMO        "Connection timed out"
    #define COSA_CONTEXT_ERRN_CONREF        68
    #define COSA_CONTEXT_ERRS_CONREF        "Connection refused"
    #define COSA_CONTEXT_ERRN_HSTDWN        69
    #define COSA_CONTEXT_ERRS_HSTDWN        "Host is down"
    #define COSA_CONTEXT_ERRN_NORTHST       70
    #define COSA_CONTEXT_ERRS_NORTHST       "No route to host"
    #define COSA_CONTEXT_ERRN_BUSYOP        71
    #define COSA_CONTEXT_ERRS_BUSYOP        "Operation already in progress"
    #define COSA_CONTEXT_ERRN_OPINPROG      72
    #define COSA_CONTEXT_ERRS_OPINPROG      "Operation now in progress"
    #define COSA_CONTEXT_ERRN_SLFILE        73
    #define COSA_CONTEXT_ERRS_SLFILE        "Stale file handle"
    #define COSA_CONTEXT_ERRN_STCTCL        74
    #define COSA_CONTEXT_ERRS_STCTCL        "Structure needs cleaning"
    #define COSA_CONTEXT_ERRN_RTEIO         75
    #define COSA_CONTEXT_ERRS_RTEIO         "Remote I/O error"
    #define COSA_CONTEXT_ERRN_DSKQA         76
    #define COSA_CONTEXT_ERRS_DSKQA         "Disk quota exceeded"
    #define COSA_CONTEXT_ERRN_NOMDIM        77
    #define COSA_CONTEXT_ERRS_NOMDIM        "No medium found"
    #define COSA_CONTEXT_ERRN_INVMDIMT      78
    #define COSA_CONTEXT_ERRS_INVMDIMT      "Wrong medium type"
    #define COSA_CONTEXT_ERRN_OPCLC         79
    #define COSA_CONTEXT_ERRS_OPCLC         "Operation canceled"
    #define COSA_CONTEXT_ERRN_NORQKEY       80
    #define COSA_CONTEXT_ERRS_NORQKEY       "Required key not available"
    #define COSA_CONTEXT_ERRN_KEYEXP        81
    #define COSA_CONTEXT_ERRS_KEYEXP        "Key has expired"
    #define COSA_CONTEXT_ERRN_KEYRVK        82
    #define COSA_CONTEXT_ERRS_KEYRVK        "Key has been revoked"
    #define COSA_CONTEXT_ERRN_KEYRJC        83
    #define COSA_CONTEXT_ERRS_KEYRJC        "Key was rejected by service"
    #define COSA_CONTEXT_ERRN_NORECVRBLESTE 84
    #define COSA_CONTEXT_ERRS_NORECVRBLESTE "State not recoverable"
    #define COSA_CONTEXT_ERRN_MEMPGHW       85
    #define COSA_CONTEXT_ERRS_MEMPGHW       "Memory page has hardware error"
    #define COSA_CONTEXT_ERRN_NODATA        86
    #define COSA_CONTEXT_ERRS_NODATA        "No data available"
    #define COSA_CONTEXT_ERROR_TOP          COSA_CONTEXT_ERRN_NODATA
    #define COSA_CONTEXT_ERROR_CNT          87 /*= (++COSA_CONTEXT_ERROR_TOP)*/
#endif

#if !defined(COSA_CHANGE_BIT_MANIPULATION)
    /*Inverse table:
        0xFE = (~0x01).
        0xFC = (~0x03).
        0xF8 = (~0x07).
        0xF0 = (~0x0F).
        0xE0 = (~0x1F).
        0xC0 = (~0x3F).
        0x80 = (~0x7F).
        0x00 = (~0xFF).
    */

    #define cosaBit1S(var) ((var) |= 0x01) //Set 1 bit to one.
    #define cosaBit2S(var) ((var) |= 0x03) //Set 2 bits to one.
    #define cosaBit3S(var) ((var) |= 0x07) //Set 3 bits to one.
    #define cosaBit4S(var) ((var) |= 0x0F) //Set 4 bits to one.
    #define cosaBit5S(var) ((var) |= 0x1F) //Set 5 bits to one.
    #define cosaBit6S(var) ((var) |= 0x3F) //Set 6 bits to one.
    #define cosaBit7S(var) ((var) |= 0x7F) //Set 7 bits to one.
    #define cosaBit8S(var) ((var) |= 0xFF) //Set 8 bits to one.
    #define cosaBit1S_O(var, offset) ((var) |= (0x01 << (offset))) //Set 1 offsetted bit to one.
    #define cosaBit2S_O(var, offset) ((var) |= (0x03 << (offset))) //Set 2 offsetted bits to one.
    #define cosaBit3S_O(var, offset) ((var) |= (0x07 << (offset))) //Set 3 offsetted bits to one.
    #define cosaBit4S_O(var, offset) ((var) |= (0x0F << (offset))) //Set 4 offsetted bits to one.
    #define cosaBit5S_O(var, offset) ((var) |= (0x1F << (offset))) //Set 5 offsetted bits to one.
    #define cosaBit6S_O(var, offset) ((var) |= (0x3F << (offset))) //Set 6 offsetted bits to one.
    #define cosaBit7S_O(var, offset) ((var) |= (0x7F << (offset))) //Set 7 offsetted bits to one.
    #define cosaBit8S_O(var, offset) ((var) |= (0xFF << (offset))) //Set 8 offsetted bits to one.

    #define cosaBit1C(var) ((var) &= 0xFE) //Set 1 bit to zero.
    #define cosaBit2C(var) ((var) &= 0xFC) //Set 2 bits to zero.
    #define cosaBit3C(var) ((var) &= 0xF8) //Set 3 bits to zero.
    #define cosaBit4C(var) ((var) &= 0xF0) //Set 4 bits to zero.
    #define cosaBit5C(var) ((var) &= 0xE0) //Set 5 bits to zero.
    #define cosaBit6C(var) ((var) &= 0xC0) //Set 6 bits to zero.
    #define cosaBit7C(var) ((var) &= 0x80) //Set 7 bits to zero.
    #define cosaBit8C(var) ((var) &= 0x00) //Set 8 bits to zero.
    #define cosaBit1C_O(var, offset) ((var) &= (~(0x01 << (offset)))) //Set 1 offsetted bit to zero.
    #define cosaBit2C_O(var, offset) ((var) &= (~(0x03 << (offset)))) //Set 2 offsetted bits to zero.
    #define cosaBit3C_O(var, offset) ((var) &= (~(0x07 << (offset)))) //Set 3 offsetted bits to zero.
    #define cosaBit4C_O(var, offset) ((var) &= (~(0x0F << (offset)))) //Set 4 offsetted bits to zero.
    #define cosaBit5C_O(var, offset) ((var) &= (~(0x1F << (offset)))) //Set 5 offsetted bits to zero.
    #define cosaBit6C_O(var, offset) ((var) &= (~(0x3F << (offset)))) //Set 6 offsetted bits to zero.
    #define cosaBit7C_O(var, offset) ((var) &= (~(0x7F << (offset)))) //Set 7 offsetted bits to zero.
    #define cosaBit8C_O(var, offset) ((var) &= (~(0xFF << (offset)))) //Set 8 offsetted bits to zero.

    #define cosaBit1I(var) ((var) ^= 0xFE) //Inverse 1 bit.
    #define cosaBit2I(var) ((var) ^= 0xFC) //Inverse 2 bits.
    #define cosaBit3I(var) ((var) ^= 0xF8) //Inverse 3 bits.
    #define cosaBit4I(var) ((var) ^= 0xF0) //Inverse 4 bits.
    #define cosaBit5I(var) ((var) ^= 0xE0) //Inverse 5 bits.
    #define cosaBit6I(var) ((var) ^= 0xC0) //Inverse 6 bits.
    #define cosaBit7I(var) ((var) ^= 0x80) //Inverse 7 bits.
    #define cosaBit8I(var) ((var) ^= 0x00) //Inverse 8 bits.
    #define cosaBit1I_O(var, offset) ((var) ^= (~(0x01 << (offset)))) //Inverse 1 offsetted bit.
    #define cosaBit2I_O(var, offset) ((var) ^= (~(0x03 << (offset)))) //Inverse 2 offsetted bits.
    #define cosaBit3I_O(var, offset) ((var) ^= (~(0x07 << (offset)))) //Inverse 3 offsetted bits.
    #define cosaBit4I_O(var, offset) ((var) ^= (~(0x0F << (offset)))) //Inverse 4 offsetted bits.
    #define cosaBit5I_O(var, offset) ((var) ^= (~(0x1F << (offset)))) //Inverse 5 offsetted bits.
    #define cosaBit6I_O(var, offset) ((var) ^= (~(0x3F << (offset)))) //Inverse 6 offsetted bits.
    #define cosaBit7I_O(var, offset) ((var) ^= (~(0x7F << (offset)))) //Inverse 7 offsetted bits.
    #define cosaBit8I_O(var, offset) ((var) ^= (~(0xFF << (offset)))) //Inverse 8 offsetted bits.

    #define cosaBit1R(var) ((var) & 0x01) //Read 1 bit.
    #define cosaBit2R(var) ((var) & 0x03) //Read 2 bits.
    #define cosaBit3R(var) ((var) & 0x07) //Read 3 bits.
    #define cosaBit4R(var) ((var) & 0x0F) //Read 4 bits.
    #define cosaBit5R(var) ((var) & 0x1F) //Read 5 bits.
    #define cosaBit6R(var) ((var) & 0x3F) //Read 6 bits.
    #define cosaBit7R(var) ((var) & 0x7F) //Read 7 bits.
    #define cosaBit8R(var) ((var) & 0xFF) //Read 8 bits.
    #define cosaBit1R_O(var, offset) ((var) & (0x01 << (offset))) //Read 1 offsetted bit.
    #define cosaBit2R_O(var, offset) ((var) & (0x03 << (offset))) //Read 2 offsetted bits.
    #define cosaBit3R_O(var, offset) ((var) & (0x07 << (offset))) //Read 3 offsetted bits.
    #define cosaBit4R_O(var, offset) ((var) & (0x0F << (offset))) //Read 4 offsetted bits.
    #define cosaBit5R_O(var, offset) ((var) & (0x1F << (offset))) //Read 5 offsetted bits.
    #define cosaBit6R_O(var, offset) ((var) & (0x3F << (offset))) //Read 6 offsetted bits.
    #define cosaBit7R_O(var, offset) ((var) & (0x7F << (offset))) //Read 7 offsetted bits.
    #define cosaBit8R_O(var, offset) ((var) & (0xFF << (offset))) //Read 8 offsetted bits.

    #define cosaBit1W(var, pattern) ((var) = ((var) & 0xFE) | cosaBit1R(pattern))
    #define cosaBit2W(var, pattern) ((var) = ((var) & 0xFC) | cosaBit2R(pattern))
    #define cosaBit3W(var, pattern) ((var) = ((var) & 0xF8) | cosaBit3R(pattern))
    #define cosaBit4W(var, pattern) ((var) = ((var) & 0xF0) | cosaBit4R(pattern))
    #define cosaBit5W(var, pattern) ((var) = ((var) & 0xE0) | cosaBit5R(pattern))
    #define cosaBit6W(var, pattern) ((var) = ((var) & 0xC0) | cosaBit6R(pattern))
    #define cosaBit7W(var, pattern) ((var) = ((var) & 0x80) | cosaBit7R(pattern))
    #define cosaBit8W(var, pattern) ((var) = ((var) & 0x00) | cosaBit8R(pattern))
    #define cosaBit1W_O(var, offset, pattern) ((var) = ((var) & (~(0x01 << (offset)))) | cosaBit1R_O(pattern, offset))
    #define cosaBit2W_O(var, offset, pattern) ((var) = ((var) & (~(0x03 << (offset)))) | cosaBit2R_O(pattern, offset))
    #define cosaBit3W_O(var, offset, pattern) ((var) = ((var) & (~(0x07 << (offset)))) | cosaBit3R_O(pattern, offset))
    #define cosaBit4W_O(var, offset, pattern) ((var) = ((var) & (~(0x0F << (offset)))) | cosaBit4R_O(pattern, offset))
    #define cosaBit5W_O(var, offset, pattern) ((var) = ((var) & (~(0x1F << (offset)))) | cosaBit5R_O(pattern, offset))
    #define cosaBit6W_O(var, offset, pattern) ((var) = ((var) & (~(0x3F << (offset)))) | cosaBit6R_O(pattern, offset))
    #define cosaBit7W_O(var, offset, pattern) ((var) = ((var) & (~(0x7F << (offset)))) | cosaBit7R_O(pattern, offset))
    #define cosaBit8W_O(var, offset, pattern) ((var) = ((var) & (~(0xFF << (offset)))) | cosaBit8R_O(pattern, offset))

    #define cosaBitPR(var, pattern) ((var) & (pattern)) //Read pattern.
    #define cosaBitPR_O(var, offset, pattern) ((var) & ((pattern) << (offset))) //Read offsetted pattern.

    /*
        Copy specific bits from 'src' into 'dest' that are specified with one's in 'pattern':

        0
    */
    #define cosaBitPC(src, dest, pattern) (((src) & (pattern)) | ((dest) & (~(pattern))))

    /*
        Copy specific bits from 'src' into 'dest' that are specified with zero's in 'pattern':

        0
    */
    #define cosaBitPCI(src, dest, pattern) (((src) & (~(pattern))) | ((dest) & (pattern)))

    /*
        Swap bits in 'var' at 'x' and 'y' respectively from a index of zero, 'buff' must be a type of 'cosaU*' with the respetive max range of 'x' and 'y' or more as '*':

        0
    */
    #define cosaBitSWP(var, buff, x, y) \
        (buff) = ((((var) >> (x)) ^ ((var) >> (y))) & 1);\
        (var) ^= ((buff) << (x)) | ((buff) << (y));

    #define cosaBitILSO(var) ((var) &= ((var) - 1)) //Invert the first least significant bit that's one, hence setting it to zero.

    /*
        Counts the number of bits bits in 'var' that are one, 'i' must be a type of 'cosaU*' with the max bit range of 'var' or more as '*':

        0
    */
    #define cosaBitCO(var, i) (while ((var) != 0) { cosaBitILSO(var); ++i; })

    #define cosaBitCOP(var) ((((var) & 1) + cosaBitCO(((var) ^ ((var) >> 1)))) / 2)
#endif

#if !defined(COSA_CHANGE_LOGIC)
    /*! @brief Tells the Compiler that the condition is Unlikely.

        @note Should only be used on `ERROR/ARG` checks that gets regularly checked.
        For example:
            Is the given `Ptr` NULL?
            Is the given `Num` in the expected `A->B` range?
    */
    #define cosaCUnlikely(x) __builtin_expect(!!(x), 0)

    #define cosaBCount(buff) (sizeof(buff)/sizeof(*buff)) //Get the element count of buffer.

    /*! @brief If signed `A` is negative, format signed `A` into a unsigned `A` using the two's complement.
        @note The argument `A` cannot be a float, double nor long double.
    */
    #define cosaStoU(A) ((A < 0) ? (~A) + 1 : A)
#endif

#if !defined(COSA_CHANGE_PRINT)
    #define cosaPrint(str) (void)puts(str)
    #define cosaPrintF (void)printf
#endif

#if !defined(COSA_CHANGE_OPERATIONS)
    //#define COSA_OPERATIONS_USE_STANDARD
    //#define COSA_OPERATIONS_SKIP_CONTEXT_CHECK
    //#define COSA_OPERATIONS_SKIP_ALL_CHECK
#endif

#if !defined(COSA_CHANGE_MEMORY)
    #define COSA_MEM_FLAGS_DEFAULT 0x00
    
    #define COSA_MEM_FLAGS_FREED 0x01
    #define COSA_MEM_FLAGS_LINKED 0x02
#endif

#if !defined(COSA_CHANGE_MEMORY_SIZES)
    #define cosaBTKB(count) (count/1024)
    #define cosaBTMB(count) (count/1048576)
    #define cosaBTGB(count) (count/1073741824)
    #define cosaBTTB(count) (count/1099511627776)

    #define cosaKBTMB(count) (count/1024)
    #define cosaKBTGB(count) (count/1048576)
    #define cosaKBTTB(count) (count/1073741824)
    #define cosaKBTPB(count) (count/1099511627776)

    #define cosaMBTGB(count) (count/1024)
    #define cosaMBTTB(count) (count/1048576)
    #define cosaMBTPB(count) (count/1073741824)
    #define cosaMBTEB(count) (count/1099511627776)

    #define cosaGBTTB(count) (count/1024)
    #define cosaGBTPB(count) (count/1048576)
    #define cosaGBTEB(count) (count/1073741824)
    #define cosaGBTZB(count) (count/1099511627776)

    #define cosaTBTPB(count) (count/1024)
    #define cosaTBTEB(count) (count/1048576)
    #define cosaTBTZB(count) (count/1073741824)
    #define cosaTBTYB(count) (count/1099511627776)

    #define cosaPBTEB(count) (count/1024)
    #define cosaPBTZB(count) (count/1048576)
    #define cosaPBTYB(count) (count/1073741824)

    #define cosaEBTZB(count) (count/1024)
    #define cosaEBTYB(count) (count/1048576)

    #define cosaZBTYB(count) (count/1024)


    #define cosaKBTB(count) (count*1024)
    #define cosaMBTB(count) (count*1048576)
    #define cosaGBTB(count) (count*1073741824)
    #define cosaTBTB(count) (count*1099511627776)

    #define cosaMBTKB(count) (count*1024)
    #define cosaGBTKB(count) (count*1048576)
    #define cosaTBTKB(count) (count*1073741824)
    #define cosaPBTKB(count) (count*1099511627776)

    #define cosaGBTMB(count) (count*1024)
    #define cosaTBTMB(count) (count*1048576)
    #define cosaPBTMB(count) (count*1073741824)
    #define cosaEBTMB(count) (count*1099511627776)

    #define cosaTBTGB(count) (count*1024)
    #define cosaPBTGB(count) (count*1048576)
    #define cosaEBTGB(count) (count*1073741824)
    #define cosaZBTGB(count) (count*1099511627776)

    #define cosaPBTTB(count) (count*1024)
    #define cosaEBTTB(count) (count*1048576)
    #define cosaZBTTB(count) (count*1073741824)
    #define cosaYBTTB(count) (count*1099511627776)

    #define cosaEBTPB(count) (count*1024)
    #define cosaZBTPB(count) (count*1048576)
    #define cosaYBTPB(count) (count*1073741824)

    #define cosaZBTEB(count) (count*1024)
    #define cosaYBTEB(count) (count*1048576)

    #define cosaYBTZB(count) (count*1024)
#endif

#if !defined(COSA_CHANGE_STACK)
    #define COSA_STACK_SX_EXPAND 8
    #define COSA_STACK_DX_EXPAND 8
    
    #define COSA_STACK_TYPE_SS 0x00 //`TS:00` -> Type:Static  Size:Static.
    #define COSA_STACK_TYPE_SD 0x01 //`TS:01` -> Type:Static  Size:Dynamic.
    #define COSA_STACK_TYPE_DS 0x02 //`TS:10` -> Type:Dynamic Size:Static.
    #define COSA_STACK_TYPE_DD 0x03 //`TS:11` -> Type:Dynamic Size:Dynamic.

    //#define cosaStackMD_Mem(pStack, stackTypeSize) ((cosaU8*)((pStack)->addr + stackTypeSize))
    #define cosaStackMD(pStack, t) ((cosaStackMD_##t##X*)(pStack)->addr)
    #define cosaStackMD_Mem(pStack, t) (((cosaU8*)(pStack)->addr) + sizeof(cosaStackMD_##t##X))
#endif

#if !defined(COSA_CHANGE_QUEUE)
    #define COSA_QUEUE_EXPAND 8

    #define cosaQueueMD(pQueue) ((cosaQueueMD*)(pQueue)->addr)
    #define cosaQueueMD_Mem(pQueue) (((cosaU8*)(pQueue)->addr) + sizeof(cosaQueueMD))
#endif

#if !defined(COSA_CHANGE_FILE)
    #define COSA_FILE_FLAG_PERM_RD 0x0001
    #define COSA_FILE_FLAG_PERM_WE 0x0002
    #define COSA_FILE_FLAG_PERM_RW 0x0003 //COSA_FILE_FLAG_PERM_RD | COSA_FILE_FLAG_PERM_WE
    #define COSA_FILE_FLAG_IS_LINK 0x0004
    #define COSA_FILE_FLAG_IS_DIRE 0x0008
    #define COSA_FILE_FLAG_UPRM_RD 0x0010
    #define COSA_FILE_FLAG_UPRM_WE 0x0020
    #define COSA_FILE_FLAG_UPRM_EX 0x0040
    #define COSA_FILE_FLAG_GPRM_RD 0x0080
    #define COSA_FILE_FLAG_GPRM_WE 0x0100
    #define COSA_FILE_FLAG_GPRM_EX 0x0200
    #define COSA_FILE_FLAG_OPRM_RD 0x0400
    #define COSA_FILE_FLAG_OPRM_WE 0x0800
    #define COSA_FILE_FLAG_OPRM_EX 0x1000
    #define COSA_FILE_FLAG_SET_UID 0x2000
    #define COSA_FILE_FLAG_SET_GID 0x4000
    #define COSA_FILE_FLAG_LOAD_FINFO 0x8000

    #define cosaFileGetF_FPerm(fileFlags) cosaBit2R((fileFlags))
    #define cosaFileGetF_FType(fileFlags) cosaBit2R((fileFlags) >> 2)
    #define cosaFileGetF_FUPrm(fileFlags) cosaBit3R((fileFlags) >> 4)
    #define cosaFileGetF_FGPrm(fileFlags) cosaBit3R((fileFlags) >> 7)
    #define cosaFileGetF_FOPrm(fileFlags) cosaBit3R((fileFlags) >> 10)
    #define cosaFileGetF_FSeID(fileFlags) cosaBit2R((fileFlags) >> 13)

    #define COSA_FINFO_PERM_NE 0x00
    #define COSA_FINFO_PERM_WE 0x01
    #define COSA_FINFO_PERM_RD 0x02
    #define COSA_FINFO_PERM_RW 0x03
    #define COSA_FINFO_TYPE_NFIL 0x00
    #define COSA_FINFO_TYPE_LFIL 0x01
    #define COSA_FINFO_TYPE_NDIR 0x02
    #define COSA_FINFO_TYPE_LDIR 0x03
    #define COSA_FINFO_FPRM_NNN 0x00
    #define COSA_FINFO_FPRM_RNN 0x01
    #define COSA_FINFO_FPRM_NWN 0x02
    #define COSA_FINFO_FPRM_NNX 0x04
    #define COSA_FINFO_FPRM_RWN 0x03
    #define COSA_FINFO_FPRM_RNX 0x05
    #define COSA_FINFO_FPRM_NWX 0x06
    #define COSA_FINFO_FPRM_RWX 0x07
    #define COSA_FINFO_SetID_NN 0x00
    #define COSA_FINFO_SetID_GN 0x01
    #define COSA_FINFO_SetID_NU 0x02
    #define COSA_FINFO_SetID_GU 0x03
#endif

#if !defined(COSA_CHANGE_IMAGE)
#endif

//Extensions.
#if defined(COSA_ENABLE_EXTENSIONS)
#endif

#endif