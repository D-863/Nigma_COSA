#ifndef NIGMA_COSA_TYPEMDS_H
#define NIGMA_COSA_TYPEMDS_H

#include "compilics.h"

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV0) {
    cosaBool isBigEndian;
    cosaU8 minFDs;
    cosaU8 maxFDs;
} _SysInfo_LV0;

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV1) {
    cosaBool isBigEndian;
    cosaU16 minFDs;
    cosaU16 maxFDs;
} _SysInfo_LV1;

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV2) {
    cosaBool isBigEndian;
    cosaU32 minFDs;
    cosaU32 maxFDs;
} _SysInfo_LV2;

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV3) {
    cosaBool isBigEndian;
    cosaU64 minFDs;
    cosaU64 maxFDs;
} _SysInfo_LV3;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV0) {
    cosaU8 freedCount;
    cosaU8 freedTop;
    cosaU8 blockCount;
    cosaU8 blockTop;
    cosaU8 linkCount;
    cosaU8 linkTop;
    cosaU8 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV0;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV1) {
    cosaU16 freedCount;
    cosaU16 freedTop;
    cosaU16 blockCount;
    cosaU16 blockTop;
    cosaU16 linkCount;
    cosaU16 linkTop;
    cosaU16 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV1;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV2) {
    cosaU32 freedCount;
    cosaU32 freedTop;
    cosaU32 blockCount;
    cosaU32 blockTop;
    cosaU32 linkCount;
    cosaU32 linkTop;
    cosaU32 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV2;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV3) {
    cosaU64 freedCount;
    cosaU64 freedTop;
    cosaU64 blockCount;
    cosaU64 blockTop;
    cosaU64 linkCount;
    cosaU64 linkTop;
    cosaU64 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV3;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV0) {
    cosaU8 freedCount;
    cosaU8 freedTop;
    cosaU8 dictionariesCount;
    cosaU8 dictionariesTop;
    cosaU8 *pFreed;
    cosaDictionary *pDictionaries;
} _StrPage_LV0;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV1) {
    cosaU16 freedCount;
    cosaU16 freedTop;
    cosaU16 dictionariesCount;
    cosaU16 dictionariesTop;
    cosaU16 *pFreed;
    cosaDictionary *pDictionaries;
} _StrPage_LV1;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV2) {
    cosaU32 freedCount;
    cosaU32 freedTop;
    cosaU32 dictionariesCount;
    cosaU32 dictionariesTop;
    cosaU32 *pFreed;
    cosaDictionary *pDictionaries;
} _StrPage_LV2;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV3) {
    cosaU64 freedCount;
    cosaU64 freedTop;
    cosaU64 dictionariesCount;
    cosaU64 dictionariesTop;
    cosaU64 *pFreed;
    cosaDictionary *pDictionaries;
} _StrPage_LV3;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV0) {
    cosaU8 finfoCount;
    cosaU8 finfoTop;
    cosaU8 fileCount;
    cosaU8 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV0;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV1) {
    cosaU16 finfoCount;
    cosaU16 finfoTop;
    cosaU16 fileCount;
    cosaU16 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV1;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV2) {
    cosaU32 finfoCount;
    cosaU32 finfoTop;
    cosaU32 fileCount;
    cosaU32 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV2;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV3) {
    cosaU64 finfoCount;
    cosaU64 finfoTop;
    cosaU64 fileCount;
    cosaU64 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV3;

typedef union cosaCompilifics(PACK, X, cosaInputMap) {
    cosaU8 data[COSA_INPUTMAP_SIZE];
    struct COSA_INPUTMAP_MAP map;
} cosaInputMap;

typedef struct cosaCompilifics(PACK, X, cosaMDPage_LV0) {
    cosaU8 count;
    cosaU8 top;
    void *pData;
    void *pMap;
} cosaMDPage_LV0;

typedef struct cosaCompilifics(PACK, X, cosaMDPage_LV1) {
    cosaU16 count;
    cosaU16 top;
    void *pData;
    void *pMap;
} cosaMDPage_LV1;

typedef struct cosaCompilifics(PACK, X, cosaMDPage_LV2) {
    cosaU32 count;
    cosaU32 top;
    void *pData;
    void *pMap;
} cosaMDPage_LV2;

typedef struct cosaCompilifics(PACK, X, cosaMDPage_LV3) {
    cosaU64 count;
    cosaU64 top;
    void *pData;
    void *pMap;
} cosaMDPage_LV3;

typedef struct cosaCompilifics(PACK, X, cosaMDPages) {
    cosaU64 pageCount;
    cosaU8 *pDataLevels;
    void **pPages;
} cosaMDPages;

typedef struct cosaCompilifics(PACK, X, cosaMDSystem) {
    cosaInputMap input;
    cosaMDPages pages;
    void *pSysInfo;
} cosaMDSystem;

typedef struct cosaCompilifics(PACK, X, cosaStackMD_SX) {
    cosaU32 top:32;
    cosaU32 bSize:32;
    cosaU8 type:8;
} cosaStackMD_SX;

typedef struct cosaCompilifics(PACK, X, cosaStackMD_DX) {
    cosaU32 top:32;
    cosaU8 type:8;
} cosaStackMD_DX;

typedef struct cosaCompilifics(PACK, X, cosaQueueMD) {
    cosaU32 back:32;
    cosaU32 front:32;
    cosaU32 count:32;
    cosaU32 bSize:32;
} cosaQueueMD;

#endif