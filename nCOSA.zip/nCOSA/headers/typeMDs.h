#ifndef NIGMA_COSA_TYPEMDS_H
#define NIGMA_COSA_TYPEMDS_H

#include "compilics.h"

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV0) {
    cosaBool isBigEndian;
    cosaU8 minFDs;
    cosaU8 maxFDs;
} _SysInfo_LV0;

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV1) {
    cosaBool isBigEndian;
    cosaU16 minFDs;
    cosaU16 maxFDs;
} _SysInfo_LV1;

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV2) {
    cosaBool isBigEndian;
    cosaU32 minFDs;
    cosaU32 maxFDs;
} _SysInfo_LV2;

typedef struct cosaCompilifics(PACK, X, _SysInfo_LV3) {
    cosaBool isBigEndian;
    cosaU64 minFDs;
    cosaU64 maxFDs;
} _SysInfo_LV3;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV0) {
    cosaU8 freedCount;
    cosaU8 blockCount;
    cosaU8 linkCount;
    cosaU8 freedTop;
    cosaU8 blockTop;
    cosaU8 linkTop;
    cosaU8 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV0;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV1) {
    cosaU16 freedCount;
    cosaU16 blockCount;
    cosaU16 linkCount;
    cosaU16 freedTop;
    cosaU16 blockTop;
    cosaU16 linkTop;
    cosaU16 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV1;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV2) {
    cosaU32 freedCount;
    cosaU32 blockCount;
    cosaU32 linkCount;
    cosaU32 freedTop;
    cosaU32 blockTop;
    cosaU32 linkTop;
    cosaU32 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV2;

typedef struct cosaCompilifics(PACK, X, _MemPage_LV3) {
    cosaU64 freedCount;
    cosaU64 blockCount;
    cosaU64 linkCount;
    cosaU64 freedTop;
    cosaU64 blockTop;
    cosaU64 linkTop;
    cosaU64 *pFreed;
    cosaBlock *pBlocks;
    cosaBlockLink *pLinks;
} _MemPage_LV3;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV0) {
    cosaU8 dictionaryCount;
    cosaU8 dictionaryTop;
    cosaDictionary *pDictionary;
} _StrPage_LV0;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV1) {
    cosaU16 dictionaryCount;
    cosaU16 dictionaryTop;
    cosaDictionary *pDictionary;
} _StrPage_LV1;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV2) {
    cosaU32 dictionaryCount;
    cosaU32 dictionaryTop;
    cosaDictionary *pDictionary;
} _StrPage_LV2;

typedef struct cosaCompilifics(PACK, X, _StrPage_LV3) {
    cosaU64 dictionaryCount;
    cosaU64 dictionaryTop;
    cosaDictionary *pDictionary;
} _StrPage_LV3;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV0) {
    cosaU8 finfoCount;
    cosaU8 fileCount;
    cosaU8 finfoTop;
    cosaU8 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV0;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV1) {
    cosaU16 finfoCount;
    cosaU16 fileCount;
    cosaU16 finfoTop;
    cosaU16 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV1;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV2) {
    cosaU32 finfoCount;
    cosaU32 fileCount;
    cosaU32 finfoTop;
    cosaU32 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV2;

typedef struct cosaCompilifics(PACK, X, _FilePage_LV3) {
    cosaU64 finfoCount;
    cosaU64 fileCount;
    cosaU64 finfoTop;
    cosaU64 fileTop;
    cosaFInfo *pFInfos;
    cosaFile *pFiles;
} _FilePage_LV3;

typedef union cosaCompilifics(PACK, X, _DataLevels) {
    cosaU8 data[1];
    struct {
        cosaU8 sysInfo:2;
        cosaU8 memPage:2;
        cosaU8 strPage:2;
        cosaU8 filePage:2;
    } levels;
} _DataLevels;

typedef union cosaCompilifics(PACK, X, _InputMap) {
    cosaU8 data[COSA_INPUTMAP_SIZE];
    struct COSA_INPUTMAP_MAP map;
} _InputMap;

typedef struct cosaCompilifics(PACK, X, cosaMDSystem) {
    _DataLevels dataLevels;
    _InputMap input;
    COSA_SYSINFO_TYPE *pSysInfo;
    COSA_MEMPAGE_TYPE *pMemPage;
    COSA_STRPAGE_TYPE *pStrPage;
    COSA_FILEPAGE_TYPE *pFilePage;
} cosaMDSystem;

typedef struct cosaCompilifics(PACK, X, cosaStackMD_SX) {
    cosaU32 top:32;
    cosaU32 bSize:32;
    cosaU8 type:8;
} cosaStackMD_SX;

typedef struct cosaCompilifics(PACK, X, cosaStackMD_DX) {
    cosaU32 top:32;
    cosaU8 type:8;
} cosaStackMD_DX;

typedef union cosaCompilifics(PACK, X, cosaDictionary_SectorMD) {
    cosaU32 data;
    struct {
        cosaU8 id:8;
        cosaU32 offset:24;
    } map;
} cosaDictionary_SectorMD;

typedef struct cosaCompilifics(PACK, X, cosaQueueMD) {
    cosaU32 back:32;
    cosaU32 front:32;
    cosaU32 count:32;
    cosaU32 bSize:32;
} cosaQueueMD;

#endif