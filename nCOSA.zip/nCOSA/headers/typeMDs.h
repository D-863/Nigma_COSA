#ifndef NIGMA_COSA_TYPEMDS_H
#define NIGMA_COSA_TYPEMDS_H

#include "utilities.h"
#include "types.h"

typedef struct __attribute__((packed)) cosaStackMD_XS {
    cosaU32 top:32;
    cosaU32 bSize:32;
    cosaU8 type:8;
} cosaStackMD_XS;

typedef struct __attribute__((packed)) cosaStackMD_XD {
    cosaU32 top:32;
    cosaU8 type:8;
} cosaStackMD_XD;

typedef struct __attribute__((packed)) cosaStackMD_XB {
    cosaU32 top:32;
    cosaU8 type:8;
    cosaU8 bSizeCount:8;
    cosaU8 bSizeIndex:8;
} cosaStackMD_XB;

typedef struct cosaBlockPage {
    cosaUSize freedCount;
    cosaUSize blockCount;
    cosaUSize linkCount;
    cosaUSize freedTop;
    cosaUSize blockTop;
    cosaUSize linkTop;
    cosaUSize *pFreed;
    cosaMemBlock *pBlocks;
    cosaLinkBlock *pLinks;
} cosaBlockPage;

typedef struct cosaFilePage {
    cosaU32 count;
    cosaFile *pFiles;
} cosaFilePage;

typedef struct _SystemInfo {
    cosaBool isBigEndian;
    _CosaSI_LT maxFDs;
} _SystemInfo;

typedef union _InputMap {
    cosaU8 data[COSA_INPUTMAP_SIZE];
    struct COSA_INPUTMAP_MAPPING mapping;
} _InputMap;

typedef struct _CosaMD {
    _SystemInfo systemInfo;
    _InputMap inputMap;

#if defined(COSA_ENABLE_EXTENSIONS)
    cosaMemBlock *pSExtensions;
#endif
} _CosaMD;

typedef struct cosaContext {
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaFilePage filePage;
    _CosaMD *pCosaMD;
    cosaChar *errorMSG;
} cosaContext;

#if defined(COSA_ENABLE_EXTENSIONS)
typedef struct _CosaExtension {
    cosaU8 ID;
    cosaMemBlock *pBlock;
    void (*pCleanup)(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock);
} _CosaExtension;
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    typedef struct _cosaGLFW_EXT {
        cosaBool isInitialized;
        cosaU32 monitorCount;
        cosaU32 panelTop;
        GLFWmonitor **pBMonitors;
        cosaMemBlock *pBPanels;
    } _cosaGLFW_EXT;

    typedef struct cosaPanel_GLFW {
        GLFWimage icon;
        GLFWwindow *pWindow;
        GLFWmonitor *pMonitor;
    } cosaPanel_GLFW;
#endif

#endif