#ifndef NIGMA_COSA_TYPES_H
#define NIGMA_COSA_TYPES_H

#include "utilities.h"

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaLinkBlock {
    cosaUSize blockSlot;
    cosaMemBlock **ppBlockLink;
} cosaLinkBlock;

typedef struct cosaFile {
    /*
        |RSVD|t,isL|gID,uID,oth,grp,usr|R,W|
        |0,  |0,0  |0,  0,  000,000,000|0,0|
    */
    cosaU16 flags;
    cosaI32 desc;
    cosaFInfo info;
    cosaMemBlock *pBData;
} cosaFile;

typedef struct cosaImage {
    cosaU8 type;
    cosaU32 width;
    cosaU32 height;
    cosaU32 channels;
    cosaFile *pFile;
    cosaU8 *pData;
} cosaImage;

typedef struct cosaPanel {
    cosaU16 flags;
    cosaU32 width;
    cosaU32 height;
    cosaU32 color; //{cR:8, cG:8, cB:8, cA:8}
    cosaI32 posX;
    cosaI32 posY;
    cosaChar *pTitle;
    cosaChar *pIconPath;
    cosaMemBlock *pBlock;
} cosaPanel;

#endif