#ifndef NIGMA_COSA_TYPES_H
#define NIGMA_COSA_TYPES_H

#include "utilities.h"

typedef struct cosaBlock {
    cosaU8 flags;
    cosaU16 byteSize;
    cosaUSize count;
    void *addr;
} cosaBlock;

typedef struct cosaBlockLink {
    cosaUSize blockSlot;
    cosaBlock **ppBAddr;
} cosaBlockLink;

typedef struct cosaString {
    cosaU8 flags;
    cosaU32 length;
    cosaU32 bitSize;
    cosaU32 id;
} cosaString;

typedef struct cosaFInfo {
    cosaU32 UID;
    cosaU32 GID;
    cosaU64 aTime;
    cosaU64 mTime;
    cosaU64 sTime;
} cosaFInfo;

typedef struct cosaFile {
    /*
        |SUID,SGID|OX,OW,OR|GX,GW,GR|UX,UW,UR|t,isL|W,R|
        |x,   x   |x, x, x |x, x, x |x, x, x |x,x  |x,x|
    */
    cosaU16 flags;
    cosaUSize size;
    cosaU64 key;
    cosaChar *pPath;
    cosaFInfo *pFInfo;
    cosaBlock *pBData;
} cosaFile;

#include "typeMDs.h"

typedef struct cosaContext {
    cosaU8 errorNUM;
    cosaMDSystem systemMD;
    cosaChar *errorMSG;
    void (*errorFUNC)(COSA_ERROR_FUNC_ARGS);
} cosaContext;

#endif