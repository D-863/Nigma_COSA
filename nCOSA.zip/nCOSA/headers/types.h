#ifndef NIGMA_COSA_TYPES_H
#define NIGMA_COSA_TYPES_H

#include "utilities.h"

typedef struct cosaBlock {
    cosaU8 flags;
    cosaU16 byteSize;
    cosaUSize count;
    void *addr;
} cosaBlock;

typedef struct cosaBlockLink {
    cosaUSize blockSlot;
    cosaBlock **ppBAddr;
} cosaBlockLink;

typedef struct cosaString {
    cosaU8 flags;
    cosaU16 length; //By area, ~63.999KB alone can hold ~9.4567 sheets of A4 paper, assuming each character is x:3mm by y:3mm without any spacing.. "(((2 ^ 16) - 1) * 9) / (210 * 297)"
    cosaU32 bitSize;
    cosaU64 id;
} cosaString;

typedef struct cosaStringLink {
    cosaUSize id;
    cosaBlock **ppBAddr;
} cosaStringLink;

typedef struct cosaFInfo {
    cosaU32 uid;
    cosaU32 gid;
    cosaU64 atime;
    cosaU64 mtime;
    cosaU64 stime;
} cosaFInfo;

typedef struct cosaFile {
    /*
        |SUID,SGID|OX,OW,OR|GX,GW,GR|UX,UW,UR|t,isL|W,R|
        |x,   x   |x, x, x |x, x, x |x, x, x |x,x  |x,x|
    */
    cosaU16 flags;
    cosaUSize size;
    cosaU64 key;
    cosaString *sPath;
    cosaFInfo *pFInfo;
    cosaBlock *pBData;
} cosaFile;

#include "typeMDs.h"

typedef struct cosaContext {
    cosaU8 errorNUM;
    cosaMDSystem systemMD;
    cosaChar *errorMSG;
    void (*errorFUNC)(COSA_ERROR_FUNC_ARGS);
} cosaContext;

#endif