#ifndef NIGMA_COSA_TYPES_H
#define NIGMA_COSA_TYPES_H

#include "utilities.h"

typedef struct cosaBlock {
    cosaU8 flags;
    cosaU16 byteSize;
    cosaUSize count;
    void *addr;
} cosaBlock;

typedef struct cosaBlockLink {
    cosaUSize blockSlot;
    cosaBlock **ppBAddr;
} cosaBlockLink;

#include "typeMDs.h"

typedef struct cosaContext {
    cosaU8 errorNUM;
    cosaMDSystem systemMD;
    cosaChar *errorMSG;
    void (*errorFUNC)(COSA_ERROR_FUNC_ARGS);
} cosaContext;

#endif