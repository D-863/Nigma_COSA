#ifndef NIGMA_COSA_MATH_H
#define NIGMA_COSA_MATH_H

#endif
