#ifndef NIGMA_COSA_MATH_H
#define NIGMA_COSA_MATH_H

#include "utilities.h"

typedef cosaFloat cosaV2[2];
typedef cosaFloat cosaV3[3];
typedef cosaFloat cosaV4[4];

typedef cosaV2 cosaM2[2];
typedef cosaV3 cosaM3[3];
typedef cosaV4 cosaM4[4];

void cosaV2AddV2_Dest(cosaV2 vA, cosaV2 vB, cosaV2 vDest) {
    vDest[0] = vA[0] + vB[0];
    vDest[1] = vA[1] + vB[1];
}

void cosaV2SubV2_Dest(cosaV2 vA, cosaV2 vB, cosaV2 vDest) {
    vDest[0] = vA[0] - vB[0];
    vDest[1] = vA[1] - vB[1];
}



void cosaM2MulV2_Dest(cosaM2 M, cosaV2 V, cosaV2 C) {
    C[0] = (M[0][0] * V[0]) + (M[0][1] * V[1]);
    C[1] = (M[1][0] * V[0]) + (M[1][1] * V[1]);
}

void cosaM2MulV2(cosaM2 M, cosaV2 V) {
    cosaV2 C = {V[0], V[1]};
    V[0] = (M[0][0] * C[0]) + (M[0][1] * C[1]);
    V[1] = (M[1][0] * C[0]) + (M[1][1] * C[1]);
}

void cosaM2AddM2_Dest(cosaM2 A, cosaM2 B, cosaM2 C) {
    C[0][0] = A[0][0] + B[0][0];
    C[0][1] = A[0][1] + B[0][1];
    C[1][0] = A[1][0] + B[1][0];
    C[1][1] = A[1][1] + B[1][1];
}

void cosaM2AddM2(cosaM2 A, cosaM2 B) {
    A[0][0] += B[0][0];
    A[0][1] += B[0][1];
    A[1][0] += B[1][0];
    A[1][1] += B[1][1];
}

//A * B = C
void cosaM2MulM2_Dest(cosaM2 A, cosaM2 B, cosaM2 C) {
    //C=X,R=Y
    //mC[i][j] = mA[i][C] & mB[C][j]
    C[0][0] = (A[0][0] * B[0][0]) + (A[0][1] * B[1][0]);
    C[0][1] = (A[0][0] * B[0][1]) + (A[0][1] * B[1][1]);

    C[1][0] = (A[1][0] * B[0][0]) + (A[1][1] * B[1][0]);
    C[1][1] = (A[1][0] * B[0][1]) + (A[1][1] * B[1][1]);
}

void cosaM2MulM2(cosaM2 A, cosaM2 B) {
    //C=X,R=Y
    //mC[i][j] = mA[i][C] & mB[C][j]
    cosaM2 C = {
        {A[0][0], A[0][1]},
        {A[1][0], A[1][1]}
    };
    A[0][0] = (C[0][0] * B[0][0]) + (C[0][1] * B[1][0]);
    A[0][1] = (C[0][0] * B[0][1]) + (C[0][1] * B[1][1]);

    A[1][0] = (C[1][0] * B[0][0]) + (C[1][1] * B[1][0]);
    A[1][1] = (C[1][0] * B[0][1]) + (C[1][1] * B[1][1]);
}

#endif
