#ifndef NIGMA_COSA_MATH_H
#define NIGMA_COSA_MATH_H

#include "utilities.h"
#include <math.h>

typedef cosaFloat cosaV2[2];
typedef cosaFloat cosaV3[3];
typedef cosaFloat cosaV4[4];

typedef cosaV2 cosaM2[2];
typedef cosaV3 cosaM3[3];
typedef cosaV4 cosaM4[4];


#define cosaV2Length(V) (sqrtf((V[0] * V[0]) + (V[1] * V[1]))) //X = sqrt(V[X]² + V[Y]²)
#define cosaV2Dot(vA, vB) ((vA[0] * vB[0]) + (vA[1] * vB[1])) //X = (vA[X] * vB[X]) + (vA[Y] * vB[Y])
#define cosaV2Cross(vA, vB) ((vA[0] * vB[1]) - (vA[1] * vB[0])) //X = (vA[X] * vB[Y]) - (vA[Y] * vB[X])

void cosaV2MulScale_Dest(cosaFloat S, cosaV2 vA, cosaV2 vDest) {
    vDest[0] = vA[0] * S;
    vDest[1] = vA[1] * S;
}

void cosaV2DivScale_Dest(cosaFloat S, cosaV2 vA, cosaV2 vDest) {
    vDest[0] = vA[0] / S;
    vDest[1] = vA[1] / S;
}

void cosaV2Normalize_Dest(cosaV2 vA, cosaV2 vDest) {
    cosaFloat length = cosaV2Length(vA);

    if (__builtin_expect(!!(length < __FLT_EPSILON__), 0)) {
        vDest[0] = 0.0f;
        vDest[1] = 0.0f;
        return;
    }
    cosaV2MulScale_Dest(1.0f/length, vA, vDest);
}

//Rotates vA by θ and stores result into vDest.
void cosaV2Rotate_Dest(cosaFloat theta, cosaV2 vA, cosaV2 vDest) {
    cosaFloat c = cosf(theta);
    cosaFloat s = sinf(theta);

    //Just a deconstructed rotation M2,
    //sin(θ) being swapped by axis.
    vDest[0] = (vA[0] *  c) + (vA[0] * s);
    vDest[1] = (vA[1] * -s) + (vA[1] * c);
}

void cosaV2AddV2_Dest(cosaV2 vA, cosaV2 vB, cosaV2 vDest) {
    vDest[0] = vA[0] + vB[0];
    vDest[1] = vA[1] + vB[1];
}

void cosaV2SubV2_Dest(cosaV2 vA, cosaV2 vB, cosaV2 vDest) {
    vDest[0] = vA[0] - vB[0];
    vDest[1] = vA[1] - vB[1];
}

void cosaV2MulV2_Dest(cosaV2 vA, cosaV2 vB, cosaV2 vDest) {
    vDest[0] = vA[0] * vB[0];
    vDest[1] = vA[1] * vB[1];
}

void cosaV2DivV2_Dest(cosaV2 vA, cosaV2 vB, cosaV2 vDest) {
    vDest[0] = vA[0] / vB[0];
    vDest[1] = vA[1] / vB[1];
}


#define cosaV3Length(V) (sqrtf((V[0] * V[0]) + (V[1] * V[1]) + (V[2] * V[2]))) //X = sqrt(V[X]² + V[Y]² + V[Z]²)
#define cosaV3Dot(vA, vB) ((vA[0] * vB[0]) + (vA[1] * vB[1]) + (vA[2] * vB[2])) //X = (vA[X] * vB[X]) + (vA[Y] * vB[Y]) + (vA[Z] * vB[Z])

void cosaV3MulScale_Dest(cosaFloat S, cosaV3 vA, cosaV3 vDest) {
    vDest[0] = vA[0] * S;
    vDest[1] = vA[1] * S;
    vDest[2] = vA[2] * S;
}

void cosaV3Cross_Dest(cosaV3 vA, cosaV3 vB, cosaV3 vDest) {
    vDest[0] = (vA[1] * vB[2]) - (vA[2] * vB[1]);
    vDest[1] = (vA[2] * vB[0]) - (vA[0] * vB[2]);
    vDest[2] = (vA[0] * vB[1]) - (vA[1] * vB[0]);
}

void cosaV3DivScale_Dest(cosaFloat S, cosaV3 vA, cosaV3 vDest) {
    vDest[0] = vA[0] / S;
    vDest[1] = vA[1] / S;
    vDest[2] = vA[2] / S;
}

void cosaV3AddV3_Dest(cosaV3 vA, cosaV3 vB, cosaV3 vDest) {
    vDest[0] = vA[0] + vB[0];
    vDest[1] = vA[1] + vB[1];
    vDest[2] = vA[2] + vB[2];
}

void cosaV3SubV3_Dest(cosaV3 vA, cosaV3 vB, cosaV3 vDest) {
    vDest[0] = vA[0] - vB[0];
    vDest[1] = vA[1] - vB[1];
    vDest[2] = vA[2] - vB[2];
}

void cosaV3MulV3_Dest(cosaV3 vA, cosaV3 vB, cosaV3 vDest) {
    vDest[0] = vA[0] * vB[0];
    vDest[1] = vA[1] * vB[1];
    vDest[2] = vA[2] * vB[2];
}

void cosaV3DivV3_Dest(cosaV3 vA, cosaV3 vB, cosaV3 vDest) {
    vDest[0] = vA[0] / vB[0];
    vDest[1] = vA[1] / vB[1];
    vDest[2] = vA[2] / vB[2];
}


#define cosaV4Length(V) (sqrtf((V[0] * V[0]) + (V[1] * V[1]) + (V[2] * V[2]) + (V[3] * V[3]))) //X = sqrt(V[X]² + V[Y]² + V[Z]² + V[W]²)
#define cosaV4Dot(vA, vB) ((vA[0] * vB[0]) + (vA[1] * vB[1]) + (vA[2] * vB[2]) + (vA[3] * vB[3])) //X = (vA[X] * vB[X]) + (vA[Y] * vB[Y]) + (vA[Z] * vB[Z]) + (vA[W] * vB[W])

void cosaV4MulScale_Dest(cosaFloat S, cosaV4 vA, cosaV4 vDest) {
    vDest[0] = vA[0] * S;
    vDest[1] = vA[1] * S;
    vDest[2] = vA[2] * S;
    vDest[3] = vA[3] * S;
}

void cosaV4DivScale_Dest(cosaFloat S, cosaV4 vA, cosaV4 vDest) {
    vDest[0] = vA[0] / S;
    vDest[1] = vA[1] / S;
    vDest[2] = vA[2] / S;
    vDest[3] = vA[3] / S;
}

void cosaV4AddV3_Dest(cosaV4 vA, cosaV4 vB, cosaV4 vDest) {
    vDest[0] = vA[0] + vB[0];
    vDest[1] = vA[1] + vB[1];
    vDest[2] = vA[2] + vB[2];
    vDest[3] = vA[3] + vB[3];
}

void cosaV4SubV3_Dest(cosaV4 vA, cosaV4 vB, cosaV4 vDest) {
    vDest[0] = vA[0] - vB[0];
    vDest[1] = vA[1] - vB[1];
    vDest[2] = vA[2] - vB[2];
    vDest[3] = vA[3] - vB[3];
}

void cosaV4MulV3_Dest(cosaV4 vA, cosaV4 vB, cosaV4 vDest) {
    vDest[0] = vA[0] * vB[0];
    vDest[1] = vA[1] * vB[1];
    vDest[2] = vA[2] * vB[2];
    vDest[3] = vA[3] * vB[3];
}

void cosaV4DivV3_Dest(cosaV4 vA, cosaV4 vB, cosaV4 vDest) {
    vDest[0] = vA[0] / vB[0];
    vDest[1] = vA[1] / vB[1];
    vDest[2] = vA[2] / vB[2];
    vDest[3] = vA[3] / vB[3];
}


void cosaM2MulV2_Dest(cosaM2 M, cosaV2 V, cosaV2 C) {
    C[0] = (M[0][0] * V[0]) + (M[0][1] * V[1]);
    C[1] = (M[1][0] * V[0]) + (M[1][1] * V[1]);
}

void cosaM2MulV2(cosaM2 M, cosaV2 V) {
    cosaV2 C = {V[0], V[1]};
    V[0] = (M[0][0] * C[0]) + (M[0][1] * C[1]);
    V[1] = (M[1][0] * C[0]) + (M[1][1] * C[1]);
}

void cosaM2AddM2_Dest(cosaM2 A, cosaM2 B, cosaM2 C) {
    C[0][0] = A[0][0] + B[0][0];
    C[0][1] = A[0][1] + B[0][1];
    C[1][0] = A[1][0] + B[1][0];
    C[1][1] = A[1][1] + B[1][1];
}

void cosaM2AddM2(cosaM2 A, cosaM2 B) {
    A[0][0] += B[0][0];
    A[0][1] += B[0][1];
    A[1][0] += B[1][0];
    A[1][1] += B[1][1];
}

//A * B = C
void cosaM2MulM2_Dest(cosaM2 A, cosaM2 B, cosaM2 C) {
    //C=X,R=Y
    //mC[i][j] = mA[i][C] & mB[C][j]
    C[0][0] = (A[0][0] * B[0][0]) + (A[0][1] * B[1][0]);
    C[0][1] = (A[0][0] * B[0][1]) + (A[0][1] * B[1][1]);

    C[1][0] = (A[1][0] * B[0][0]) + (A[1][1] * B[1][0]);
    C[1][1] = (A[1][0] * B[0][1]) + (A[1][1] * B[1][1]);
}

void cosaM2MulM2(cosaM2 A, cosaM2 B) {
    //C=X,R=Y
    //mC[i][j] = mA[i][C] & mB[C][j]
    cosaM2 C = {
        {A[0][0], A[0][1]},
        {A[1][0], A[1][1]}
    };
    A[0][0] = (C[0][0] * B[0][0]) + (C[0][1] * B[1][0]);
    A[0][1] = (C[0][0] * B[0][1]) + (C[0][1] * B[1][1]);

    A[1][0] = (C[1][0] * B[0][0]) + (C[1][1] * B[1][0]);
    A[1][1] = (C[1][0] * B[0][1]) + (C[1][1] * B[1][1]);
}

#endif
