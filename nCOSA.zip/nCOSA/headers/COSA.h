#ifndef NIGMA_COSA_H
#define NIGMA_COSA_H

#include "utilities.h"

//Operations:
extern void cosaOPSETArea(cosaContext *pContext, void *pAddr, cosaU8 value, cosaUSize size);
extern void cosaOPCPYArea(cosaContext *pContext, const void *pSrc, void *pDest, cosaUSize size);
extern void cosaOPSWPArea(cosaContext *pContext, void *pAddrA, void *pAddrB, cosaUSize size);

//Pages:
extern void cosaCreatePage(cosaContext *pContext);
extern void cosaPageGetMD(cosaContext *pContext, cosaPage *pPage, cosaU64 pageID);
extern void cosaPageSetMD(cosaContext *pContext, cosaPage *pPage, cosaU64 pageID);
extern void cosaPageAdd(cosaContext *pContext, cosaPage *pPage, const void *pAddr, cosaU64 byteSize, cosaU64 pageID);

//RAM:
extern void *cosaCreateBlock(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaBlockSegment(cosaContext *pContext, const cosaBlock *pBSrc, cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size);
extern void cosaBlockGetMD(cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr);
extern void cosaBlockLinkMD(cosaContext *pContext, cosaBlock **ppBAddr);
extern void cosaBlockRelinkMD(cosaContext *pContext, cosaBlock **ppBSrc, cosaBlock **ppBDest);
extern void cosaBlockUnlinkMD(cosaContext *pContext, cosaBlock **ppBAddr);
extern void cosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr);
extern void cosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr);

//Stacks:
extern void cosaCreateStackSS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize); //SS -> Type:Static  Size:Static.
extern void cosaCreateStackSD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize); //SD -> Type:Static  Size:Dynamic.
extern void cosaCreateStackDS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size); //DS -> Type:Dynamic Size:Static.
extern void cosaCreateStackDD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size); //DD -> Type:Dynamic Size:Dynamic.
extern void cosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem);
extern void cosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem, cosaUSize itemSize);
extern void *cosaStackSXPop(cosaContext *pContext, const cosaBlock *pStack);
extern void *cosaStackDXPop(cosaContext *pContext, const cosaBlock *pStack, cosaUSize *pItemSize);

//Queues:
extern void cosaCreateQueue(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaQueueAdd(cosaContext *pContext, const cosaBlock *pQueue, const void *pItem);
extern void *cosaQueueNext(cosaContext *pContext, const cosaBlock *pQueue);

//Strings:
extern void cosaCreateDictionary(cosaContext *pContext, cosaU64 *pDictionaryID);
extern void cosaCreateDictionaryByID(cosaContext *pContext, cosaU64 requestedID);
extern void cosaStringLoad(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID);
extern void cosaStringUnload(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID);
extern void cosaStringAddEntry(cosaContext *pContext, cosaString *pString, const cosaChar *pText, cosaU64 dictionaryID);
extern void cosaStringRemoveEntry(cosaContext *pContext, const cosaString *pString, cosaU64 dictionaryID);
extern void cosaStringGet(cosaContext *pContext, cosaBlock **ppBAddr, const cosaString *pString, cosaU64 dictionaryID);
extern void cosaDestroyDictionary(cosaContext *pContext, cosaU64 dictionaryID);

//Files:
extern void cosaFileOpen(cosaContext *pContext, cosaFile **ppFile, const cosaChar *pFilePath, cosaU16 flags);
extern void cosaFileLoadInfo(cosaContext *pContext, cosaFile *pFile);
extern void cosaFileUnloadInfo(cosaContext *pContext, cosaFile *pFile);
extern void cosaFileCreate(cosaContext *pContext);
extern void cosaFileWrite(cosaContext *pContext);
extern void cosaFileRead(cosaContext *pContext);

//CosaContext:
extern cosaBool cosaInitContext(cosaContext *pContext);
extern cosaBool cosaDestroyContext(cosaContext *pContext);

#endif