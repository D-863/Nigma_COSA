#ifndef NIGMA_COSA_H
#define NIGMA_COSA_H

#include "utilities.h"

//Operations:
extern void cosaMemSet(cosaContext *pContext, void *pAddr, cosaU8 value, cosaUSize size);
extern void cosaMemCopy(cosaContext *pContext, const void *pSrc, void *pDest, cosaUSize size);
extern void cosaMemSwap(cosaContext *pContext, const void *pSrc, void *pDest, cosaUSize size);

//RAM:
extern void *cosaCreateBlock(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaBlockExpand(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaBlockShrink(cosaContext *pContext, cosaBlock *pBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaBlockSegment(cosaContext *pContext, const cosaBlock *pBSrc, cosaBlock *pBDest, cosaUSize srcOffset, cosaUSize destOffset, cosaUSize size);
extern void cosaBlockGetMD(cosaContext *pContext, cosaBlock **ppBAddr, const void *pAddr);
extern void cosaBlockLinkMD(cosaContext *pContext, cosaBlock **ppBAddr);
extern void cosaBlockUnlinkMD(cosaContext *pContext, cosaBlock **ppBAddr);
extern void cosaFreeBlock(cosaContext *pContext, cosaBlock **ppBAddr);
extern void cosaDestroyBlock(cosaContext *pContext, cosaBlock **ppBAddr);

//Stacks:
extern void cosaCreateStackSS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize); //SS -> Type:Static  Size:Static.
extern void cosaCreateStackSD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize); //SD -> Type:Static  Size:Dynamic.
extern void cosaCreateStackDS(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size); //DS -> Type:Dynamic Size:Static.
extern void cosaCreateStackDD(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize size); //DD -> Type:Dynamic Size:Dynamic.
extern void cosaStackSXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem);
extern void cosaStackDXPush(cosaContext *pContext, cosaBlock *pStack, const void *pItem, cosaUSize itemSize);
extern void *cosaStackSXPop(cosaContext *pContext, const cosaBlock *pStack);
extern void *cosaStackDXPop(cosaContext *pContext, const cosaBlock *pStack, cosaUSize *pItemSize);

//Queues:
extern void cosaCreateQueue(cosaContext *pContext, cosaBlock **ppBAddr, cosaUSize count, cosaU16 byteSize);
extern void cosaQueueAdd(cosaContext *pContext, const cosaBlock *pQueue, const void *pItem);
extern void *cosaQueueNext(cosaContext *pContext, const cosaBlock *pQueue);

//Files:
extern cosaFile *cosaFileOpen(cosaContext *pContext, const cosaChar *pFilePath, cosaU16 flags);
extern void cosaFileCreate(cosaContext *pContext);
extern void cosaFileWrite(cosaContext *pContext);
extern void cosaFileRead(cosaContext *pContext);

//CosaContext:
extern cosaBool cosaInitContext(cosaContext *pContext);
extern cosaBool cosaDestroyContext(cosaContext *pContext);

#endif