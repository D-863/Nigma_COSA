#ifndef NIGMA_COSA_H
#define NIGMA_COSA_H

#include "utilities.h"

void cosaEndianSWP8B(cosaContext *pContext, cosaU8 *pA, cosaU8 *pB);
void cosaEndianSWP16B(cosaContext *pContext, cosaU16 *pEndian);
void cosaEndianSWP32B(cosaContext *pContext, cosaU32 *pEndian);
void cosaEndianSWP64B(cosaContext *pContext, cosaU64 *pEndian);

cosaMemBlock *cosaMemoryAlloc(cosaContext *pContext, cosaU32 count, cosaUSize byteSize);

void cosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void *cosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);
cosaMemBlock *cosaCreateStack(cosaContext *pContext);

void cosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void cosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue, cosaUSize elemID);
void *cosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue);
cosaMemBlock *cosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize);
void cosaDestroyQueue(cosaContext *pContext, cosaMemBlock *pQueue);

cosaFile *cosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]);
void cosaFileClose(cosaContext *pContext, cosaFile *pFile);

//void cosaOpenQOI(cosaContext *pContext, cosaChar filePath[]);
void cosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]);
void cosaCloseImage(cosaContext *pContext, cosaImage *pImage);

void cosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel);
void cosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel);
void cosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel);
void cosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);

void cosaDestroyContext(cosaContext *pContext);
cosaU8 cosaInitContext(cosaContext *pContext);

#endif