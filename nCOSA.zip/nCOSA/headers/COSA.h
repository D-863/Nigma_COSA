#ifndef NIGMA_COSA_H
#define NIGMA_COSA_H

#include "utilities.h"

cosaMemBlock *cosaMemoryAlloc(cosaContext *pContext, cosaU32 count, cosaUSize byteSize);

void cosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void *cosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);
cosaMemBlock *cosaCreateStack(cosaContext *pContext);

void cosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *cosaQueueRemove(cosaContext *pContext, cosaMemBlock *pQueue);
cosaMemBlock *cosaCreateQueue(cosaContext *pContext, cosaUSize count, cosaUSize byteSize);
void cosaDestroyQueue(cosaContext *pContext, cosaMemBlock *pQueue);

cosaFile *cosaFileOpen(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]);
void cosaFileClose(cosaContext *pContext, cosaFile *pFile);

cosaPanel *cosaCreatePanel(
    cosaContext *pContext,
    cosaU8 type,
    cosaI32 posX,
    cosaI32 posY,
    cosaU32 sizeX,
    cosaU32 sizeY,
    cosaU8 borderWidth,
    cosaU32 panelColor,
    cosaU32 borderColor);
void cosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);

void cosaDestroyContext(cosaContext *pContext);
cosaU8 cosaInitContext(cosaContext *pContext);

#endif