#ifndef NIGMA_COSA_H
#define NIGMA_COSA_H

#include "utilities.h"

void cosaEndianSWP8B(cosaContext *pContext, cosaU8 *pA, cosaU8 *pB);
void cosaEndianSWP16B(cosaContext *pContext, cosaU16 *pEndian);
void cosaEndianSWP32B(cosaContext *pContext, cosaU32 *pEndian);
void cosaEndianSWP64B(cosaContext *pContext, cosaU64 *pEndian);

void cosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize);
void cosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize);
void cosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock);

void cosaStackXSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem);
void cosaStackXDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void cosaStackXBPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemCount);

void *cosaStackXSPop(cosaContext *pContext, cosaMemBlock *pStack);
void *cosaStackXDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);
void *cosaStackXBPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pItemSize);

void cosaCreateStackSS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize);
void cosaCreateStackDS(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize);
void cosaCreateStackSD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size);
void cosaCreateStackDD(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size);
void cosaCreateStackSB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes);
void cosaCreateStackDB(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize size, cosaU8 flagCount, cosaU8 bSizeCount, cosaU8 *pFlags, cosaU32 *pBSizes);

void cosaStackSSRemove(cosaContext *pContext, cosaMemBlock *pStack, cosaU32 itemIndex);

void cosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *cosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue);

void cosaCreateQueue(cosaContext *pContext, cosaMemBlock **ppBlock, cosaU32 count, cosaU32 byteSize);

cosaFile *cosaOpenFile(cosaContext *pContext, cosaU16 flags, cosaChar filePath[]);
void cosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]);

void cosaCloseFile(cosaContext *pContext, cosaFile *pFile);
void cosaCloseImage(cosaContext *pContext, cosaImage *pImage);

void cosaPanelUpdateMousePosInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_POS);
void cosaPanelUpdateMouseKeyInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_MOUSE_KEY);
void cosaPanelUpdateKeyboardInput(cosaContext *pContext, COSA_PANEL_LINK_FUNC_ARGS_KEYBOARD);
void cosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel);
void cosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel);
void cosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel);
void cosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel);

cosaU8 cosaInitContext(cosaContext *pContext);
void cosaDestroyContext(cosaContext *pContext);

#endif