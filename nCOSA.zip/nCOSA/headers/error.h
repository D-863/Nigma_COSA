#ifndef NIGMA_COSA_ERROR_H
#define NIGMA_COSA_ERROR_H

#include "utilities.h"

extern void cosaError(cosaContext *pContext, const cosaChar filePath[], const cosaS32 codeLine);
extern void cosaErrno(cosaContext *pContext, const cosaChar filePath[], const cosaS32 codeLine);

#endif