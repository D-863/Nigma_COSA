#ifndef NIGMA_COSA_ERROR_H
#define NIGMA_COSA_ERROR_H

#include "utilities.h"

void _SetContextERRResult(cosaContext *pContext, const cosaChar filePath[], cosaI32 line);
void _TakeAContextSnapshot(cosaContext *pContext, FILE *pFile);

#endif