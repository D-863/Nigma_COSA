#ifndef NIGMA_COSA_INLINES_H
#define NIGMA_COSA_INLINES_H

#include "COSA.h"
#include "compilics.h"

cosaCompilifics(INLINE, void _TestArchitectureCompatibility(cosaBool *pResult)) {
    if ((sizeof(cosaU8) + sizeof(cosaU16) + sizeof(cosaU32) + sizeof(cosaU64)) != 15) {
        cosaPrint("COSA: (cosaU8 + cosaU16 + cosaU32 + cosaU64) / 8 != 15 Bytes.");
        cosaPrint("COSA: The current CPU Architecture is not compatible!");
        (*pResult) = cosaBFalse;
    } else { (*pResult) = cosaBTrue; }
}

cosaCompilifics(INLINE, void _InitContext(cosaContext *pContext)) {
    cosaOPSETArea(pContext, pContext, 0, sizeof(cosaContext));
    pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
    pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;
}

cosaCompilifics(INLINE, void _EndianSWP_16B(cosaU16 *pEndian)) {
    *pEndian = (*pEndian >> 8) | (*pEndian << 8);
}

cosaCompilifics(INLINE, void _EndianSWP_32B(cosaU32 *pEndian)) {
    cosaU32 val = *pEndian;
    *pEndian = (val >> 24) | (val << 24) | ((val & 0x00FF0000) >> 8) | ((val & 0x0000FF00) << 8);
}

cosaCompilifics(INLINE, void _EndianSWP_64B(cosaU64 *pEndian)) {
    *pEndian = (*pEndian >> 32) | (*pEndian << 32);
    cosaU32 val = *((cosaU32*)pEndian);
    *((cosaU32*)pEndian) = (val >> 24) | (val << 24) | ((val & 0x00FF0000) >> 8) | ((val & 0x0000FF00) << 8);
    val = *(((cosaU32*)pEndian) + 1);
    *(((cosaU32*)pEndian) + 1) = (val >> 24) | (val << 24) | ((val & 0x00FF0000) >> 8) | ((val & 0x0000FF00) << 8);
}

/*BinarySearch return states:
    If there's one instance of <t>, return the index of said instance.
    If there's more than one instance of <t>, return the index of first instance incremented once.
    If there is no instance of <t>, return the bottom index of a instance which is greater than <t>.

    if (instance:count == 1) { return i:<t>; }
    if (instance:count > 1) { return ++i:<t>; }
    if (instance:count == 0) { return --i:(<instance> > <t>); }
*/
cosaCompilifics(INLINE, void _BinarySearch_8B(cosaBool *pFound, cosaUSize *pIndex, const cosaU8 *pBuff, cosaUSize size, cosaU8 target)) {
    cosaUSize i;
    cosaUSize pL = 0;
    cosaUSize pH = size;
    while (pL <= pH) {
        i = pL + ((pH - pL) / 2);
        if (pBuff[i] == target) {
            (*pFound) = cosaBTrue;
            (*pIndex) = i;
            break;
        }
        if (pBuff[i] < target) { pL = i + 1; } else { pH = i - 1; }
    }
}

cosaCompilifics(INLINE, void _BinarySearch_16B(cosaBool *pFound, cosaUSize *pIndex, const cosaU16 *pBuff, cosaUSize size, cosaU16 target)) {
    cosaUSize i;
    cosaUSize pL = 0;
    cosaUSize pH = size;
    while (pL <= pH) {
        i = pL + ((pH - pL) / 2);
        if (pBuff[i] == target) {
            (*pFound) = cosaBTrue;
            break;
        }
        if (pBuff[i] < target) { pL = i + 1; } else { pH = i - 1; }
    }
}

cosaCompilifics(INLINE, void _BinarySearch_32B(cosaBool *pFound, cosaUSize *pIndex, const cosaU32 *pBuff, cosaUSize size, cosaU32 target)) {
    cosaUSize i;
    cosaUSize pL = 0;
    cosaUSize pH = size;
    while (pL <= pH) {
        i = pL + ((pH - pL) / 2);
        if (pBuff[i] == target) {
            (*pFound) = cosaBTrue;
            (*pIndex) = i;
            break;
        }
        if (pBuff[i] < target) { pL = i + 1; } else { pH = i - 1; }
    }
}

cosaCompilifics(INLINE, void _BinarySearch_64B(cosaBool *pFound, cosaUSize *pIndex, const cosaU64 *pBuff, cosaUSize size, cosaU64 target)) {
    cosaUSize i;
    cosaUSize pL = 0;
    cosaUSize pH = size;
    while (pL <= pH) {
        i = pL + ((pH - pL) / 2);
        if (pBuff[i] == target) {
            (*pFound) = cosaBTrue;
            (*pIndex) = i;
            break;
        }
        if (pBuff[i] < target) { pL = i + 1; } else { pH = i - 1; }
    }
}

#endif