#ifndef NIGMA_COSA_INLINES_H
#define NIGMA_COSA_INLINES_H

#include "utilities.h"

#define NIGMA_COSA_BLUEPRINT __attribute__((__always_inline__))static inline

/*! @brief If signed `A` is negative, format signed `A` into a unsigned `A` using the two's complement.
    @note The argument `A` cannot be a float, double nor long double.
*/
#define COSA_MACRO_SIGNED_TO_UNSIGNED(A) ((A < 0) ? (~A) + 1 : A)


NIGMA_COSA_BLUEPRINT cosaU8 _TestArchitectureCompatibility(void) {
    if ((sizeof(cosaU8) + sizeof(cosaU16) + sizeof(cosaU32) + sizeof(cosaU64)) != 15) {
        cosaPrint("COSA: (cosaU8 + cosaU16 + cosaU32 + cosaU64) / 8 != 15 Bytes.");
        cosaPrint("COSA: The current CPU Architecture is not compatible!");
        return COSA_RESULTS_FUNC_FAILURE;
    } else { return COSA_RESULTS_FUNC_SUCCESS; }
}

NIGMA_COSA_BLUEPRINT void _InitializeContext(cosaContext *_pContext) {
    _pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
    _pContext->errorMSG = COSA_CONTEXT_SUCCESS_STR;
    _pContext->blockPage.count = 0;
    _pContext->blockPage.top = 0;
    _pContext->blockPage.pBlocks = NULL;
    _pContext->memPage.size = 0;
    _pContext->memPage.top = 0;
    _pContext->memPage.pMem = NULL;
}

#undef NIGMA_COSA_BLUEPRINT
#endif