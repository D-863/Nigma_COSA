#ifndef NIGMA_COSA_LIZARD_H
#define NIGMA_COSA_LIZARD_H

#include "utilities.h"

/*Nigma:
    Prints 'Lizard.\n' ¯\_(ツ)_/¯
    I do not know how it got here,
    but I am keeping it as a gift for D_863. :>
*/
#define COSA_LIZARD \
    cosaU8 R[8] = ".draziL";\
    while (7 - R[7]) { printf("%c", R[6]); R[6] ^= R[5 - R[7]] ^ R[6] ^ R[5 - R[7]] ^ R[6] ^ R[5 - R[7]] ^ R[6]; ++R[7]; }\
    printf("%c", R[7] + 3);\

#endif