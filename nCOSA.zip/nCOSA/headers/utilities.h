#ifndef NIGMA_COSA_UTILITIES_H
#define NIGMA_COSA_UTILITIES_H

/*STD Libaries*/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>
#include <errno.h>

#if !defined(NIGMA_COSA_ENABLES_PATH)
    #define NIGMA_COSA_ENABLES_PATH "enables.h"
#endif

#if !defined(NIGMA_COSA_DEFINES_PATH)
    #define NIGMA_COSA_DEFINES_PATH "defines.h"
#endif

#include NIGMA_COSA_ENABLES_PATH
#include NIGMA_COSA_DEFINES_PATH
#include "types.h"
#include "error.h"
//#include "math.h"

#endif