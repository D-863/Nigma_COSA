#ifndef NIGMA_COSA_UTILITIES_H
#define NIGMA_COSA_UTILITIES_H

/*STD Libaries*/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>

#define COSA_ENABLE_DEBUG

#define COSA_ENABLE_EXTENSIONS
#define COSA_EXTENSION_COUNT 1
#define COSA_ENABLE_PANEL

#if !defined(NIGMA_COSA_DEFINES_PATH)
    #define NIGMA_COSA_DEFINES_PATH "defines.h"
#endif
#include NIGMA_COSA_DEFINES_PATH

#include "structs.h"
#include "inlines.h"
#include "math.h"

#endif