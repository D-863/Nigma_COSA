#ifndef NIGMA_COSA_COMPILIFICS_H
#define NIGMA_COSA_COMPILIFICS_H
//The neat made up word 'Compilics' means 'Compiler Specifics'.

/*
    I will throw both of the hellish compiler and std version checking headache onto Nigma,
    to fix later in spacetime. For now just declare compiler-specific code here.
*/

/*
    ? = Compier specific keywords.
    t:INLINE = "?static inline [...]"
    t:PACK(t, ...) {
        t:X = "? [...]"
        t:VAR = "? [...]"
        t:UNION = "union ? [...]"
        t:STRUC = "struct ? [...]"
    }
*/
#define cosaCompilifics(t, ...) COSA_COMPILIFICS_##t(__VA_ARGS__)

#define COSA_COMPILIFICS_INLINE(...) __attribute__((__always_inline__))static inline __VA_ARGS__

#define COSA_COMPILIFICS_PACK(t, ...) COSA_COMPILIFICS_PACK_##t(__VA_ARGS__)
#define COSA_COMPILIFICS_PACK_X(...) __attribute__((packed)) __VA_ARGS__
#define COSA_COMPILIFICS_PACK_VAR(...) __attribute__((packed)) __VA_ARGS__
#define COSA_COMPILIFICS_PACK_UNION(...) union __attribute__((packed)) __VA_ARGS__
#define COSA_COMPILIFICS_PACK_STRUCT(...) struct __attribute__((packed)) __VA_ARGS__

#endif