#include "headers/error.h"

void _SetContextERRResult(cosaContext *pContext, const cosaChar filePath[], cosaI32 line) {
    cosaI32 errorNum = errno;
    pContext->errorNUM = COSA_MACRO_SIGNED_TO_UNSIGNED(errorNum);
    cosaU32 lineNum = COSA_MACRO_SIGNED_TO_UNSIGNED(line);

    cosaChar *errorStr = strerror(pContext->errorNUM);
    cosaChar resultStrTemp[] = "COSA: {\n\tFile<>\n\tLine<>\n\tERROR: {\n\t\tnum<>\n\t\tstr<>\n\t}\n}\n";
    cosaChar errorNumStr[11] = {0};
    cosaChar lineNumStr[11]  = {0};
    (void)snprintf(errorNumStr, 11 * sizeof(cosaChar), "%u", pContext->errorNUM);
    (void)snprintf(lineNumStr,  11 * sizeof(cosaChar), "%u", lineNum);

    cosaUSize lengthResultStrTemp = strlen(resultStrTemp);
    cosaUSize lengthFilePath      = strlen(filePath);
    cosaUSize lengthErrorStr      = strlen(errorStr);
    cosaUSize lengthErrorNumStr   = strlen(errorNumStr);
    cosaUSize lengthLineNumStr    = strlen(lineNumStr);
    pContext->errorMSG = malloc(lengthResultStrTemp + lengthFilePath + lengthErrorStr);
    if (pContext->errorMSG == NULL) {
        pContext->errorMSG = "COSA: Could not allocate heap memory for errorMSG!\n";
        cosaPrint(pContext->errorMSG);
        return;
    }
    (void)memset(pContext->errorMSG, '\0', lengthResultStrTemp + lengthFilePath + lengthErrorStr);

    cosaUSize offsetDest = 0;
    cosaUSize offsetSrc = 0;
    (void)memcpy(pContext->errorMSG, resultStrTemp, 14 * sizeof(cosaChar));
    offsetSrc  += 14;
    offsetDest += 14;
    (void)memcpy(pContext->errorMSG + offsetDest, filePath, lengthFilePath * sizeof(cosaChar));
    offsetDest += lengthFilePath;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    offsetSrc  += 8;
    offsetDest += 8;
    (void)memcpy(pContext->errorMSG + offsetDest, lineNumStr, lengthLineNumStr * sizeof(cosaChar));
    offsetDest += lengthLineNumStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 18 * sizeof(cosaChar));
    offsetSrc  += 18;
    offsetDest += 18;
    (void)memcpy(pContext->errorMSG + offsetDest, errorNumStr, lengthErrorNumStr * sizeof(cosaChar));
    offsetDest += lengthErrorNumStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    offsetSrc  += 8;
    offsetDest += 8;
    (void)memcpy(pContext->errorMSG + offsetDest, errorStr, lengthErrorStr * sizeof(cosaChar));
    offsetDest += lengthErrorStr;
    (void)memcpy(pContext->errorMSG + offsetDest, resultStrTemp + offsetSrc, 8 * sizeof(cosaChar));
    /*COSA: {
          File<__FILE__>
          Line<__LINE__>
          ERROR: {
              num<errno>
              str<strerror(errno)>
          }
      }*/
}
