#ifndef NIGMA_COSA_H
#define NIGMA_COSA_H

#include "utilities.h"

void cosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize);
void cosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock);

cosaU8 cosaInitContext(cosaContext *pContext);
void cosaDestroyContext(cosaContext *pContext);

#endif