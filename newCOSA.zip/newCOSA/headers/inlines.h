#ifndef NIGMA_COSA_INLINES_H
#define NIGMA_COSA_INLINES_H

#include "utilities.h"

#define NIGMA_COSA_BLUEPRINT __attribute__((__always_inline__))static inline

/*! @brief If signed `A` is negative, format signed `A` into a unsigned `A` using the two's complement.
    @note The argument `A` cannot be a float, double nor long double.
*/
#define COSA_MACRO_SIGNED_TO_UNSIGNED(A) ((A < 0) ? (~A) + 1 : A)


NIGMA_COSA_BLUEPRINT cosaU8 _TestArchitectureCompatibility(void) {
    if ((sizeof(cosaU8) + sizeof(cosaU16) + sizeof(cosaU32) + sizeof(cosaU64)) != 15) {
        cosaPrint("COSA: (cosaU8 + cosaU16 + cosaU32 + cosaU64) / 8 != 15 Bytes.");
        cosaPrint("COSA: The current CPU Architecture is not compatible!");
        return COSA_RESULTS_FUNC_FAILURE;
    } else { return COSA_RESULTS_FUNC_SUCCESS; }
}

NIGMA_COSA_BLUEPRINT void _InitContext(cosaContext *_pContext) {
    (void)memset(_pContext, 0, sizeof(cosaContext));
    (void)memset(&_pContext->blockPage, 0, sizeof(cosaBlockPage));
    (void)memset(&_pContext->filePage, 0, sizeof(cosaFilePage));
    _pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
    _pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;
}

NIGMA_COSA_BLUEPRINT void _EndianSWP8B(cosaU8 *pA, cosaU8 *pB) {
    *pA ^= *pB;
    *pB ^= *pA;
    *pA ^= *pB;
}

NIGMA_COSA_BLUEPRINT void _EndianSWP16B(cosaU16 *pEndian) {
    *pEndian = (*pEndian >> 8) | (*pEndian << 8);
}

NIGMA_COSA_BLUEPRINT void _EndianSWP32B(cosaU32 *pEndian) {
    cosaU32 val = *pEndian;
    *pEndian = (val >> 24) | (val << 24) | ((val & 0x00FF0000) >> 8) | ((val & 0x0000FF00) << 8);
}

NIGMA_COSA_BLUEPRINT void _EndianSWP64B(cosaU64 *pEndian) {
    *pEndian = (*pEndian >> 32) | (*pEndian << 32);
    cosaU32 val = *((cosaU32*)pEndian);
    *((cosaU32*)pEndian) = (val >> 24) | (val << 24) | ((val & 0x00FF0000) >> 8) | ((val & 0x0000FF00) << 8);
    val = *(((cosaU32*)pEndian) + 1);
    *(((cosaU32*)pEndian) + 1) = (val >> 24) | (val << 24) | ((val & 0x00FF0000) >> 8) | ((val & 0x0000FF00) << 8);
}

#undef NIGMA_COSA_BLUEPRINT
#endif