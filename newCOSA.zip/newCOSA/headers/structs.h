#ifndef NIGMA_COSA_STRUCTS_H
#define NIGMA_COSA_STRUCTS_H

#include "utilities.h"

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaBlockLink {
    cosaUSize blockSlot;
    cosaMemBlock **ppBlockLink;
} cosaBlockLink;

typedef struct cosaBlockPage {
    cosaUSize freedCount;
    cosaUSize blockCount;
    cosaUSize linkCount;
    cosaUSize freedTop;
    cosaUSize blockTop;
    cosaUSize linkTop;
    cosaUSize *pFreed;
    cosaMemBlock *pBlocks;
    cosaBlockLink *pLinks;
} cosaBlockPage;

typedef struct cosaContext {
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaChar *errorMSG;
} cosaContext;

#endif