#ifndef NIGMA_COSA_STRUCTS_H
#define NIGMA_COSA_STRUCTS_H

#include "utilities.h"

typedef struct cosaMemBlock {
    cosaU8 flags;
    cosaUSize byteSize;
    cosaUSize count;
    cosaU8 *addr;
} cosaMemBlock;

typedef struct cosaLinkBlock {
    cosaUSize blockSlot;
    cosaMemBlock **ppBlockLink;
} cosaLinkBlock;

typedef struct cosaBlockPage {
    cosaUSize freedCount;
    cosaUSize blockCount;
    cosaUSize linkCount;
    cosaUSize freedTop;
    cosaUSize blockTop;
    cosaUSize linkTop;
    cosaUSize *pFreed;
    cosaMemBlock *pBlocks;
    cosaLinkBlock *pLinks;
} cosaBlockPage;

typedef struct cosaContext {
    cosaU32 errorNUM;
    cosaBlockPage blockPage;
    cosaChar *errorMSG;
} cosaContext;

#endif