#include "headers/COSA.h"

int main(void) {
    cosaContext context;
    (void)cosaInitContext(&context);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }

    cosaMemBlock *pBlock = NULL;
    cosaCreateBlock(&context, &pBlock, 1, sizeof(cosaU32));
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }

    cosaU32 *pAa = (cosaU32*)pBlock->addr;
    *pAa = 32;
    cosaPrintF("<%u>\n", *pAa);

    cosaDestroyBlock(&context, pBlock);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }
    pBlock = NULL;
    pAa = NULL;

    cosaChar msg[] = "Hello, Cosa!";
    cosaMemBlock *pStack = cosaCreateStackSS(&context, cosaBCount(msg), sizeof(cosaChar));
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }
    cosaPrint(msg);

    for (cosaUSize i = 0; i < cosaBCount(msg) - 1; ++i) {
        cosaStackSSPush(&context, pStack, &msg[i]);
        assert(context.errorNUM == COSA_CONTEXT_SUCCESS_NUM);
    }

    for (cosaUSize i = 0; i < cosaBCount(msg) - 1; ++i) {
        cosaChar *pC = cosaStackSSPop(&context, pStack, NULL);
        assert(context.errorNUM == COSA_CONTEXT_SUCCESS_NUM);
        cosaPrintF("%c", *pC);
    }
    cosaPrintF("\n");

    cosaDestroyBlock(&context, pStack);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }

    cosaDestroyContext(&context);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }
    return 0;
}
