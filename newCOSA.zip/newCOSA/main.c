#include "headers/COSA.h"

void printMemInfo(cosaContext *pContext) {
    cosaPrint("pContext->blockPage {");
    cosaPrintF("\t.freedCount<%lu>\n", pContext->blockPage.freedCount);
    cosaPrintF("\t.blockCount<%lu>\n", pContext->blockPage.blockCount);
    cosaPrintF("\t.linkCount<%lu>\n",  pContext->blockPage.linkCount);
    cosaPrintF("\t.freedTop<%lu>\n",   pContext->blockPage.freedTop);
    cosaPrintF("\t.blockTop<%lu>\n",   pContext->blockPage.blockTop);
    cosaPrintF("\t.linkTop<%lu>\n",    pContext->blockPage.linkTop);
    cosaPrintF("\t.pFreed<%p>\n",  (void*)pContext->blockPage.pFreed);
    cosaPrintF("\t.pBlocks<%p>\n", (void*)pContext->blockPage.pBlocks);
    cosaPrintF("\t.pLinks<%p>\n",  (void*)pContext->blockPage.pLinks);
    cosaPrint("\n}");
    cosaPrint("---------------------------");
}

int main(void) {
    cosaContext context = {0};
    (void)cosaInitContext(&context);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }

    cosaUSize i,j;
    cosaMemBlock *pBlocks[1000] = {0};
    for (i = 0; i < 1000; ++i) {
        (void)memset(pBlocks, 0, sizeof(pBlocks));
        for (j = 0; j < 100; ++j) {
            //cosaPrintF("j<%lu>\n", j);
            cosaCreateBlock(&context, &pBlocks[j], 1, cosaMBTB(1));
            if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
                cosaPrint(context.errorMSG);
                return 1;
            }
            (void)memset(pBlocks[j]->addr, 0, pBlocks[j]->count * pBlocks[j]->byteSize);

            cosaU32 *pAa = (cosaU32*)pBlocks[j]->addr;
            *pAa = 32;
            //cosaPrintF("<%u>\n", *pAa);
        }

        for (j = 0; j < 100; ++j) {
            cosaDestroyBlock(&context, pBlocks[j]);
            if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
                cosaPrint(context.errorMSG);
                return 1;
            }
            pBlocks[j] = NULL;
        }
    }
    cosaPrintF("{i:%lu, j:%lu}\n", i, j);

    cosaDestroyContext(&context);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }
    return 0;
}
