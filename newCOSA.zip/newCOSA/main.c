#include "headers/COSA.h"

int main(void) {
    cosaContext context;
    (void)cosaInitContext(&context);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }

    cosaUSize i,j;
    for (i = 0; i < 1000000; ++i) {
        cosaMemBlock *pBlocks[100] = {0};
        for (j = 0; j < 100; ++j) {
            cosaPrintF("j<%lu>\n", j);
            cosaCreateBlock(&context, &pBlocks[j], 1, sizeof(cosaU32));
            if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
                cosaPrint(context.errorMSG);
                return 1;
            }

            cosaU32 *pAa = (cosaU32*)pBlocks[j]->addr;
            *pAa = 32;
            //cosaPrintF("<%u>\n", *pAa);
        }

        for (j = 0; j < 100; ++j) {
            cosaPrintF("j<%lu>\n", j);
            cosaDestroyBlock(&context, pBlocks[j]);
            if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
                cosaPrint(context.errorMSG);
                return 1;
            }
            pBlocks[j] = NULL;
        }
    }
    cosaPrintF("{i:%lu, j:%lu}\n", i, j);

    cosaDestroyContext(&context);
    if (context.errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        cosaPrintF("context.errorNUM<%u>\n", context.errorNUM);
        cosaPrint(context.errorMSG);
        return 1;
    }
    return 0;
}
