#include "headers/COSA.h"

int main(void) {
    cosaContext context;
    (void)cosaInitContext(&context);

    cosaMemBlock *pBlock = NULL;
    cosaCreateBlock(&context, &pBlock, 1, sizeof(cosaU32));

    cosaU32 *pAa = (cosaU32*)pBlock->addr;
    *pAa = 32;
    cosaPrintF("<%u>\n", *pAa);

    cosaDestroyBlock(&context, pBlock);
    pBlock = NULL;
    pAa = NULL;

    cosaDestroyContext(&context);
    return 0;
}
