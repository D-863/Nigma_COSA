#ifndef NIGMA_COSA_LINUX_H
#define NIGMA_COSA_LINUX_H

#include "../headers/utilities.h"

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize);
void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize);
void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock);

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem);
void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem);
void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);
void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize);

void *linuxCosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);
void *linuxCosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);
void *linuxCosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);
void *linuxCosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize);

cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize);
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize);
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size);
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size);

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem);
void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue);

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaU32 count, cosaU32 byteSize);

#endif