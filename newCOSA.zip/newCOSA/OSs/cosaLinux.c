#include "cosaLinux.h"
#include "../headers/error.h"

void _ExpandFreedRegion(cosaContext *pContext) {
    cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.freedCount);

    cosaUSize *pNewRegion = realloc(pContext->blockPage.pFreed, newCount * sizeof(cosaUSize));
    if (pNewRegion == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewRegion + pContext->blockPage.freedCount, 0, (newCount - pContext->blockPage.freedCount) * sizeof(cosaUSize));
    pContext->blockPage.freedTop = pContext->blockPage.freedCount;
    pContext->blockPage.freedCount = newCount;
    pContext->blockPage.pFreed = pNewRegion;
}

void _ExpandLinkRegion(cosaContext *pContext) {
    cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

    cosaBlockLink *pNewRegion = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaBlockLink));
    if (pNewRegion == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewRegion + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaBlockLink));
    pContext->blockPage.linkTop = pContext->blockPage.linkCount;
    pContext->blockPage.linkCount = newCount;
    pContext->blockPage.pLinks = pNewRegion;
}

void _ExpandBlockPage(cosaContext *pContext) {
    cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

    cosaMemBlock *pNewRegion = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
    if (pNewRegion == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewRegion + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
    pContext->blockPage.blockTop = pContext->blockPage.blockCount;
    pContext->blockPage.blockCount = newCount;
    pContext->blockPage.pBlocks = pNewRegion;

    cosaUSize blockSlot;
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink == NULL) { continue; }

        blockSlot = pContext->blockPage.pLinks[i].blockSlot;
        (*pContext->blockPage.pLinks[i].ppBlockLink) = &pContext->blockPage.pBlocks[blockSlot];
    }
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    (*ppBlock) = NULL;
    if (cosaCUnlikely((count * byteSize) > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }

    cosaUSize blockSize = count * byteSize;
    cosaUSize blockSlot,freedSlot,freedSize;
    cosaBool foundSlot = cosaBFalse;
    for (freedSlot = 0; freedSlot < pContext->blockPage.freedTop; ++freedSlot) {
        blockSlot = pContext->blockPage.pFreed[freedSlot];
        freedSize = pContext->blockPage.pBlocks[blockSlot].count;
        freedSize *= pContext->blockPage.pBlocks[blockSlot].byteSize;
        if (freedSize >= blockSize) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBFalse) {
        for (blockSlot = 0; blockSlot < pContext->blockPage.blockCount; ++blockSlot) {
            if (cosaRP(pContext->blockPage.pBlocks[blockSlot].flags, COSA_MEM_FLAG_USED) == COSA_MEM_FLAG_FREE) {
                foundSlot = cosaBTrue;
                break;
            }
        }
        if (foundSlot == cosaBFalse) {
            _ExpandBlockPage(pContext);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        }
    } else {
        for (cosaUSize i = freedSlot + 1; i < pContext->blockPage.freedTop; ++i) {
            pContext->blockPage.pFreed[i - 1] = pContext->blockPage.pFreed[i];
        }
        --pContext->blockPage.freedTop;
    }

    foundSlot = cosaBFalse;
    cosaUSize linkSlot;
    for (linkSlot = 0; linkSlot < pContext->blockPage.linkTop; ++linkSlot) {
        if (pContext->blockPage.pLinks[linkSlot].ppBlockLink == NULL) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBFalse) {
        _ExpandLinkRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }

    pContext->blockPage.pBlocks[blockSlot].addr = malloc(count * byteSize);
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOM;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOM;
        return;
    }
    pContext->blockPage.pBlocks[blockSlot].flags = COSA_MEM_FLAG_USED;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    *ppBlock = &pContext->blockPage.pBlocks[blockSlot];

    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;
}

void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    cosaPrintF("<%p>\n", (void*)pBlock);
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    cosaUSize blockSlot = pBlock - pContext->blockPage.pBlocks;
    if (blockSlot > pContext->blockPage.blockTop) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
        return;
    } else if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }

    //Links.
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].blockSlot != blockSlot) { continue; }
        if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) { (*pContext->blockPage.pLinks[i].ppBlockLink) = NULL; }
        pContext->blockPage.pLinks[i].ppBlockLink = NULL;
    }

    //Blocks.
    free(pContext->blockPage.pBlocks[blockSlot].addr);
    pContext->blockPage.pBlocks[blockSlot].addr = NULL;
    cosaC1B(pContext->blockPage.pBlocks[blockSlot].flags);

    //Freeds.
    cosaUSize oldTop = pContext->blockPage.freedTop;
    ++pContext->blockPage.freedTop;
    if (pContext->blockPage.freedTop >= pContext->blockPage.freedCount) {
        _ExpandFreedRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    pContext->blockPage.pFreed[oldTop] = blockSlot;
}

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 BSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * BSize;

    if (offset >= (pStack->count - COSA_STACK_SIZE_SS)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    (void)memcpy(pMem + offset, pItem, BSize);
    ++(*pTop);
}

void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 BSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * BSize;
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DS);

    if (offset >= size) {
        size += offset - size;
        size += COSA_STACK_EXPAND * BSize;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DS, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    (void)memcpy(pMem + offset, pItem, BSize);
    ++(*pTop);
}

void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) += itemSize + sizeof(itemSize);

    if (newTop >= (pStack->count - COSA_STACK_SIZE_SD)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);

    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(itemSize));
    (*pTop) = newTop;
}

void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) += itemSize + sizeof(itemSize);
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DD);

    if (newTop >= size) {
        size += newTop - size;
        size += COSA_STACK_EXPAND * 16;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);

    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(itemSize));
    (*pTop) = newTop;
}

//Copies itemSize amount of bytes from pItem into Stack##.
void linuxCosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU8 type = *((cosaU8*)(pStack->addr + sizeof(cosaU32)));
    switch (type) {
        case COSA_STACK_TYPE_SS: {
            linuxCosaStackSSPush(pContext, pStack, pItem);
            break;
        }
        case COSA_STACK_TYPE_SD: {
            linuxCosaStackSDPush(pContext, pStack, pItem, itemSize);
            break;
        }
        case COSA_STACK_TYPE_DS: {
            linuxCosaStackDSPush(pContext, pStack, pItem);
            break;
        }
        case COSA_STACK_TYPE_DD: {
            linuxCosaStackDDPush(pContext, pStack, pItem, itemSize);
            break;
        }
        default: {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
            break;
        }
    }
}

//Returns a pointer to item from Stack## and gives item's Size.
void *linuxCosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    return NULL;
}

//StackSS - Static Sized Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_SS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

//StackDS - Dynamic Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_DS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pType = COSA_STACK_TYPE_DS;
    *pBSize = byteSize;

    return pBlock;
}

//StackSD - Static Sized Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_SD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_SD;

    return pBlock;
}

//StackDD - Dynamic Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_DD;

    return pBlock;
}
