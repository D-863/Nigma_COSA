#include "cosaLinux.h"
#include "../headers/error.h"

cosaBool _CosaFindFreedBlock(cosaContext *pContext, cosaUSize *pFreedSlot) {
}

void _CosaGetLinkBlock(cosaContext *pContext, cosaUSize *pLinkSlot) {
    (*pLinkSlot) = pContext->blockPage.linkTop;
    ++pContext->blockPage.linkTop;

    if (pContext->blockPage.linkTop >= pContext->blockPage.linkCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

        cosaLinkBlock *pNewLinks = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaLinkBlock));
        if (pNewLinks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewLinks + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaLinkBlock));
        pContext->blockPage.linkCount = newCount;
        pContext->blockPage.pLinks = pNewLinks;
    }
}

void _CosaSortLinks(cosaContext *pContext) {
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink == NULL) {
            pContext->blockPage.pLinks[i].blockSlot = pContext->blockPage.pLinks[pContext->blockPage.linkTop].blockSlot;
            pContext->blockPage.pLinks[i].ppBlockLink = pContext->blockPage.pLinks[pContext->blockPage.linkTop].ppBlockLink;
            --pContext->blockPage.linkTop;
        }
    }
}

void _CosaUpdateLinks(cosaContext *pContext) {
    cosaUSize blockSlot;
    _CosaSortLinks(pContext);
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        blockSlot = pContext->blockPage.pLinks[i].blockSlot;
        (*pContext->blockPage.pLinks[i].ppBlockLink) = &pContext->blockPage.pBlocks[blockSlot];
    }
}

void _CosaGetBlockMD(cosaContext *pContext, cosaUSize *pBlockSlot) {
    (*pBlockSlot) = pContext->blockPage.blockTop;
    ++pContext->blockPage.blockTop;

    if (pContext->blockPage.blockTop >= pContext->blockPage.blockCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

        cosaMemBlock *pNewBlocks = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
        if (pNewBlocks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewBlocks + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
        pContext->blockPage.blockCount = newCount;
        pContext->blockPage.pBlocks = pNewBlocks;

        if (pNewBlocks == pContext->blockPage.pBlocks) {
            _CosaUpdateLinks(pContext);
        }
    }
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    //Unlikely yet possible malloc error.
    if (cosaCUnlikely((count * byteSize) > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }

    //Is there usuable freed blocks? Otherwise, get a fresh one.
    cosaUSize blockSlot = 0;
    cosaBool foundSlot = _CosaFindFreedBlock(pContext, &blockSlot);
    if (foundSlot == cosaBFalse) {
        _CosaGetBlockMD(pContext, &blockSlot);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    pContext->blockPage.pBlocks[blockSlot].addr = malloc(count * byteSize);
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }

    //Get a linkBlock slot and set it.
    cosaUSize linkSlot = 0;
    _CosaGetLinkBlock(pContext, &linkSlot);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        free(pContext->blockPage.pBlocks[blockSlot].addr);
        return;
    }
    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;

    //Give the newly created block's address.
    (*ppBlock) = &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
}

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 BSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * BSize;

    if (offset >= (pStack->count - COSA_STACK_SIZE_SS)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    (void)memcpy(pMem + offset, pItem, BSize);
    ++(*pTop);
}

void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 BSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * BSize;
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DS);

    if (offset >= size) {
        size += offset - size;
        size += COSA_STACK_EXPAND * BSize;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DS, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    (void)memcpy(pMem + offset, pItem, BSize);
    ++(*pTop);
}

void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) + itemSize + sizeof(cosaUSize);

    if (newTop >= (pStack->count - COSA_STACK_SIZE_SD)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(cosaUSize));
    (*pTop) = newTop;
}

void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) += itemSize + sizeof(itemSize);
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DD);

    if (newTop >= size) {
        size += newTop - size;
        size += COSA_STACK_EXPAND * 16;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(itemSize));
    (*pTop) = newTop;
}

void *linuxCosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 BSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    if (pSize != NULL) { *pSize = BSize; }
    --(*pTop);

    return pMem + ((*pTop) * BSize);
}

void *linuxCosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 BSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    if (pSize != NULL) { *pSize = BSize; }
    --(*pTop);

    return pMem + ((*pTop) * BSize);
}

void *linuxCosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

void *linuxCosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

//Copies itemSize amount of bytes from pItem into Stack##.
void linuxCosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU8 type = *((cosaU8*)(pStack->addr + sizeof(cosaU32)));
    switch (type) {
        case COSA_STACK_TYPE_SS: {
            linuxCosaStackSSPush(pContext, pStack, pItem);
            break;
        }
        case COSA_STACK_TYPE_SD: {
            linuxCosaStackSDPush(pContext, pStack, pItem, itemSize);
            break;
        }
        case COSA_STACK_TYPE_DS: {
            linuxCosaStackDSPush(pContext, pStack, pItem);
            break;
        }
        case COSA_STACK_TYPE_DD: {
            linuxCosaStackDDPush(pContext, pStack, pItem, itemSize);
            break;
        }
        default: {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
            break;
        }
    }
}

//Returns a pointer to item from Stack## and gives item's Size.
void *linuxCosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU8 type = *((cosaU8*)(pStack->addr + sizeof(cosaU32)));
    void *pItem = NULL;
    switch (type) {
        case COSA_STACK_TYPE_SS: {
            pItem = linuxCosaStackSSPop(pContext, pStack, pSize);
            break;
        }
        case COSA_STACK_TYPE_SD: {
            pItem = linuxCosaStackSDPop(pContext, pStack, pSize);
            break;
        }
        case COSA_STACK_TYPE_DS: {
            pItem = linuxCosaStackDSPop(pContext, pStack, pSize);
            break;
        }
        case COSA_STACK_TYPE_DD: {
            pItem = linuxCosaStackDDPop(pContext, pStack, pSize);
            break;
        }
        default: {
            pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
            pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
            break;
        }
    }
    return pItem;
}

//StackSS - Static Sized Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_SS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

//StackDS - Dynamic Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_DS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pType = COSA_STACK_TYPE_DS;
    *pBSize = byteSize;

    return pBlock;
}

//StackSD - Static Sized Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_SD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_SD;

    return pBlock;
}

//StackDD - Dynamic Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_DD;

    return pBlock;
}
