#include "cosaLinux.h"
#include "../headers/error.h"

void _ExpandFreedRegion(cosaContext *pContext) {
    cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.freedCount);

    cosaUSize *pNewRegion = realloc(pContext->blockPage.pFreed, newCount * sizeof(cosaUSize));
    if (pNewRegion == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewRegion + pContext->blockPage.freedCount, 0, (newCount - pContext->blockPage.freedCount) * sizeof(cosaUSize));
    pContext->blockPage.freedTop = pContext->blockPage.freedCount;
    pContext->blockPage.freedCount = newCount;
    pContext->blockPage.pFreed = pNewRegion;
}

void _ExpandLinkRegion(cosaContext *pContext) {
    cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

    cosaBlockLink *pNewRegion = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaBlockLink));
    if (pNewRegion == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewRegion + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaBlockLink));
    pContext->blockPage.linkTop = pContext->blockPage.linkCount;
    pContext->blockPage.linkCount = newCount;
    pContext->blockPage.pLinks = pNewRegion;
}

void _ExpandBlockPage(cosaContext *pContext) {
    cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

    cosaMemBlock *pNewRegion = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
    if (pNewRegion == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewRegion + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
    pContext->blockPage.blockTop = pContext->blockPage.blockCount;
    pContext->blockPage.blockCount = newCount;
    pContext->blockPage.pBlocks = pNewRegion;

    cosaUSize blockSlot;
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink == NULL) { continue; }

        blockSlot = pContext->blockPage.pLinks[i].blockSlot;
        *pContext->blockPage.pLinks[i].ppBlockLink = &pContext->blockPage.pBlocks[blockSlot];
    }
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    if (cosaCUnlikely((count * byteSize) > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        *ppBlock = NULL;
        return;
    }

    cosaUSize blockSize = count * byteSize;
    cosaUSize blockSlot,freedSlot,freedSize;
    cosaBool foundSlot = cosaBFalse;
    for (freedSlot = 0; freedSlot < pContext->blockPage.freedTop; ++freedSlot) {
        blockSlot = pContext->blockPage.pFreed[freedSlot];
        freedSize = pContext->blockPage.pBlocks[blockSlot].count;
        freedSize *= pContext->blockPage.pBlocks[blockSlot].byteSize;
        if (freedSize >= blockSize) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBFalse) {
        for (blockSlot = 0; blockSlot < pContext->blockPage.blockCount; ++blockSlot) {
            if (cosaRP(pContext->blockPage.pBlocks[blockSlot].flags, COSA_MEM_FLAG_USED) == COSA_MEM_FLAG_FREE) {
                foundSlot = cosaBTrue;
                break;
            }
        }
        if (foundSlot == cosaBFalse) {
            _ExpandBlockPage(pContext);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                *ppBlock = NULL;
                return;
            }
        }
    } else {
        for (cosaUSize i = freedSlot + 1; i < pContext->blockPage.freedTop; ++i) {
            pContext->blockPage.pFreed[i - 1] = pContext->blockPage.pFreed[i];
        }
        --pContext->blockPage.freedTop;
    }

    foundSlot = cosaBFalse;
    cosaUSize linkSlot;
    for (linkSlot = 0; linkSlot < pContext->blockPage.linkTop; ++linkSlot) {
        if (pContext->blockPage.pLinks[linkSlot].ppBlockLink == NULL) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBFalse) {
        _ExpandLinkRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
            *ppBlock = NULL;
            return;
        }
    }

    pContext->blockPage.pBlocks[blockSlot].addr = malloc(count * byteSize);
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOM;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOM;
        *ppBlock = NULL;
        return;
    }
    pContext->blockPage.pBlocks[blockSlot].flags = COSA_MEM_FLAG_USED;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    *ppBlock = &pContext->blockPage.pBlocks[blockSlot];

    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    cosaUSize blockSlot = pBlock - pContext->blockPage.pBlocks;
    if (blockSlot > pContext->blockPage.blockTop) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }

    //Links.
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].blockSlot != blockSlot) { continue; }
        pContext->blockPage.pLinks[i].ppBlockLink = NULL;
    }

    //Blocks.
    free(pContext->blockPage.pBlocks[blockSlot].addr);
    pContext->blockPage.pBlocks[blockSlot].addr = NULL;
    cosaC1B(pContext->blockPage.pBlocks[blockSlot].flags);

    //Freeds.
    cosaUSize oldTop = pContext->blockPage.freedTop;
    ++pContext->blockPage.freedTop;
    if (pContext->blockPage.freedTop >= pContext->blockPage.freedCount) {
        _ExpandFreedRegion(pContext);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    pContext->blockPage.pFreed[oldTop] = blockSlot;
}
