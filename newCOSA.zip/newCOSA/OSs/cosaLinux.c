#include "cosaLinux.h"
#include "../headers/error.h"

cosaBool _CosaFindFreedBlock(cosaContext *pContext, cosaUSize *pBlockSlot, cosaUSize blockSize) {
    cosaBool foundSlot = cosaBFalse;
    cosaUSize freedSlot, freedSize, blockSlot = 0;
    for (freedSlot = 0; freedSlot < pContext->blockPage.freedTop; ++freedSlot) {
        blockSlot = pContext->blockPage.pFreed[freedSlot];
        freedSize = pContext->blockPage.pBlocks[blockSlot].count;
        freedSize *= pContext->blockPage.pBlocks[blockSlot].byteSize;
        if (freedSize >= blockSize) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBTrue) {
        cosaUSize i;
        for (i = blockSlot + 1; i < pContext->blockPage.freedTop; ++i) {
            pContext->blockPage.pFreed[i - 1] = pContext->blockPage.pFreed[i];
        }
        --pContext->blockPage.freedTop;
    }

    (*pBlockSlot) = blockSlot;
    return foundSlot;
}

void _CosaAddFreedBlock(cosaContext *pContext, cosaUSize blockSlot) {
    pContext->blockPage.pFreed[pContext->blockPage.freedTop] = blockSlot;
    ++pContext->blockPage.freedTop;

    if (pContext->blockPage.freedTop >= pContext->blockPage.freedCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.freedCount);

        cosaUSize *pNewFreed = realloc(pContext->blockPage.pFreed, newCount * sizeof(cosaUSize));
        if (pNewFreed == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.freedTop;
            return;
        }
        (void)memset(pNewFreed + pContext->blockPage.freedCount, 0, (newCount - pContext->blockPage.freedCount) * sizeof(cosaUSize));
        pContext->blockPage.freedCount = newCount;
        pContext->blockPage.pFreed = pNewFreed;
    }
}

void _CosaGetLinkBlock(cosaContext *pContext, cosaUSize *pLinkSlot) {
    (*pLinkSlot) = pContext->blockPage.linkTop;
    ++pContext->blockPage.linkTop;

    if (pContext->blockPage.linkTop >= pContext->blockPage.linkCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

        cosaLinkBlock *pNewLinks = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaLinkBlock));
        if (pNewLinks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewLinks + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaLinkBlock));
        pContext->blockPage.linkCount = newCount;
        pContext->blockPage.pLinks = pNewLinks;
    }
}

void _CosaUpdateLinks(cosaContext *pContext, cosaMemBlock *pNewBuff) {
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
            (*pContext->blockPage.pLinks[i].ppBlockLink) = &pNewBuff[pContext->blockPage.pLinks[i].blockSlot];
        }
    }
}

void _CosaRemoveLinkBlock(cosaContext *pContext, cosaUSize linkSlot) {
    for (cosaUSize i = linkSlot + 1; i < pContext->blockPage.linkTop; ++i) {
        pContext->blockPage.pLinks[i - 1].blockSlot = pContext->blockPage.pLinks[i].blockSlot;
        pContext->blockPage.pLinks[i - 1].ppBlockLink = pContext->blockPage.pLinks[i].ppBlockLink;
    }
    --pContext->blockPage.linkTop;
}

void _CosaGetBlockMD(cosaContext *pContext, cosaUSize *pBlockSlot) {
    (*pBlockSlot) = pContext->blockPage.blockTop;
    ++pContext->blockPage.blockTop;

    if (pContext->blockPage.blockTop >= pContext->blockPage.blockCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

        cosaMemBlock *pNewBlocks = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
        if (pNewBlocks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewBlocks + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
        pContext->blockPage.blockCount = newCount;

        if (pNewBlocks != pContext->blockPage.pBlocks) {
            _CosaUpdateLinks(pContext, pNewBlocks);
        }
        pContext->blockPage.pBlocks = pNewBlocks;
    }
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    //Unlikely yet possible malloc error.
    cosaUSize blockSize = count * byteSize;
    if (cosaCUnlikely(blockSize > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }

    //Is there usuable freed blocks? Otherwise, get a fresh one.
    cosaUSize blockSlot = 0;
    cosaBool foundSlot = _CosaFindFreedBlock(pContext, &blockSlot, blockSize);
    if (foundSlot == cosaBFalse) {
        _CosaGetBlockMD(pContext, &blockSlot);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }

    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->blockPage.pBlocks[blockSlot].addr = malloc(blockSize);

        if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            return;
        }
    }

    //Get a linkBlock slot and set it.
    cosaUSize linkSlot = 0;
    _CosaGetLinkBlock(pContext, &linkSlot);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        free(pContext->blockPage.pBlocks[blockSlot].addr);
        pContext->blockPage.pBlocks[blockSlot].addr = NULL;
        return;
    }
    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;

    //Give the newly created block's address.
    (*ppBlock) = &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    cosaUSize newSize = count * byteSize;
    cosaUSize oldSize = pBlock->count * pBlock->byteSize;
    cosaU8 *pNewAddr = realloc(pBlock->addr, newSize);
    if (pNewAddr == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewAddr + oldSize, 0, newSize - oldSize);
    pBlock->byteSize = byteSize;
    pBlock->count = count;
    pBlock->addr = pNewAddr;
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    cosaUSize blockSlot = pBlock - pContext->blockPage.pBlocks;
    if (blockSlot > pContext->blockPage.blockTop) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }

    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].blockSlot == blockSlot) {
            _CosaRemoveLinkBlock(pContext, i);
        }
    }
    _CosaAddFreedBlock(pContext, blockSlot);
}

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * bSize;

    if (offset >= (pStack->count - COSA_STACK_SIZE_SS)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    (void)memcpy(pMem + offset, pItem, bSize);
    ++(*pTop);
}

void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * bSize;
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DS);

    if (offset >= size) {
        size += offset - size;
        size += COSA_STACK_EXPAND * bSize;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DS, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    (void)memcpy(pMem + offset, pItem, bSize);
    ++(*pTop);
}

void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) + itemSize + sizeof(cosaUSize);

    if (newTop >= (pStack->count - COSA_STACK_SIZE_SD)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(cosaUSize));
    (*pTop) = newTop;
}

void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) += itemSize + sizeof(itemSize);
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DD);

    if (newTop >= size) {
        size += newTop - size;
        size += COSA_STACK_EXPAND * COSA_STACK_DTYPE_EXPAND;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(itemSize));
    (*pTop) = newTop;
}

void *linuxCosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    if (pSize != NULL) { *pSize = bSize; }
    --(*pTop);

    return pMem + ((*pTop) * bSize);
}

void *linuxCosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    if (pSize != NULL) { *pSize = bSize; }
    --(*pTop);

    return pMem + ((*pTop) * bSize);
}

void *linuxCosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

void *linuxCosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

//StackSS - Static Sized Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_SS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

//StackDS - Dynamic Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_DS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pType = COSA_STACK_TYPE_DS;
    *pBSize = byteSize;

    return pBlock;
}

//StackSD - Static Sized Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_SD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_SD;

    return pBlock;
}

//StackDD - Dynamic Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_DD;

    return pBlock;
}

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pBack = cosaQueueMD_Back(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((size - ((*pCount) * bSize)) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }

    cosaU8 *pMem = cosaQueueMD_Mem(pQueue);
    (void)memcpy(pMem + (*pBack), pItem, bSize);
    (*pBack) = ((*pBack) + bSize) % size;
    ++(*pCount);
}

void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pFront = cosaQueueMD_Front(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((*pCount) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaQueueMD_Mem(pQueue) + (*pFront);
    (*pFront) = ((*pFront) + bSize) % size;
    --(*pCount);
    return pMem;
}

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_QUEUE_SIZE, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaQueueMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}
