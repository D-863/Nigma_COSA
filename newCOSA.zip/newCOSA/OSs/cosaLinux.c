#include "cosaLinux.h"
#include "../headers/error.h"

static cosaBool _CosaFindFreedBlock(cosaContext *pContext, cosaUSize *pBlockSlot, cosaUSize blockSize) {
    cosaBool foundSlot = cosaBFalse;
    cosaUSize freedSlot, freedSize, blockSlot = 0;
    for (freedSlot = 0; freedSlot < pContext->blockPage.freedTop; ++freedSlot) {
        blockSlot = pContext->blockPage.pFreed[freedSlot];
        freedSize = pContext->blockPage.pBlocks[blockSlot].count;
        freedSize *= pContext->blockPage.pBlocks[blockSlot].byteSize;
        if (freedSize >= blockSize) {
            foundSlot = cosaBTrue;
            break;
        }
    }
    if (foundSlot == cosaBTrue) {
        cosaUSize i;
        for (i = blockSlot + 1; i < pContext->blockPage.freedTop; ++i) {
            pContext->blockPage.pFreed[i - 1] = pContext->blockPage.pFreed[i];
        }
        --pContext->blockPage.freedTop;
    }

    (*pBlockSlot) = blockSlot;
    return foundSlot;
}

static void _CosaAddFreedBlock(cosaContext *pContext, cosaUSize blockSlot) {
    pContext->blockPage.pFreed[pContext->blockPage.freedTop] = blockSlot;
    ++pContext->blockPage.freedTop;

    if (pContext->blockPage.freedTop >= pContext->blockPage.freedCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.freedCount);

        cosaUSize *pNewFreed = realloc(pContext->blockPage.pFreed, newCount * sizeof(cosaUSize));
        if (pNewFreed == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.freedTop;
            return;
        }
        (void)memset(pNewFreed + pContext->blockPage.freedCount, 0, (newCount - pContext->blockPage.freedCount) * sizeof(cosaUSize));
        pContext->blockPage.freedCount = newCount;
        pContext->blockPage.pFreed = pNewFreed;
    }
}

static void _CosaGetLinkBlock(cosaContext *pContext, cosaUSize *pLinkSlot) {
    (*pLinkSlot) = pContext->blockPage.linkTop;
    ++pContext->blockPage.linkTop;

    if (pContext->blockPage.linkTop >= pContext->blockPage.linkCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.linkCount);

        cosaLinkBlock *pNewLinks = realloc(pContext->blockPage.pLinks, newCount * sizeof(cosaLinkBlock));
        if (pNewLinks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewLinks + pContext->blockPage.linkCount, 0, (newCount - pContext->blockPage.linkCount) * sizeof(cosaLinkBlock));
        pContext->blockPage.linkCount = newCount;
        pContext->blockPage.pLinks = pNewLinks;
    }
}

static void _CosaUpdateLinks(cosaContext *pContext, cosaMemBlock *pNewBuff) {
    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
            (*pContext->blockPage.pLinks[i].ppBlockLink) = &pNewBuff[pContext->blockPage.pLinks[i].blockSlot];
        }
    }
}

static void _CosaRemoveLinkBlock(cosaContext *pContext, cosaUSize linkSlot) {
    for (cosaUSize i = linkSlot + 1; i < pContext->blockPage.linkTop; ++i) {
        pContext->blockPage.pLinks[i - 1].blockSlot = pContext->blockPage.pLinks[i].blockSlot;
        pContext->blockPage.pLinks[i - 1].ppBlockLink = pContext->blockPage.pLinks[i].ppBlockLink;
    }
    --pContext->blockPage.linkTop;
}

static void _CosaGetBlockMD(cosaContext *pContext, cosaUSize *pBlockSlot) {
    (*pBlockSlot) = pContext->blockPage.blockTop;
    ++pContext->blockPage.blockTop;

    if (pContext->blockPage.blockTop >= pContext->blockPage.blockCount) {
        cosaUSize newCount = COSA_PAGE_EXPAND(pContext->blockPage.blockCount);

        cosaMemBlock *pNewBlocks = realloc(pContext->blockPage.pBlocks, newCount * sizeof(cosaMemBlock));
        if (pNewBlocks == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            --pContext->blockPage.linkTop;
            return;
        }
        (void)memset(pNewBlocks + pContext->blockPage.blockCount, 0, (newCount - pContext->blockPage.blockCount) * sizeof(cosaMemBlock));
        pContext->blockPage.blockCount = newCount;

        if (pNewBlocks != pContext->blockPage.pBlocks) {
            _CosaUpdateLinks(pContext, pNewBlocks);
        }
        pContext->blockPage.pBlocks = pNewBlocks;
    }
}

void linuxCosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    //Unlikely yet possible malloc error.
    cosaUSize blockSize = count * byteSize;
    if (cosaCUnlikely(blockSize > PTRDIFF_MAX)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }

    //Is there usuable freed blocks? Otherwise, get a fresh one.
    cosaUSize blockSlot = 0;
    cosaBool foundSlot = _CosaFindFreedBlock(pContext, &blockSlot, blockSize);
    if (foundSlot == cosaBFalse) {
        _CosaGetBlockMD(pContext, &blockSlot);
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }

    pContext->blockPage.pBlocks[blockSlot].flags = 0x00;
    pContext->blockPage.pBlocks[blockSlot].byteSize = byteSize;
    pContext->blockPage.pBlocks[blockSlot].count = count;
    if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
        pContext->blockPage.pBlocks[blockSlot].addr = malloc(blockSize);

        if (pContext->blockPage.pBlocks[blockSlot].addr == NULL) {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            return;
        }
    }

    //Get a linkBlock slot and set it.
    cosaUSize linkSlot = 0;
    _CosaGetLinkBlock(pContext, &linkSlot);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
        free(pContext->blockPage.pBlocks[blockSlot].addr);
        pContext->blockPage.pBlocks[blockSlot].addr = NULL;
        return;
    }
    pContext->blockPage.pLinks[linkSlot].blockSlot = blockSlot;
    pContext->blockPage.pLinks[linkSlot].ppBlockLink = ppBlock;

    //Give the newly created block's address.
    (*ppBlock) = &pContext->blockPage.pBlocks[blockSlot];
}

void linuxCosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    cosaUSize newSize = count * byteSize;
    cosaUSize oldSize = pBlock->count * pBlock->byteSize;
    cosaU8 *pNewAddr = realloc(pBlock->addr, newSize);
    if (pNewAddr == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pNewAddr + oldSize, 0, newSize - oldSize);
    pBlock->byteSize = byteSize;
    pBlock->count = count;
    pBlock->addr = pNewAddr;
}

void linuxCosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    cosaUSize blockSlot = pBlock - pContext->blockPage.pBlocks;
    if (blockSlot > pContext->blockPage.blockTop) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }

    for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
        if (pContext->blockPage.pLinks[i].blockSlot == blockSlot) {
            _CosaRemoveLinkBlock(pContext, i);
        }
    }
    _CosaAddFreedBlock(pContext, blockSlot);
}

void linuxCosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * bSize;

    if (offset >= (pStack->count - COSA_STACK_SIZE_SS)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    (void)memcpy(pMem + offset, pItem, bSize);
    ++(*pTop);
}

void linuxCosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaUSize offset = (*pTop) * bSize;
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DS);

    if (offset >= size) {
        size += offset - size;
        size += COSA_STACK_EXPAND * bSize;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DS, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    (void)memcpy(pMem + offset, pItem, bSize);
    ++(*pTop);
}

void linuxCosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) + itemSize + sizeof(cosaUSize);

    if (newTop >= (pStack->count - COSA_STACK_SIZE_SD)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(cosaUSize));
    (*pTop) = newTop;
}

void linuxCosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);
    cosaU32 newTop = (*pTop) += itemSize + sizeof(itemSize);
    cosaUSize size = (pStack->count - COSA_STACK_SIZE_DD);

    if (newTop >= size) {
        size += newTop - size;
        size += COSA_STACK_EXPAND * COSA_STACK_DTYPE_EXPAND;
        linuxCosaExpandBlock(pContext, pStack, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);

    (void)memcpy(pMem + (*pTop), pItem, itemSize);
    (void)memcpy(pMem + (*pTop) + itemSize, &itemSize, sizeof(itemSize));
    (*pTop) = newTop;
}

void *linuxCosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SS);
    if (pSize != NULL) { *pSize = bSize; }
    --(*pTop);

    return pMem + ((*pTop) * bSize);
}

void *linuxCosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 bSize = *cosaStackMD_BSize(pStack);
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DS);
    if (pSize != NULL) { *pSize = bSize; }
    --(*pTop);

    return pMem + ((*pTop) * bSize);
}

void *linuxCosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_SD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

void *linuxCosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    cosaU32 *pTop = cosaStackMD_Top(pStack);

    if ((*pTop) < (sizeof(cosaUSize) + 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    (*pTop) -= sizeof(cosaUSize);

    cosaU8 *pMem = cosaStackMD_Mem(pStack, COSA_STACK_SIZE_DD);
    cosaUSize itemSize = *((cosaUSize*)(pMem + (*pTop)));

    if (pSize != NULL) { (*pSize) = itemSize; }
    (*pTop) -= itemSize;

    return pMem + (*pTop);
}

//StackSS - Static Sized Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_SS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

//StackDS - Dynamic Stack Static Typed.
cosaMemBlock *linuxCosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_STACK_SIZE_DS, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    cosaU32 *pBSize = cosaStackMD_BSize(pBlock);
    *pType = COSA_STACK_TYPE_DS;
    *pBSize = byteSize;

    return pBlock;
}

//StackSD - Static Sized Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackSD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_SD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_SD;

    return pBlock;
}

//StackDD - Dynamic Stack Dynamic Typed.
cosaMemBlock *linuxCosaCreateStackDD(cosaContext *pContext, cosaUSize size) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, size + COSA_STACK_SIZE_DD, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU8 *pType = cosaStackMD_Type(pBlock);
    *pType = COSA_STACK_TYPE_DD;

    return pBlock;
}

void linuxCosaQueueAdd(cosaContext *pContext, cosaMemBlock *pQueue, void *pItem) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pBack = cosaQueueMD_Back(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((size - ((*pCount) * bSize)) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OOBSP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OOBSP;
        return;
    }

    cosaU8 *pMem = cosaQueueMD_Mem(pQueue);
    (void)memcpy(pMem + (*pBack), pItem, bSize);
    (*pBack) = ((*pBack) + bSize) % size;
    ++(*pCount);
}

void *linuxCosaQueueNext(cosaContext *pContext, cosaMemBlock *pQueue) {
    cosaU32 bSize = *cosaQueueMD_BSize(pQueue);
    cosaU32 *pFront = cosaQueueMD_Front(pQueue);
    cosaU32 *pCount = cosaQueueMD_Count(pQueue);
    cosaUSize size = pQueue->count - COSA_QUEUE_SIZE;

    if ((*pCount) == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NODATA;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NODATA;
        return NULL;
    }
    cosaU8 *pMem = cosaQueueMD_Mem(pQueue) + (*pFront);
    (*pFront) = ((*pFront) + bSize) % size;
    --(*pCount);
    return pMem;
}

cosaMemBlock *linuxCosaCreateQueue(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    cosaMemBlock *pBlock = NULL;
    linuxCosaCreateBlock(pContext, &pBlock, (count * byteSize) + COSA_QUEUE_SIZE, sizeof(cosaU8));
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return NULL; }
    (void)memset(pBlock->addr, 0, pBlock->count * pBlock->byteSize);

    cosaU32 *pBSize = cosaQueueMD_BSize(pBlock);
    *pBSize = byteSize;

    return pBlock;
}

cosaFile *linuxCosaOpenFile(cosaContext *pContext, cosaU8 flags, cosaChar filePath[]) {
    cosaFile *pFile = NULL;
    cosaU32 fileSlot;
    for (fileSlot = 0; fileSlot < pContext->filePage.count; ++fileSlot) {
        if (pContext->filePage.pFiles[fileSlot].desc == -1) {
            pFile = &pContext->filePage.pFiles[fileSlot];
            break;
        }
    }
    if (pFile == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_TOMFILE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_TOMFILE;
        return NULL;
    }
    cosaU8 fileFlags = cosaR3B(flags);
    cosaI32 memFlags = cosaR2B(fileFlags);

    pFile->desc = open(filePath, memFlags - 1);
    if (pFile->desc < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return NULL;
    }

    if (fstat(pFile->desc, &pFile->info) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    pFile->pMData = mmap(
        NULL, pFile->info.st_size,
        memFlags, COSA_MEM_FLAG_PVE,
        pFile->desc, 0);
    if (pFile->pMData == COSA_MEM_FAILURE) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        (void)close(pFile->desc);
        pFile->desc = -1;
        return NULL;
    }

    return pFile;
}

void linuxCosaOpenImage(cosaContext *pContext, cosaImage *pImage, cosaChar filePath[]) {
    cosaUSize pathLength = strlen(filePath);
    pImage->type = 0;
    cosaChar imageTypes[COSA_IMAGE_TYPE_COUNT][COSA_IMAGE_TYPE_LENGTH] = COSA_IMAGE_TYPES;
    for (cosaU8 i = 0; i < COSA_IMAGE_TYPE_COUNT; ++i) {
        if (strncmp(filePath + (pathLength - 4), imageTypes[i], 4) == 0) {
            pImage->type = i + 1;
            break;
        }
    }
    if (pImage->type == 0) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOOPSUP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOOPSUP;
        return;
    }
    pImage->pFile = linuxCosaOpenFile(pContext, COSA_FILE_FLAG_PERM_RD, filePath);
    if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

    cosaI32 w = 0;
    cosaI32 h = 0;
    cosaI32 c = 0;
    pImage->pData = stbi_load_from_memory(pImage->pFile->pMData, pImage->pFile->info.st_size, &w, &h, &c, 0);
    if (pImage->pData == NULL) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
        return;
    } else if ((w < 1) || (h < 1) || (c < 1)) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        pContext->errorNUM = COSA_CONTEXT_ERRN_RESOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_RESOORNE;
        return;
    }
    pImage->width    = COSA_MACRO_SIGNED_TO_UNSIGNED(w);
    pImage->height   = COSA_MACRO_SIGNED_TO_UNSIGNED(h);
    pImage->channels = COSA_MACRO_SIGNED_TO_UNSIGNED(c);
}

void linuxCosaCloseFile(cosaContext *pContext, cosaFile *pFile) {
    cosaI32 errMem = munmap(pFile->pMData, pFile->info.st_size);
    cosaI32 err = close(pFile->desc);
    pFile->flags = 0x00;

    cosaU8 errFlg = 0x00;
    (errMem < 0) ? cosaS1B(errFlg) : cosaC1B(errFlg);
    (err < 0) ? cosaS1B_O(errFlg, 1) : cosaC1B_O(errFlg, 1);

    switch (errFlg) {
        case 0x03: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            break;
        }
        case 0x02: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->pMData = NULL;
            break;
        }
        case 0x01: {
            _SetContextERRResult(pContext, __FILE__, __LINE__);
            pFile->desc = -1;
            break;
        }
        default: {
            pFile->pMData = NULL;
            pFile->desc = -1;
            break;
        }
    }
}

void linuxCosaCloseImage(cosaContext *pContext, cosaImage *pImage) {
    if (pImage->pData != NULL) {
        stbi_image_free(pImage->pData);
        pImage->pData = NULL;
        pImage->width = 0;
        pImage->height = 0;
        pImage->channels = 0;
    }
    if (pImage->pFile != NULL) {
        linuxCosaCloseFile(pContext, pImage->pFile);
        if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
            pImage->pFile = NULL;
            pImage->type = 0;
        }
    }
}

void linuxCosaInitContext(cosaContext *pContext) {
    pContext->blockPage.blockCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pBlocks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));
    if (pContext->blockPage.pBlocks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return;
    }
    (void)memset(pContext->blockPage.pBlocks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));

    pContext->blockPage.freedCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pFreed = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaUSize));
    if (pContext->blockPage.pFreed == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->blockPage.pFreed, 0, COSA_PAGE_BLOCK_START * sizeof(cosaUSize));

    pContext->blockPage.linkCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pLinks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));
    if (pContext->blockPage.pLinks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->blockPage.pLinks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));


    pContext->pCosaMD = malloc(sizeof(_CosaMD));
    if (pContext->pCosaMD == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->pCosaMD, 0, sizeof(_CosaMD));

    cosaU16 isBigEndian = 0x0001;
    pContext->pCosaMD->systemInfo.isBigEndian = cosaIsEndianBig(isBigEndian);

    if (getrlimit(RLIMIT_NOFILE, &pContext->pCosaMD->systemInfo.maxFDs) < 0) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->pCosaMD);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->pCosaMD = NULL;
        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }


    pContext->filePage.count = COSA_FILE_DESCS_MIN;
    if ((pContext->filePage.count == 0) || (pContext->pCosaMD->systemInfo.maxFDs.rlim_cur < pContext->filePage.count)) {
        pContext->filePage.count = pContext->pCosaMD->systemInfo.maxFDs.rlim_cur;
    }

    pContext->filePage.pFiles = malloc(pContext->filePage.count * sizeof(cosaFile));
    if (pContext->filePage.pFiles == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->pCosaMD);
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);

        pContext->pCosaMD = NULL;
        pContext->blockPage.pLinks = NULL;
        pContext->blockPage.pFreed = NULL;
        pContext->blockPage.pBlocks = NULL;
        return;
    }
    (void)memset(pContext->filePage.pFiles, 0, pContext->filePage.count * sizeof(cosaFile));
    for (cosaU32 i = 0; i < pContext->filePage.count; ++i) {
        pContext->filePage.pFiles[i].desc = -1;
    }
}

void linuxCosaDestroyContext(cosaContext *pContext) {
    if (pContext->filePage.pFiles != NULL) {
        free(pContext->filePage.pFiles);
        pContext->filePage.pFiles = NULL;
    }

    if (pContext->pCosaMD != NULL) {
        free(pContext->pCosaMD);
        pContext->pCosaMD = NULL;
    }

    if (pContext->blockPage.pBlocks != NULL) {
        for (cosaUSize i = 0; i < pContext->blockPage.blockTop; ++i) {
            free(pContext->blockPage.pBlocks[i].addr);
            pContext->blockPage.pBlocks[i].addr = NULL;
        }
        free(pContext->blockPage.pBlocks);
        pContext->blockPage.pBlocks = NULL;
    }

    if (pContext->blockPage.pLinks != NULL) {
        for (cosaUSize i = 0; i < pContext->blockPage.linkTop; ++i) {
            if (pContext->blockPage.pLinks[i].ppBlockLink != NULL) {
                (*pContext->blockPage.pLinks[i].ppBlockLink) = NULL;
            }
            pContext->blockPage.pLinks[i].ppBlockLink = NULL;
        }
        free(pContext->blockPage.pLinks);
        pContext->blockPage.pLinks = NULL;
    }

    free(pContext->blockPage.pFreed);
    pContext->blockPage.pFreed = NULL;
    _InitContext(pContext);
}


#if defined(COSA_ENABLE_EXTENSIONS)
    static cosaU32 _CosaExtensionFind(cosaContext *pContext, cosaU32 extensionID) {
        cosaU32 top = *cosaStackMD_Top(pContext->pCosaMD->pSExtensions);
        if (top == 0) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
            return 0;
        }
        _CosaExtension *pMem = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, COSA_STACK_SIZE_SS);

        cosaBool foundSlot = cosaBFalse;
        cosaU32 extensionSlot;
        for (extensionSlot = 0; extensionSlot < top; ++extensionSlot) {
            if (pMem[extensionSlot].ID == extensionID) {
                foundSlot = cosaBTrue;
                break;
            }
        }
        if (foundSlot == cosaBFalse) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
        }
        return extensionSlot;
    }

    static cosaU32 _CosaExtensionCreate(cosaContext *pContext, _CosaExtension *pExtensionMD) {
        cosaU32 top = *cosaStackMD_Top(pContext->pCosaMD->pSExtensions);
        linuxCosaStackSSPush(pContext, pContext->pCosaMD->pSExtensions, pExtensionMD);
        return top;
    }

    static void _CosaExtensionRemove(cosaContext *pContext, cosaU32 extensionSlot) {
        cosaU32 top = *cosaStackMD_Top(pContext->pCosaMD->pSExtensions);
        if ((top == 0) || (extensionSlot > (top - 1))) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_INVSLT;
            pContext->errorMSG = COSA_CONTEXT_ERRS_INVSLT;
            return;
        }
        _CosaExtension *pMem = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, COSA_STACK_SIZE_SS);
        _CosaExtension *pExt = linuxCosaStackSSPop(pContext, pContext->pCosaMD->pSExtensions, NULL);
        if (pMem[extensionSlot].ID != pExt->ID) {
            pMem[extensionSlot].ID       = pExt->ID;
            pMem[extensionSlot].pBlock   = pExt->pBlock;
            pMem[extensionSlot].pCleanup = pExt->pCleanup;
        }
    }

    void linuxCosaInitExtensions(cosaContext *pContext) {
        if ((COSA_EXTENSION_COUNT == 0) || (COSA_EXTENSION_COUNT > 255)) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
            pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
            return;
        }
        pContext->pCosaMD->pSExtensions = linuxCosaCreateStackSS(pContext, COSA_EXTENSION_COUNT, sizeof(_CosaExtension));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
    }
#endif

#if defined(COSA_EXTENSION_ENABLE_PANEL)
    void _CosaPanelExtensionCleanupGlfw(cosaContext *pContext, cosaU8 ID, cosaMemBlock *pBlock) {
        (void)_CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;
            return;
        }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBTrue) {
            pCosaGLFW->isInitialized = cosaBFalse;
            pCosaGLFW->monitorCount = 0;
            pCosaGLFW->pBMonitors = NULL;
        }
        glfwTerminate();
    }

    void _CosaPanelExtensionInitGlfw(cosaContext *pContext, _CosaExtension *pExtension, _cosaGLFW_EXT *pCosaGLFW) {
        if (glfwInit() == GLFW_FALSE) {
            pContext->errorNUM = COSA_CONTEXT_ERRN_LIBACC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_LIBACC;
        }
        pCosaGLFW->isInitialized = cosaBTrue;
        pExtension->pCleanup = _CosaPanelExtensionCleanupGlfw;
    }

    void linuxCosaPanelFrameStart(cosaContext *pContext, cosaPanel *pPanel) {
        cosaU8 R = cosaR8B_O(pPanel->color, 24) >> 24;
        cosaU8 G = cosaR8B_O(pPanel->color, 16) >> 16;
        cosaU8 B = cosaR8B_O(pPanel->color, 8) >> 8;
        cosaU8 A = cosaR8B(pPanel->color) >> 0;
        glClearColor(
            (R > 0) ? (GLfloat)(1.0f/(255.0f/R)) : 0.0f,
            (G > 0) ? (GLfloat)(1.0f/(255.0f/G)) : 0.0f,
            (B > 0) ? (GLfloat)(1.0f/(255.0f/B)) : 0.0f,
            (A > 0) ? (GLfloat)(1.0f/(255.0f/A)) : 0.0f
        );
        glClear(GL_COLOR_BUFFER_BIT);
    }

    void linuxCosaPanelFrameEnd(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        glfwSwapBuffers(pPanelMD_GLFW->pWindow);
        glfwPollEvents();

        if (glfwWindowShouldClose(pPanelMD_GLFW->pWindow) == GLFW_TRUE) { pPanel->flags |= COSA_PANEL_ACTIVE; }
    }

    void linuxCosaDestroyPanel(cosaContext *pContext, cosaPanel *pPanel) {
        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        if (pPanel->pIconPath != NULL) { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        glfwMakeContextCurrent(NULL);
        glfwDestroyWindow(pPanelMD_GLFW->pWindow);
        pPanelMD_GLFW->icon.width = 0;
        pPanelMD_GLFW->icon.height = 0;
        pPanelMD_GLFW->icon.pixels = NULL;
        pPanelMD_GLFW->pMonitor = NULL;
        pPanelMD_GLFW->pWindow = NULL;
        pPanel->pBlock->flags = 0x00;
        pPanel->pBlock = NULL;
        pPanel->pIconPath = NULL;
        pPanel->pTitle = NULL;
        pPanel->posX = 0;
        pPanel->posY = 0;
        pPanel->color = 0x000000FF;
        pPanel->width = 0;
        pPanel->height = 0;
        pPanel->flags = 0x0000;
    }

    void linuxCosaCreatePanel(cosaContext *pContext, cosaPanel *pPanel) {
        _CosaExtension *pExtStack = (_CosaExtension*)cosaStackMD_Mem(pContext->pCosaMD->pSExtensions, COSA_STACK_SIZE_SS);
        cosaU32 panelExtSlot = _CosaExtensionFind(pContext, COSA_EXTENSION_PANEL_ID);
        if (pContext->errorNUM == COSA_CONTEXT_ERRN_INVSLT) {
            pContext->errorNUM = COSA_CONTEXT_SUCCESS_NUM;
            pContext->errorMSG = COSA_CONTEXT_SUCCESS_MSG;

            _CosaExtension panelExt = {0};

            linuxCosaCreateBlock(pContext, &panelExt.pBlock, 1, sizeof(_cosaGLFW_EXT));
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

            (void)memset(panelExt.pBlock->addr, 0, panelExt.pBlock->count * panelExt.pBlock->byteSize);
            panelExt.ID = COSA_EXTENSION_PANEL_ID;

            panelExtSlot = _CosaExtensionCreate(pContext, &panelExt);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        } else if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }

        _cosaGLFW_EXT *pCosaGLFW = (_cosaGLFW_EXT*)pExtStack[panelExtSlot].pBlock->addr;
        if (pCosaGLFW->isInitialized == cosaBFalse) {
            _CosaPanelExtensionInitGlfw(pContext, &pExtStack[panelExtSlot], pCosaGLFW);
            if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) {
                pExtStack[panelExtSlot].pBlock->flags = 0x00;
                _CosaExtensionRemove(pContext, panelExtSlot);
            }
        }
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, COSA_PANEL_CONTEXT_MAJOR);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, COSA_PANEL_CONTEXT_MINOR);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

        glfwWindowHint(GLFW_POSITION_X, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_POSITION_Y, GLFW_ANY_POSITION);
        glfwWindowHint(GLFW_CONTEXT_DEBUG,           ((pPanel->flags >> 9) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, ((pPanel->flags >> 1) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        glfwWindowHint(GLFW_FOCUS_ON_SHOW,           ((pPanel->flags >> 2) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #if defined(USING_X11) || defined(COSA_OS_WINDOWS)
            glfwWindowHint(GLFW_SCALE_TO_MONITOR,  ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #elif defined(USING_WAYLAND)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
        #endif

        #if defined(COSA_OS_MACOS)
            glfwWindowHint(GLFW_SCALE_FRAMEBUFFER, ((pPanel->flags >> 4) & 0x01) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
        #else
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_FALSE);
        #endif

        if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
            glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
            glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
            glfwWindowHint(GLFW_MAXIMIZED, GLFW_FALSE);
            glfwWindowHint(GLFW_VISIBLE,   GLFW_FALSE);
            glfwWindowHint(GLFW_FOCUSED,   GLFW_FALSE);
            glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & COSA_PANEL_MOUSE_PASSTHROUGH) == COSA_PANEL_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_AUTO_ICONIFY,      ((pPanel->flags & COSA_PANEL_AUTO_ICONIFY)      == COSA_PANEL_AUTO_ICONIFY     ) ? GLFW_TRUE : GLFW_FALSE);
            glfwWindowHint(GLFW_CENTER_CURSOR,     ((pPanel->flags & COSA_PANEL_CENTER_CURSOR)     == COSA_PANEL_CENTER_CURSOR    ) ? GLFW_TRUE : GLFW_FALSE);
        } else {
            glfwWindowHint(GLFW_MAXIMIZED, ((pPanel->flags & COSA_PANEL_MAXIMIZED) == COSA_PANEL_MAXIMIZED) ? GLFW_TRUE : GLFW_FALSE);

            if ((pPanel->flags & COSA_PANEL_DECORATED) == COSA_PANEL_DECORATED) {
                glfwWindowHint(GLFW_DECORATED, GLFW_TRUE);
                glfwWindowHint(GLFW_RESIZABLE, ((pPanel->flags & COSA_PANEL_RESIZABLE) == COSA_PANEL_RESIZABLE) ? GLFW_TRUE : GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
                glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
                glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, ((pPanel->flags & GLFW_MOUSE_PASSTHROUGH) == GLFW_MOUSE_PASSTHROUGH) ? GLFW_TRUE : GLFW_FALSE);
            }

            if ((pPanel->flags & COSA_PANEL_VISIBLE) == COSA_PANEL_VISIBLE) {
                glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);
                glfwWindowHint(GLFW_FOCUSED, ((pPanel->flags & COSA_PANEL_FOCUSED) == COSA_PANEL_FOCUSED) ? GLFW_TRUE : GLFW_FALSE);
            } else {
                glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
                glfwWindowHint(GLFW_FOCUSED, GLFW_FALSE);
            }
        }


        linuxCosaCreateBlock(pContext, &pPanel->pBlock, 1, sizeof(cosaPanel_GLFW));
        if (pContext->errorNUM != COSA_CONTEXT_SUCCESS_NUM) { return; }
        (void)memset(pPanel->pBlock->addr, 0, pPanel->pBlock->count * pPanel->pBlock->byteSize);

        cosaPanel_GLFW *pPanelMD_GLFW = (cosaPanel_GLFW*)pPanel->pBlock->addr;
        pPanelMD_GLFW->pWindow = glfwCreateWindow(pPanel->width, pPanel->height, pPanel->pTitle, NULL, NULL);
        if (pPanelMD_GLFW->pWindow == NULL) {
            pPanel->pBlock->flags = 0x00;
            pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
            pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
            return;
        }
        glfwMakeContextCurrent(pPanelMD_GLFW->pWindow);
        glfwSwapInterval(1); // V-Sync.

        if (pPanel->pIconPath != NULL) {
            cosaImage image;
            linuxCosaOpenImage(pContext, &image, pPanel->pIconPath);
            if (pContext->errorNUM == COSA_CONTEXT_SUCCESS_NUM) {
                pPanelMD_GLFW->icon.width = image.width;
                pPanelMD_GLFW->icon.height = image.height;
                pPanelMD_GLFW->icon.pixels = image.pData;
                glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 1, &pPanelMD_GLFW->icon);
                linuxCosaCloseImage(pContext, &image);

                pPanelMD_GLFW->icon.width = 0;
                pPanelMD_GLFW->icon.height = 0;
                pPanelMD_GLFW->icon.pixels = NULL;
            } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }
        } else { glfwSetWindowIcon(pPanelMD_GLFW->pWindow, 0, NULL); }

        if (((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) ||
            ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) ||
            ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y)) {
                if (pCosaGLFW->pBMonitors == NULL) {
                    cosaI32 monitorCount = 0;
                    pCosaGLFW->pBMonitors = glfwGetMonitors(&monitorCount);
                    if ((monitorCount == 0) || (pCosaGLFW->pBMonitors == NULL)) {
                        pCosaGLFW->monitorCount = 0;
                        pCosaGLFW->pBMonitors = NULL;
                        pContext->errorNUM = COSA_CONTEXT_ERRN_INVARG;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_INVARG;

                        linuxCosaDestroyPanel(pContext, pPanel);
                        return;
                    }
                    pCosaGLFW->monitorCount = COSA_MACRO_SIGNED_TO_UNSIGNED(monitorCount);
                }
                pPanelMD_GLFW->pMonitor = NULL;

                for (cosaU32 i = 0; i < pCosaGLFW->monitorCount; i++) {
                    if (pCosaGLFW->pBMonitors[i] != NULL) {
                        pPanelMD_GLFW->pMonitor = pCosaGLFW->pBMonitors[i];
                        break;
                    }
                }
                if (pPanelMD_GLFW->pMonitor == NULL) {
                    pContext->errorNUM = COSA_CONTEXT_ERRN_NOMDIM;
                    pContext->errorMSG = COSA_CONTEXT_ERRS_NOMDIM;
                } else {
                    const GLFWvidmode *pVideoMode = glfwGetVideoMode(pPanelMD_GLFW->pMonitor);
                    if (pVideoMode == NULL) {
                        pContext->errorNUM = COSA_CONTEXT_ERRN_PTC;
                        pContext->errorMSG = COSA_CONTEXT_ERRS_PTC;
                    } else if ((pPanel->flags & COSA_PANEL_FULL) == COSA_PANEL_FULL) {
                        pPanel->width = pVideoMode->width;
                        pPanel->height = pVideoMode->height;
                        pPanel->posX = 0;
                        pPanel->posY = 0;
                        glfwSetWindowMonitor(pPanelMD_GLFW->pWindow, pPanelMD_GLFW->pMonitor, pPanel->posX, pPanel->posY, pPanel->width, pPanel->height, pVideoMode->refreshRate);
                    } else {
                        cosaI32 gotWindowPosX = 0;
                        cosaI32 gotWindowPosY = 0;
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);

                        cosaI32 gotMonitorPosX = 0;
                        cosaI32 gotMonitorPosY = 0;
                        glfwGetMonitorPos(pPanelMD_GLFW->pMonitor, &gotMonitorPosX, &gotMonitorPosY);
                        if ((pPanel->flags & COSA_PANEL_POS_X) == COSA_PANEL_POS_X) {
                            gotWindowPosX = gotMonitorPosX + pPanel->posX;
                            if ((gotWindowPosX + pPanel->width) > pVideoMode->width) {
                                gotWindowPosX -= (gotWindowPosX + pPanel->width) - pVideoMode->width;
                                if (gotWindowPosX < gotMonitorPosX) { gotWindowPosX = gotMonitorPosX; }
                            }
                        }
                        if ((pPanel->flags & COSA_PANEL_POS_Y) == COSA_PANEL_POS_Y) {
                            gotWindowPosY = gotMonitorPosY + pPanel->posY;
                            if ((gotWindowPosY + pPanel->height) > pVideoMode->height) {
                                gotWindowPosY -= (gotWindowPosY + pPanel->height) - pVideoMode->height;
                                if (gotWindowPosY < gotMonitorPosY) { gotWindowPosY = gotMonitorPosY; }
                            }
                        }
                        glfwSetWindowPos(pPanelMD_GLFW->pWindow, gotWindowPosX, gotWindowPosY);
                        glfwGetWindowPos(pPanelMD_GLFW->pWindow, &gotWindowPosX, &gotWindowPosY);
                    }
                }
        }


        (void)gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
        glViewport(0, 0, pPanel->width, pPanel->height);
    }
#endif