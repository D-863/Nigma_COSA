#include "headers/COSA.h"
#include "headers/error.h"

#if defined(COSA_OS_LINUX)
    #include "OSs/cosaLinux.h"
#endif

void cosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateBlock(pContext, ppBlock, count, byteSize);
    #endif
}

void cosaExpandBlock(cosaContext *pContext, cosaMemBlock *pBlock, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaExpandBlock(pContext, pBlock, count, byteSize);
    #endif
}

void cosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaDestroyBlock(pContext, pBlock);
    #endif
}

void cosaStackSSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackSSPush(pContext, pStack, pItem);
    #endif
}

void cosaStackDSPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackDSPush(pContext, pStack, pItem);
    #endif
}

void cosaStackSDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((itemSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackSDPush(pContext, pStack, pItem, itemSize);
    #endif
}

void cosaStackDDPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((itemSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackDDPush(pContext, pStack, pItem, itemSize);
    #endif
}

void *cosaStackSSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackSSPop(pContext, pStack, pSize);
    #endif
}

void *cosaStackDSPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackDSPop(pContext, pStack, pSize);
    #endif
}

void *cosaStackSDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackSDPop(pContext, pStack, pSize);
    #endif
}

void *cosaStackDDPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackDDPop(pContext, pStack, pSize);
    #endif
}

void cosaStackPush(cosaContext *pContext, cosaMemBlock *pStack, void *pItem, cosaUSize itemSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL) || (pItem == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((itemSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaStackPush(pContext, pStack, pItem, itemSize);
    #endif
}

void *cosaStackPop(cosaContext *pContext, cosaMemBlock *pStack, cosaUSize *pSize) {
    if (pContext == NULL) { return NULL; }
    if ((pContext->blockPage.pBlocks == NULL) || (pStack == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaStackPop(pContext, pStack, pSize);
    #endif
}

cosaMemBlock *cosaCreateStackSS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    if (pContext == NULL) { return NULL; }
    if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaCreateStackSS(pContext, count, byteSize);
    #endif
}

cosaMemBlock *cosaCreateStackDS(cosaContext *pContext, cosaU32 count, cosaU32 byteSize) {
    if (pContext == NULL) { return NULL; }
    if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaCreateStackDS(pContext, count, byteSize);
    #endif
}

cosaMemBlock *cosaCreateStackSD(cosaContext *pContext, cosaUSize size) {
    if (pContext == NULL) { return NULL; }
    if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if (size < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaCreateStackSD(pContext, size);
    #endif
}

cosaMemBlock *cosaCreateStackDD(cosaContext *pContext, cosaUSize size) {
    if (pContext == NULL) { return NULL; }
    if (pContext->blockPage.pBlocks == NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return NULL;
    } else if (size < 1) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return NULL;
    }
    #if defined(COSA_OS_LINUX)
        return linuxCosaCreateStackDD(pContext, size);
    #endif
}

cosaU8 cosaInitContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return COSA_RESULTS_FUNC_FAILURE;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return COSA_RESULTS_FUNC_ARG_PTR_NULL;
    } else if (pContext->blockPage.pBlocks != NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (_TestArchitectureCompatibility() == COSA_RESULTS_FUNC_FAILURE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return COSA_RESULTS_FUNC_FAILURE;
    }
    _InitializeContext(pContext);

    pContext->blockPage.blockCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pBlocks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));
    if (pContext->blockPage.pBlocks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->blockPage.pBlocks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));

    pContext->blockPage.freedCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pFreed = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaUSize));
    if (pContext->blockPage.pFreed == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pBlocks);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->blockPage.pFreed, 0, COSA_PAGE_BLOCK_START * sizeof(cosaUSize));

    pContext->blockPage.linkCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pLinks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));
    if (pContext->blockPage.pLinks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->blockPage.pLinks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaLinkBlock));

    return COSA_RESULTS_FUNC_SUCCESS;
#endif
}

void cosaDestroyContext(cosaContext *pContext) {
    if (pContext != NULL) {
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);
        _InitializeContext(pContext);
    }
}
