#include "headers/COSA.h"
#include "headers/error.h"

#if defined(COSA_OS_LINUX)
    #include "OSs/cosaLinux.h"
#endif

void cosaCreateBlock(cosaContext *pContext, cosaMemBlock **ppBlock, cosaUSize count, cosaUSize byteSize) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (ppBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    } else if ((count < 1) || (byteSize < 1)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_ARGOORNE;
        pContext->errorMSG = COSA_CONTEXT_ERRS_ARGOORNE;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaCreateBlock(pContext, ppBlock, count, byteSize);
    #endif
}

void cosaDestroyBlock(cosaContext *pContext, cosaMemBlock *pBlock) {
    if (pContext == NULL) { return; }
    if ((pContext->blockPage.pBlocks == NULL) || (pBlock == NULL)) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_NOADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_NOADDR;
        return;
    }
    #if defined(COSA_OS_LINUX)
        linuxCosaDestroyBlock(pContext, pBlock);
    #endif
}

cosaU8 cosaInitContext(cosaContext *pContext) {
#if defined(COSA_OS_NOSUPPORT)
    cosaPrint("COSA: The current OS is not supported!");
    return COSA_RESULTS_FUNC_FAILURE;
#else
    if (pContext == NULL) {
        cosaPrint(COSA_CONTEXT_ERRS_INVARG);
        return COSA_RESULTS_FUNC_ARG_PTR_NULL;
    } else if (pContext->blockPage.pBlocks != NULL) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_BUSYADDR;
        pContext->errorMSG = COSA_CONTEXT_ERRS_BUSYADDR;
        return COSA_RESULTS_FUNC_FAILURE;
    } else if (_TestArchitectureCompatibility() == COSA_RESULTS_FUNC_FAILURE) {
        pContext->errorNUM = COSA_CONTEXT_ERRN_OPNP;
        pContext->errorMSG = COSA_CONTEXT_ERRS_OPNP;
        return COSA_RESULTS_FUNC_FAILURE;
    }
    _InitializeContext(pContext);

    pContext->blockPage.blockCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pBlocks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));
    if (pContext->blockPage.pBlocks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->blockPage.pBlocks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaMemBlock));

    pContext->blockPage.freedCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pFreed = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaUSize));
    if (pContext->blockPage.pFreed == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pBlocks);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->blockPage.pFreed, 0, COSA_PAGE_BLOCK_START * sizeof(cosaUSize));

    pContext->blockPage.linkCount = COSA_PAGE_BLOCK_START;
    pContext->blockPage.pLinks = malloc(COSA_PAGE_BLOCK_START * sizeof(cosaUSize));
    if (pContext->blockPage.pLinks == NULL) {
        _SetContextERRResult(pContext, __FILE__, __LINE__);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);
        return COSA_RESULTS_FUNC_FAILURE;
    }
    (void)memset(pContext->blockPage.pLinks, 0, COSA_PAGE_BLOCK_START * sizeof(cosaUSize));

    return COSA_RESULTS_FUNC_SUCCESS;
#endif
}

void cosaDestroyContext(cosaContext *pContext) {
    if (pContext != NULL) {
        free(pContext->blockPage.pLinks);
        free(pContext->blockPage.pFreed);
        free(pContext->blockPage.pBlocks);
        _InitializeContext(pContext);
    }
}
